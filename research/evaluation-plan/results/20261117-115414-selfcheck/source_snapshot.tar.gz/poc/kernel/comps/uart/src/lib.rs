// SPDX-License-Identifier: MPL-2.0

//! Universal asynchronous receiver-transmitter (UART).

#![no_std]
#![deny(unsafe_code)]

extern crate alloc;

#[cfg(not(feature = "kernelet"))]
use component::{ComponentInitError, init_component};

// Set this crate's log prefix for `ostd::log`.
macro_rules! __log_prefix {
    () => {
        "uart: "
    };
}

#[cfg_attr(target_arch = "x86_64", path = "arch/x86/mod.rs")]
#[cfg_attr(target_arch = "riscv64", path = "arch/riscv/mod.rs")]
#[cfg_attr(target_arch = "loongarch64", path = "arch/loongarch/mod.rs")]
#[cfg_attr(target_arch = "aarch64", path = "arch/arm/mod.rs")]
#[cfg(not(feature = "kernelet"))]
mod arch;

#[cfg(not(feature = "kernelet"))]
mod console;

pub const CONSOLE_NAME: &str = "Uart-Console";

#[cfg(not(feature = "kernelet"))]
#[init_component]
fn init() -> Result<(), ComponentInitError> {
    arch::init();
    Ok(())
}
