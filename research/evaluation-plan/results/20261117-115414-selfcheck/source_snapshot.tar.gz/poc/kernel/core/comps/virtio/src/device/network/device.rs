// SPDX-License-Identifier: MPL-2.0

use alloc::{boxed::Box, string::ToString, sync::Arc, vec::Vec};
use core::fmt::Debug;

use aster_bigtcp::{
    device::{AnyNetworkDevice, Checksum, DeviceCapabilities, EthernetAddress, Medium, NetError},
    packet::{
        ApplicationLayer, FreshTxPacket, Layer, LinkLayer, RxBuffer, RxPacket, TxBuffer, TxPacket,
    },
};
use aster_util::slot_vec::SlotVec;
use ostd::{arch::trap::TrapFrame, debug, sync::SpinLock, warn};

use super::{config::VirtioNetConfig, header::VirtioNetHdr};
use crate::{
    device::{
        VirtioDeviceError,
        network::{
            buffer::{RX_BUFFER_POOL, TX_BUFFER_LEN, TX_BUFFER_POOL},
            config::NetworkFeatures,
        },
    },
    queue::{self, VirtQueue},
    transport::{ConfigManager, DeviceTransport},
};

pub struct NetworkDevice {
    config_manager: ConfigManager<VirtioNetConfig>,
    // For smoltcp use
    caps: DeviceCapabilities,
    mac_addr: EthernetAddress,
    send_queue: VirtQueue,
    recv_queue: VirtQueue,
    // Since the virtio net header remains consistent for each sending packet,
    // we store it to avoid recreating the header repeatedly.
    header: VirtioNetHdr,
    tx_buffers: Vec<Option<TxBuffer>>,
    rx_buffers: SlotVec<RxBuffer>,
    new_rx_buffer: Option<RxBuffer>,
    transport: DeviceTransport,
    poll_stat: PollStatistics,
}

/// Structure to track the number of packets sent and received during a single polling process.
struct PollStatistics {
    sent_packet: usize,
    received_packet: usize,
}

impl PollStatistics {
    const fn new() -> Self {
        Self {
            sent_packet: 0,
            received_packet: 0,
        }
    }
}

impl NetworkDevice {
    pub(crate) fn negotiate_features(device_features: u64) -> u64 {
        let device_features = NetworkFeatures::from_bits_truncate(device_features);
        let supported_features = NetworkFeatures::supported_features();
        let network_features = device_features & supported_features;

        if network_features != device_features {
            warn!(
                "unsupported device features: {:?}",
                device_features.difference(supported_features)
            );
        }

        debug!("{:?}", network_features);
        network_features.bits()
    }

    pub(crate) fn init(mut device_transport: DeviceTransport) -> Result<(), VirtioDeviceError> {
        let config_manager = VirtioNetConfig::new_manager(device_transport.as_ref());
        let config = config_manager.read_config();
        debug!("virtio_net_config = {:?}", config);
        let mac_addr = EthernetAddress(config.mac);
        let features = NetworkFeatures::from_bits_truncate(Self::negotiate_features(
            device_transport.read_device_features(),
        ));
        debug!("features = {:?}", features);

        let caps = init_caps(&features, &config);

        let mut send_queue = VirtQueue::new(QUEUE_SEND, QUEUE_SIZE, device_transport.as_mut())?;
        send_queue.disable_callback();

        let mut recv_queue = VirtQueue::new(QUEUE_RECV, QUEUE_SIZE, device_transport.as_mut())?;

        let tx_buffers = (0..QUEUE_SIZE).map(|_| None).collect();

        let mut rx_buffers = SlotVec::new();
        for i in 0..QUEUE_SIZE {
            let rx_pool = RX_BUFFER_POOL.get().unwrap();
            let rx_buffer = RxBuffer::alloc(rx_pool).map_err(VirtioDeviceError::ResourceAlloc)?;
            let token = recv_queue.add_output_bufs(&[&rx_buffer]).unwrap();
            assert_eq!(i, token);
            assert_eq!(rx_buffers.put(rx_buffer) as u16, i);
        }

        let mut device = Self {
            config_manager,
            caps,
            mac_addr,
            send_queue,
            recv_queue,
            header: VirtioNetHdr::default(),
            tx_buffers,
            rx_buffers,
            new_rx_buffer: None,
            transport: device_transport,
            poll_stat: PollStatistics::new(),
        };

        /// Interrupt handler if network device config space changes
        fn config_space_change(_: &TrapFrame) {
            debug!("network device config space change");
        }

        /// Interrupt handlers if network device receives/sends some packet
        fn handle_send_event(_: &TrapFrame) {
            aster_network::raise_send_softirq();
        }
        fn handle_recv_event(_: &TrapFrame) {
            aster_network::raise_receive_softirq();
        }

        device
            .transport
            .register_cfg_callback(Box::new(config_space_change))?;
        device
            .transport
            .register_queue_callback(QUEUE_SEND, Box::new(handle_send_event), true)?;
        device
            .transport
            .register_queue_callback(QUEUE_RECV, Box::new(handle_recv_event), true)?;

        device.transport.finish_init();

        if device.recv_queue.should_notify() {
            debug!("notify receive queue");
            device.recv_queue.notify();
        }

        aster_network::register_device(
            super::DEVICE_NAME.to_string(),
            Arc::new(SpinLock::new(device)),
        );
        Ok(())
    }

    /// Adds a `RxBuffer` to the receive queue.
    fn add_rx_buffer(&mut self, rx_buffer: RxBuffer) -> Result<(), queue::AddBufsError> {
        let token = self.recv_queue.add_output_bufs(&[&rx_buffer])?;
        assert!(self.rx_buffers.put_at(token as usize, rx_buffer).is_none());

        self.poll_stat.received_packet += 1;

        if self.poll_stat.received_packet == QUEUE_SIZE as _ {
            // If we know there are no free buffers for receiving,
            // we will notify the receive queue as soon as possible.
            self.notify_receive_queue();
        }

        Ok(())
    }

    /// Receives a packet from network.
    fn receive(&mut self) -> Result<RxPacket<LinkLayer>, NetError> {
        if self.new_rx_buffer.is_none() {
            // FIXME: Ideally, we can reuse the returned buffer without creating new buffer.
            // But this requires locking device to be compatible with smoltcp interface.
            let rx_pool = RX_BUFFER_POOL.get().unwrap();
            let new_rx_buffer = RxBuffer::alloc(rx_pool).map_err(|_| NetError::NoMemory)?;

            self.new_rx_buffer = Some(new_rx_buffer);
        }

        let (token, len) = self
            .recv_queue
            .pop_used_with_min_bytes(size_of::<VirtioNetHdr>())
            .map_err(|_| NetError::NotReady)?;
        debug!("receive packet: token = {}, len = {}", token, len);

        let rx_buffer = self.rx_buffers.remove(token as usize).unwrap();

        let new_rx_buffer = self.new_rx_buffer.take().unwrap();
        self.add_rx_buffer(new_rx_buffer).unwrap();

        let packet = rx_buffer.finish_dma(len as usize);
        Ok(packet.peel(size_of::<VirtioNetHdr>()))
    }

    /// Sends a packet to network.
    fn send(&mut self, packet: TxPacket<LinkLayer>) -> Result<(), NetError> {
        if !self.can_send() {
            return Err(NetError::Busy);
        }

        let packet_len = packet.reader().remain();
        let packet = packet.prepend_and_pack(&self.header);
        let tx_buffer = packet.map_dma(false).map_err(|_| NetError::NoMemory)?;

        let token = self.send_queue.add_input_bufs(&[&tx_buffer]).unwrap();

        self.poll_stat.sent_packet += 1;

        if self.send_queue.available_desc() == 0 {
            // If the send queue is full,
            // we will notify the send queue as soon as possible.
            self.notify_send_queue();
        }

        debug!("send packet, token = {}, len = {}", token, packet_len);

        debug_assert!(self.tx_buffers[token as usize].is_none());
        self.tx_buffers[token as usize] = Some(tx_buffer);

        self.free_processed_tx_buffers();

        // If the send queue is not full, we can free the send buffers during the next sending process.
        // Therefore, there is no need to free the used buffers in the IRQ handlers.
        // This allows us to temporarily disable the send queue interrupt.
        // Conversely, if the send queue is full, the send queue interrupt should remain enabled
        // to free the send buffers as quickly as possible.
        if !self.can_send() {
            self.send_queue.enable_callback();
            // A completion may arrive after the previous reap while callbacks
            // are disabled. The used-ring read barrier publishes the callback
            // state before checking again: this reap observes earlier work,
            // while a later completion can generate an interrupt.
            self.free_processed_tx_buffers();
        }
        if self.can_send() {
            self.send_queue.disable_callback();
        }

        Ok(())
    }

    fn notify_send_queue(&mut self) {
        if self.poll_stat.sent_packet == 0 {
            return;
        }

        debug!(
            "notify send queue: sent {} packets",
            self.poll_stat.sent_packet
        );
        if self.send_queue.should_notify() {
            self.send_queue.notify();
        }

        self.poll_stat.sent_packet = 0;
    }

    fn notify_receive_queue(&mut self) {
        if self.poll_stat.received_packet == 0 {
            return;
        }

        debug!(
            "notify receive queue: received {} packets",
            self.poll_stat.received_packet
        );
        if self.recv_queue.should_notify() {
            self.recv_queue.notify();
        }

        self.poll_stat.received_packet = 0;
    }
}

fn init_caps(features: &NetworkFeatures, config: &VirtioNetConfig) -> DeviceCapabilities {
    let mut caps = DeviceCapabilities::default();

    caps.max_burst_size = None;
    caps.medium = Medium::Ethernet;

    if features.contains(NetworkFeatures::VIRTIO_NET_F_MTU) {
        // If `VIRTIO_NET_F_MTU` is negotiated, the MTU is decided by the device.
        caps.max_transmission_unit = config.mtu as usize;
    } else {
        // We do not support these features,
        // so this asserts that they are _not_ negotiated.
        //
        // Without these features, the MTU is 1514 bytes per the virtio-net specification
        // (see "5.1.6.3 Setting Up Receive Buffers" and "5.1.6.2 Packet Transmission").
        assert!(
            !features.contains(NetworkFeatures::VIRTIO_NET_F_GUEST_TSO4)
                && !features.contains(NetworkFeatures::VIRTIO_NET_F_GUEST_TSO6)
                && !features.contains(NetworkFeatures::VIRTIO_NET_F_GUEST_UFO)
        );
        caps.max_transmission_unit = 1514;
    }

    // We do not support checksum offloading.
    // So the features must not be negotiated,
    // and we must deliver fully checksummed packets to the device
    // and validate all checksums for packets from the device.
    assert!(
        !features.contains(NetworkFeatures::VIRTIO_NET_F_CSUM)
            && !features.contains(NetworkFeatures::VIRTIO_NET_F_GUEST_CSUM)
    );
    caps.checksum.tcp = Checksum::Both;
    caps.checksum.udp = Checksum::Both;
    caps.checksum.ipv4 = Checksum::Both;
    caps.checksum.icmpv4 = Checksum::Both;

    caps
}

impl AnyNetworkDevice for NetworkDevice {
    fn mac_addr(&self) -> EthernetAddress {
        self.mac_addr
    }

    fn capabilities(&self) -> DeviceCapabilities {
        self.caps.clone()
    }

    fn can_receive(&self) -> bool {
        self.recv_queue.can_pop()
    }

    fn can_send(&self) -> bool {
        self.send_queue.available_desc() >= 1
    }

    fn receive(&mut self) -> Result<RxPacket<LinkLayer>, NetError> {
        self.receive()
    }

    fn send(&mut self, packet: TxPacket<LinkLayer>) -> Result<(), NetError> {
        self.send(packet)
    }

    fn alloc_tx_buffer(payload_len: usize) -> Result<FreshTxPacket, ostd::Error> {
        if payload_len > const { TX_BUFFER_LEN - ApplicationLayer::HEAD_ROOM_SIZE } {
            return Err(ostd::Error::InvalidArgs);
        }
        FreshTxPacket::alloc_from_pool(TX_BUFFER_POOL.get().unwrap())
    }

    fn free_processed_tx_buffers(&mut self) {
        while let Ok((token, _)) = self.send_queue.pop_used() {
            self.tx_buffers[token as usize] = None;
        }
    }

    fn notify_poll_end(&mut self) {
        self.notify_send_queue();
        self.notify_receive_queue();
    }
}

impl Debug for NetworkDevice {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("NetworkDevice")
            .field("config", &self.config_manager.read_config())
            .field("mac_addr", &self.mac_addr)
            .field("send_queue", &self.send_queue)
            .field("recv_queue", &self.recv_queue)
            .field("transport", &self.transport)
            .finish()
    }
}

const QUEUE_RECV: u16 = 0;
const QUEUE_SEND: u16 = 1;

const QUEUE_SIZE: u16 = 64;

#[cfg(ktest)]
#[path = "tx_completion_test.rs"]
mod tx_completion_test;
