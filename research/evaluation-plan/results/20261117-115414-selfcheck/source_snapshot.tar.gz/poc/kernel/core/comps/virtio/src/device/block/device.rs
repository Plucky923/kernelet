// SPDX-License-Identifier: MPL-2.0

use alloc::{boxed::Box, collections::BTreeMap, string::String, sync::Arc, vec::Vec};
use core::{
    fmt::Debug,
    sync::atomic::{AtomicU32, AtomicUsize, Ordering},
};

use aster_block::{
    BlockDeviceMeta, PartitionManager,
    bio::{BioEnqueueError, BioStatus, BioType, SubmittedBio, bio_segment_pool_init},
    request_queue::{BioRequest, BioRequestSingleQueue},
};
use aster_util::mem_obj_slice::Slice;
use device_id::{DeviceId, MinorId};
use ostd::{
    arch::trap::TrapFrame,
    debug, info,
    mm::{PAGE_SIZE, VmIo, dma::DmaStream},
    sync::SpinLock,
};

use super::{BlockConfigManager, BlockFeatures, VirtioBlockConfig};
use crate::{
    VIRTIO_BLOCK_MAJOR_ID,
    device::{
        VirtioDeviceError,
        block::{ReqType, RespStatus},
    },
    dma_buf::DmaBuf,
    id_alloc::SyncIdAlloc,
    queue::VirtQueue,
    transport::DeviceTransport,
};

/// The number of virtio block devices, used to assign minor device numbers.
static NR_BLOCK_DEVICE: AtomicU32 = AtomicU32::new(0);

#[derive(Debug)]
pub struct BlockDevice {
    device: Arc<DeviceInner>,
    /// The software staging queue.
    queue: BioRequestSingleQueue,
    id: DeviceId,
    name: String,
    partition_manager: PartitionManager,
}

impl BlockDevice {
    /// Returns the formatted device name.
    ///
    /// The device name starts at "vda". The 26th device is "vdz" and the 27th is "vdaa".
    /// The last one for two lettered suffix is "vdzz" which is followed by "vdaaa".
    fn formatted_device_name(mut index: u32) -> String {
        const VIRTIO_DISK_PREFIX: &str = "vd";

        let mut suffix = Vec::new();
        loop {
            suffix.push((b'a' + (index % 26) as u8) as char);
            index /= 26;
            if index == 0 {
                break;
            }
            index -= 1;
        }
        suffix.reverse();
        let mut name = String::from(VIRTIO_DISK_PREFIX);
        name.extend(suffix);
        name
    }

    /// Creates a new VirtIO-Block driver and registers it.
    pub(crate) fn init(device_transport: DeviceTransport) -> Result<(), VirtioDeviceError> {
        let device = DeviceInner::init(device_transport)?;

        let index = NR_BLOCK_DEVICE.fetch_add(1, Ordering::Relaxed);
        let id = DeviceId::new(
            VIRTIO_BLOCK_MAJOR_ID.get().unwrap().get(),
            MinorId::new(index * aster_block::DEVICE_MINORS),
        );
        let name = Self::formatted_device_name(index);

        let block_device = Arc::new(BlockDevice {
            device,
            // Each bio request includes an additional 1 request and 1 response descriptor,
            // therefore this upper bound is set to (QUEUE_SIZE - 2).
            queue: BioRequestSingleQueue::with_max_nr_segments_per_bio(
                (DeviceInner::QUEUE_SIZE - 2) as usize,
            ),
            id,
            name,
            partition_manager: PartitionManager::new(),
        });

        aster_block::register(block_device).unwrap();

        bio_segment_pool_init();
        Ok(())
    }

    /// Dequeues a `BioRequest` from the software staging queue and
    /// processes the request.
    pub fn handle_requests(&self) {
        let request = self.queue.dequeue();
        debug!("Handle Request: {:?}", request);
        match request.type_() {
            BioType::Read => self.device.read(request),
            BioType::Write => self.device.write(request),
            BioType::Flush => self.device.flush(request),
        }
    }

    /// Negotiate features for the device specified bits 0~23
    pub(crate) fn negotiate_features(device_features: u64) -> u64 {
        BlockFeatures::negotiated_with_device(device_features).bits()
    }
}

impl aster_block::BlockDevice for BlockDevice {
    fn enqueue(&self, bio: SubmittedBio) -> Result<(), BioEnqueueError> {
        self.queue.enqueue(bio)
    }

    fn metadata(&self) -> BlockDeviceMeta {
        BlockDeviceMeta {
            max_nr_segments_per_bio: self.queue.max_nr_segments_per_bio(),
            nr_sectors: self.device.capacity_sectors.load(Ordering::Relaxed),
        }
    }

    fn name(&self) -> &str {
        &self.name
    }

    fn id(&self) -> DeviceId {
        self.id
    }

    fn partition_manager(&self) -> Option<&PartitionManager> {
        Some(&self.partition_manager)
    }
}

#[derive(Debug)]
struct DeviceInner {
    config_manager: BlockConfigManager,
    capacity_sectors: AtomicUsize,
    features: BlockFeatures,
    queue: SpinLock<VirtQueue>,
    transport: SpinLock<DeviceTransport>,
    block_requests: Arc<DmaStream>,
    block_responses: Arc<DmaStream>,
    id_allocator: SyncIdAlloc,
    submitted_requests: SpinLock<BTreeMap<u16, SubmittedRequest>>,
}

impl DeviceInner {
    const QUEUE_SIZE: u16 = 64;

    /// Creates and inits the device.
    fn init(mut device_transport: DeviceTransport) -> Result<Arc<Self>, VirtioDeviceError> {
        let config_manager = VirtioBlockConfig::new_manager(device_transport.as_ref());

        let config = config_manager.read_config();
        debug!("virio_blk_config = {:?}", config);

        let features =
            BlockFeatures::negotiated_with_device(device_transport.read_device_features());

        let block_size = if features.contains(BlockFeatures::BLK_SIZE) {
            config_manager.block_size()
        } else {
            // Fall back to standard sector size SECTOR_SIZE (512 bytes)
            // Reference:
            // <https://docs.oasis-open.org/virtio/virtio/v1.2/virtio-v1.2.html#x1-2790004>
            VirtioBlockConfig::sector_size()
        };
        if block_size != VirtioBlockConfig::sector_size() {
            ostd::error!("block size {} is not supported yet", block_size);
            return Err(VirtioDeviceError::UnsupportedConfig);
        }

        let num_queues = device_transport.num_queues();
        if num_queues != 1 {
            // TODO: Support Multi-Queue Block IO Queueing Mechanism
            // (`BlkFeatures::MQ`) to accelerate multi-processor requests for
            // block devices. When SMP is enabled on x86, the feature is on.
            ostd::warn!(
                "Multi-Queue Block IO Queueing Mechanism is not supported yet; using the first queue"
            );
        }

        let queue = VirtQueue::new(0, Self::QUEUE_SIZE, device_transport.as_mut())?;

        let block_requests =
            Arc::new(DmaStream::alloc(1, false).map_err(VirtioDeviceError::ResourceAlloc)?);
        let block_responses =
            Arc::new(DmaStream::alloc(1, false).map_err(VirtioDeviceError::ResourceAlloc)?);
        const {
            assert!(Self::QUEUE_SIZE as usize * REQ_SIZE <= PAGE_SIZE);
            assert!(Self::QUEUE_SIZE as usize * RESP_SIZE <= PAGE_SIZE);
        }

        let device = Arc::new(Self {
            config_manager,
            capacity_sectors: AtomicUsize::new(config.capacity as usize),
            features,
            queue: SpinLock::new(queue),
            transport: SpinLock::new(device_transport),
            block_requests,
            block_responses,
            id_allocator: SyncIdAlloc::with_capacity(Self::QUEUE_SIZE as usize),
            submitted_requests: SpinLock::new(BTreeMap::new()),
        });

        let cloned_device = device.clone();
        let handle_irq_fn = move |_: &TrapFrame| {
            cloned_device.handle_irq();
        };

        let cloned_device = device.clone();
        let handle_config_change_fn = move |_: &TrapFrame| {
            cloned_device.handle_config_change();
        };

        {
            let mut transport = device.transport.disable_irq().lock();
            transport.register_cfg_callback(Box::new(handle_config_change_fn))?;
            transport.register_queue_callback(0, Box::new(handle_irq_fn), false)?;
            transport.finish_init();
            // Refresh after DRIVER_OK, when subsequent configuration changes
            // are notified. Local IRQs stay disabled until this store finishes.
            device
                .capacity_sectors
                .store(device.config_manager.capacity_sectors(), Ordering::Relaxed);
        }

        Ok(device)
    }

    /// Handles the IRQ issued from the device.
    fn handle_irq(&self) {
        debug!("block device handle IRQ");
        // When we enter the IRQs handling function,
        // IRQs have already been disabled,
        // so there is no need to call `disable_irq`.
        loop {
            // Pops the complete request
            let complete_request = {
                let mut queue = self.queue.lock();
                let Ok((token, _)) = queue.pop_used_with_min_bytes(RESP_SIZE) else {
                    return;
                };
                self.submitted_requests.lock().remove(&token).unwrap()
            };

            // Handles the response
            let id = complete_request.id as usize;
            let resp_slice =
                Slice::new(&self.block_responses, id * RESP_SIZE..(id + 1) * RESP_SIZE);
            resp_slice.sync_from_device().unwrap();
            let resp: BlockResp = resp_slice.read_val(0).unwrap();
            self.id_allocator.dealloc(id);
            match RespStatus::try_from(resp.status) {
                Ok(RespStatus::Ok) => {}
                _ => {
                    // Completes the bio request with an error
                    complete_request.bio_request.into_bios().for_each(|bio| {
                        bio.complete(BioStatus::IoError);
                    });
                    continue;
                }
            };

            // Synchronize DMA mapping if read from the device
            if let BioType::Read = complete_request.bio_request.type_() {
                complete_request
                    .bio_request
                    .bios()
                    .flat_map(|bio| bio.segments().iter().map(|segment| segment.dma_slice()))
                    .for_each(|dma_slice| {
                        dma_slice
                            .mem_obj()
                            .sync_from_device(dma_slice.offset().clone())
                            .unwrap()
                    });
            }

            // Completes the bio request
            complete_request.bio_request.into_bios().for_each(|bio| {
                bio.complete(BioStatus::Complete);
            });
        }
    }

    fn handle_config_change(&self) {
        // Capacity changes arrive through the configuration interrupt. Ordinary
        // metadata queries must not perform PCI device-register reads per I/O.
        self.capacity_sectors
            .store(self.config_manager.capacity_sectors(), Ordering::Relaxed);
        info!("block device config space change");
    }

    /// Reads data from the device, this function is non-blocking.
    fn read(&self, bio_request: BioRequest) {
        let id = self.id_allocator.alloc();
        let req_slice = {
            let req_slice = Slice::new(
                self.block_requests.clone(),
                id * REQ_SIZE..(id + 1) * REQ_SIZE,
            );
            let req = BlockReq {
                type_: ReqType::In as _,
                reserved: 0,
                sector: bio_request.sid_range().start.to_raw(),
            };
            req_slice.write_val(0, &req).unwrap();
            req_slice.sync_to_device().unwrap();
            req_slice
        };

        let resp_slice = {
            let resp_slice = Slice::new(
                self.block_responses.clone(),
                id * RESP_SIZE..(id + 1) * RESP_SIZE,
            );
            resp_slice.write_val(0, &BlockResp::default()).unwrap();
            resp_slice.sync_to_device().unwrap();
            resp_slice
        };

        let outputs = {
            let mut outputs: Vec<&dyn DmaBuf> = Vec::with_capacity(bio_request.num_segments() + 1);
            let dma_slices_iter = bio_request.bios().flat_map(|bio| {
                bio.segments()
                    .iter()
                    .map(|segment| segment.dma_slice() as &dyn DmaBuf)
            });
            outputs.extend(dma_slices_iter);
            outputs.push(&resp_slice);
            outputs
        };

        let num_used_descs = outputs.len() + 1;
        // FIXME: Split the request if it is too big
        if num_used_descs > Self::QUEUE_SIZE as usize {
            panic!("The request size surpasses the queue size");
        }

        loop {
            let mut queue = self.queue.disable_irq().lock();
            if num_used_descs > queue.available_desc() {
                continue;
            }
            let token = queue
                .add_dma_bufs(&[&req_slice], outputs.as_slice())
                .expect("add queue failed");
            if queue.should_notify() {
                queue.notify();
            }

            // Records the submitted request
            let submitted_request = SubmittedRequest::new(id as u16, bio_request);
            self.submitted_requests
                .disable_irq()
                .lock()
                .insert(token, submitted_request);
            return;
        }
    }

    /// Writes data to the device, this function is non-blocking.
    fn write(&self, bio_request: BioRequest) {
        let id = self.id_allocator.alloc();
        let req_slice = {
            let req_slice = Slice::new(
                self.block_requests.clone(),
                id * REQ_SIZE..(id + 1) * REQ_SIZE,
            );
            let req = BlockReq {
                type_: ReqType::Out as _,
                reserved: 0,
                sector: bio_request.sid_range().start.to_raw(),
            };
            req_slice.write_val(0, &req).unwrap();
            req_slice.sync_to_device().unwrap();
            req_slice
        };

        let resp_slice = {
            let resp_slice = Slice::new(
                self.block_responses.clone(),
                id * RESP_SIZE..(id + 1) * RESP_SIZE,
            );
            resp_slice.write_val(0, &BlockResp::default()).unwrap();
            resp_slice.sync_to_device().unwrap();
            resp_slice
        };

        let inputs = {
            let mut inputs: Vec<&dyn DmaBuf> = Vec::with_capacity(bio_request.num_segments() + 1);
            inputs.push(&req_slice);
            for dma_slice in bio_request
                .bios()
                .flat_map(|bio| bio.segments().iter().map(|segment| segment.dma_slice()))
            {
                dma_slice
                    .mem_obj()
                    .sync_to_device(dma_slice.offset().clone())
                    .unwrap();
                inputs.push(dma_slice as &dyn DmaBuf);
            }
            inputs
        };

        let num_used_descs = inputs.len() + 1;
        // FIXME: Split the request if it is too big
        if num_used_descs > Self::QUEUE_SIZE as usize {
            panic!("The request size surpasses the queue size");
        }
        loop {
            let mut queue = self.queue.disable_irq().lock();
            if num_used_descs > queue.available_desc() {
                continue;
            }
            let token = queue
                .add_dma_bufs(inputs.as_slice(), &[&resp_slice])
                .expect("add queue failed");
            if queue.should_notify() {
                queue.notify();
            }

            // Records the submitted request
            let submitted_request = SubmittedRequest::new(id as u16, bio_request);
            self.submitted_requests
                .disable_irq()
                .lock()
                .insert(token, submitted_request);
            return;
        }
    }

    /// Flushes any cached data from the guest to the persistent storage on the host.
    /// This will be ignored if the device doesn't support the `VIRTIO_BLK_F_FLUSH` feature.
    fn flush(&self, bio_request: BioRequest) {
        if !self.features.contains(BlockFeatures::FLUSH) {
            bio_request.into_bios().for_each(|bio| {
                bio.complete(BioStatus::Complete);
            });
            return;
        }

        let id = self.id_allocator.alloc();
        let req_slice = {
            let req_slice = Slice::new(&self.block_requests, id * REQ_SIZE..(id + 1) * REQ_SIZE);
            let req = BlockReq {
                type_: ReqType::Flush as _,
                reserved: 0,
                sector: bio_request.sid_range().start.to_raw(),
            };
            req_slice.write_val(0, &req).unwrap();
            req_slice.sync_to_device().unwrap();
            req_slice
        };

        let resp_slice = {
            let resp_slice =
                Slice::new(&self.block_responses, id * RESP_SIZE..(id + 1) * RESP_SIZE);
            resp_slice.write_val(0, &BlockResp::default()).unwrap();
            resp_slice.sync_to_device().unwrap();
            resp_slice
        };

        // One descriptor for the input `req_slice`, one for the output `resp_slice`.
        let num_used_descs = 2;
        loop {
            let mut queue = self.queue.disable_irq().lock();
            if num_used_descs > queue.available_desc() {
                continue;
            }
            let token = queue
                .add_dma_bufs(&[&req_slice], &[&resp_slice])
                .expect("add queue failed");
            if queue.should_notify() {
                queue.notify();
            }

            // Records the submitted request
            let submitted_request = SubmittedRequest::new(id as u16, bio_request);
            self.submitted_requests
                .disable_irq()
                .lock()
                .insert(token, submitted_request);
            return;
        }
    }
}

/// A submitted bio request for callback.
#[derive(Debug)]
struct SubmittedRequest {
    id: u16,
    bio_request: BioRequest,
}

impl SubmittedRequest {
    fn new(id: u16, bio_request: BioRequest) -> Self {
        Self { id, bio_request }
    }
}

/// VirtIOBlock request.
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod)]
struct BlockReq {
    type_: u32,
    reserved: u32,
    sector: u64,
}

const REQ_SIZE: usize = size_of::<BlockReq>();

/// Response of a VirtIOBlock request.
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod)]
struct BlockResp {
    pub status: u8,
}

const RESP_SIZE: usize = size_of::<BlockResp>();

impl Default for BlockResp {
    fn default() -> Self {
        Self {
            status: RespStatus::_NotReady as _,
        }
    }
}
