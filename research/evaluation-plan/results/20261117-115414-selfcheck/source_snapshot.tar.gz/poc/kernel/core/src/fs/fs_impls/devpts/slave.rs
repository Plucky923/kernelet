// SPDX-License-Identifier: MPL-2.0

#![expect(dead_code)]
#![expect(unused_variables)]

use core::time::Duration;

use super::{BLOCK_SIZE, DevPts, FIRST_SLAVE_INO};
use crate::{
    device::{Device, PtySlave},
    fs::{
        file::{AccessMode, InodeMode, InodeType, PerOpenFileOps, StatusFlags, mkmod},
        vfs::{
            file_system::FileSystem,
            inode::{Extension, FileOps, Inode, Metadata},
            path::Dentry,
        },
    },
    prelude::*,
    process::{Gid, Uid},
};

/// Same major number with Linux, the minor number is the index of slave.
const SLAVE_MAJOR_NUM: u32 = 3;

/// Pty slave inode for the slave device.
pub(crate) struct PtySlaveInode {
    device: Arc<PtySlave>,
    metadata: RwLock<Metadata>,
    extension: Extension,
    fs: Weak<DevPts>,
}

impl PtySlaveInode {
    pub(crate) fn new(device: Arc<PtySlave>, fs: Weak<DevPts>) -> Arc<Self> {
        let devpts = fs.upgrade().unwrap();
        let metadata = Metadata::new_device(
            device.index() as u64 + FIRST_SLAVE_INO,
            mkmod!(u+rw, g+w),
            BLOCK_SIZE,
            device.as_ref(),
            devpts.sb().container_dev_id,
        );
        Arc::new(Self {
            device,
            metadata: RwLock::new(metadata),
            extension: Extension::new(),
            fs,
        })
    }
}

impl FileOps for PtySlaveInode {
    fn read_at(
        &self,
        _offset: usize,
        writer: &mut VmWriter,
        status_flags: StatusFlags,
    ) -> Result<usize> {
        self.device.read(writer, status_flags)
    }

    fn write_at(
        &self,
        _offset: usize,
        reader: &mut VmReader,
        status_flags: StatusFlags,
    ) -> Result<usize> {
        self.device.write(reader, status_flags)
    }
}

impl Inode for PtySlaveInode {
    fn size(&self) -> usize {
        self.metadata.read().size
    }

    fn resize(&self, _self_dentry: &Dentry, new_size: usize) -> Result<()> {
        Err(Error::new(Errno::EPERM))
    }

    fn metadata(&self) -> Result<Metadata> {
        Ok(*self.metadata.read())
    }

    fn extension(&self) -> &Extension {
        &self.extension
    }

    fn ino(&self) -> u64 {
        self.metadata.read().ino as _
    }

    fn type_(&self) -> InodeType {
        self.metadata.read().type_
    }

    fn mode(&self) -> Result<InodeMode> {
        Ok(self.metadata.read().mode)
    }

    fn set_mode(&self, _self_dentry: &Dentry, mode: InodeMode) -> Result<()> {
        self.metadata.write().mode = mode;
        Ok(())
    }

    fn owner(&self) -> Result<Uid> {
        Ok(self.metadata.read().uid)
    }

    fn set_owner(&self, _self_dentry: &Dentry, uid: Uid) -> Result<()> {
        self.metadata.write().uid = uid;
        Ok(())
    }

    fn group(&self) -> Result<Gid> {
        Ok(self.metadata.read().gid)
    }

    fn set_group(&self, _self_dentry: &Dentry, gid: Gid) -> Result<()> {
        self.metadata.write().gid = gid;
        Ok(())
    }

    fn atime(&self) -> Duration {
        self.metadata.read().last_access_at
    }

    fn set_atime(&self, _self_dentry: &Dentry, time: Duration) {
        self.metadata.write().last_access_at = time;
    }

    fn mtime(&self) -> Duration {
        self.metadata.read().last_modify_at
    }

    fn set_mtime(&self, _self_dentry: &Dentry, time: Duration) {
        self.metadata.write().last_modify_at = time;
    }

    fn ctime(&self) -> Duration {
        self.metadata.read().last_meta_change_at
    }

    fn set_ctime(&self, _self_dentry: &Dentry, time: Duration) {
        self.metadata.write().last_meta_change_at = time;
    }

    fn fs(&self) -> Arc<dyn FileSystem> {
        self.fs.upgrade().unwrap()
    }

    fn open(
        &self,
        _self_dentry: &Dentry,
        access_mode: AccessMode,
        status_flags: StatusFlags,
    ) -> Option<Result<Box<dyn PerOpenFileOps>>> {
        Some(self.device.open())
    }
}
