// SPDX-License-Identifier: MPL-2.0

#![expect(unused_variables)]

use core::time::Duration;

use aster_util::slot_vec::SlotVec;
use id_alloc::IdAlloc;

pub(crate) use self::ptmx::Ptmx;
use self::slave::PtySlaveInode;
use crate::{
    device::PtyMaster,
    fs::{
        file::{InodeMode, InodeType, StatusFlags, mkmod},
        pseudofs::AnonDeviceId,
        utils::{DirEntryVecExt, DirentVisitor, NAME_MAX},
        vfs::{
            file_system::{FileSystem, FsEventSubscriberStats, SuperBlock},
            inode::{
                Extension, FileOps, Inode, Metadata, MknodType, RenameMode, RevalidationPolicy,
            },
            path::Dentry,
            registry::{FsCreationCtx, FsProperties, FsType},
        },
    },
    prelude::*,
    process::{Gid, Uid},
};

mod ptmx;
mod slave;

const DEVPTS_MAGIC: u64 = 0x1cd1;
const BLOCK_SIZE: usize = 1024;

const ROOT_INO: u64 = 1;
const PTMX_INO: u64 = 2;
const FIRST_SLAVE_INO: u64 = 3;

/// The max number of pty pairs.
const MAX_PTY_NUM: usize = 4096;

/// Devpts(device pseudo terminal filesystem) is a virtual filesystem.
///
/// It is normally mounted at "/dev/pts" and contains solely devices files which
/// represent slaves to the multiplexing master located at "/dev/ptmx".
///
/// Actually, the "/dev/ptmx" is a symlink to the real device at "/dev/pts/ptmx".
pub(crate) struct DevPts {
    _anon_device_id: AnonDeviceId,
    sb: SuperBlock,
    root: Arc<RootInode>,
    index_alloc: Mutex<IdAlloc>,
    fs_event_subscriber_stats: FsEventSubscriberStats,
    this: Weak<Self>,
}

impl DevPts {
    pub(crate) fn new() -> Arc<Self> {
        let anon_device_id = AnonDeviceId::acquire().expect("no device ID is available for devpts");
        let sb = SuperBlock::new(DEVPTS_MAGIC, BLOCK_SIZE, NAME_MAX, anon_device_id.id());
        Arc::new_cyclic(|weak_self| Self {
            _anon_device_id: anon_device_id,
            sb: sb.clone(),
            root: RootInode::new(weak_self.clone(), &sb),
            index_alloc: Mutex::new(IdAlloc::with_capacity(MAX_PTY_NUM)),
            fs_event_subscriber_stats: FsEventSubscriberStats::new(),
            this: weak_self.clone(),
        })
    }

    /// Create the master and slave pair.
    fn create_master_slave_pair(&self) -> Result<(Box<PtyMaster>, Arc<PtySlaveInode>)> {
        let index = self
            .index_alloc
            .lock()
            .alloc()
            .ok_or_else(|| Error::with_message(Errno::EIO, "cannot alloc index"))?;

        let (master, slave) = crate::device::new_pty_pair(index as u32, self.root.ptmx.clone())?;

        let slave_inode = PtySlaveInode::new(slave, self.this.clone());
        self.root
            .slaves
            .write()
            .put_entry_if_not_found(&index.to_string(), || slave_inode.clone());

        Ok((master, slave_inode))
    }

    /// Remove the slave from fs.
    ///
    /// This is called when the master is being dropped.
    pub(crate) fn remove_slave(&self, index: u32) -> Option<Arc<dyn Inode>> {
        let (_, removed_slave) = self
            .root
            .slaves
            .write()
            .remove_entry_by_name(&index.to_string())?;
        self.index_alloc.lock().free(index as usize);
        Some(removed_slave)
    }
}

impl FileSystem for DevPts {
    fn name(&self) -> &'static str {
        "devpts"
    }

    fn sync(&self) -> Result<()> {
        Ok(())
    }

    fn root_inode(&self) -> Arc<dyn Inode> {
        self.root.clone()
    }

    fn sb(&self) -> SuperBlock {
        self.sb.clone()
    }

    fn fs_event_subscriber_stats(&self) -> &FsEventSubscriberStats {
        &self.fs_event_subscriber_stats
    }
}

struct DevPtsType;

impl FsType for DevPtsType {
    type Key = ();

    fn name(&self) -> &'static str {
        "devpts"
    }

    fn properties(&self) -> FsProperties {
        FsProperties::empty()
    }

    fn create(&self, _fs_creation_ctx: &mut FsCreationCtx) -> Result<Arc<dyn FileSystem>> {
        Ok(DevPts::new())
    }

    fn sysnode(&self) -> Option<Arc<dyn aster_systree::SysNode>> {
        None
    }
}

pub(super) fn init() {
    crate::fs::vfs::registry::register(&DevPtsType).unwrap();
}

struct RootInode {
    ptmx: Arc<Ptmx>,
    slaves: RwLock<SlotVec<(String, Arc<dyn Inode>)>>,
    metadata: RwLock<Metadata>,
    extension: Extension,
    fs: Weak<DevPts>,
}

impl RootInode {
    pub(crate) fn new(fs: Weak<DevPts>, sb: &SuperBlock) -> Arc<Self> {
        Arc::new(Self {
            ptmx: Ptmx::new(fs.clone(), sb),
            slaves: RwLock::new(SlotVec::new()),
            metadata: RwLock::new(Metadata::new_dir(
                ROOT_INO,
                mkmod!(a+rx, u+w),
                BLOCK_SIZE,
                sb.container_dev_id,
            )),
            extension: Extension::new(),
            fs,
        })
    }
}

impl FileOps for RootInode {
    fn read_at(
        &self,
        _offset: usize,
        _writer: &mut VmWriter,
        _status_flags: StatusFlags,
    ) -> Result<usize> {
        Err(Error::new(Errno::EISDIR))
    }

    fn write_at(
        &self,
        _offset: usize,
        _reader: &mut VmReader,
        _status_flags: StatusFlags,
    ) -> Result<usize> {
        Err(Error::new(Errno::EISDIR))
    }

    fn readdir_at(&self, offset: usize, visitor: &mut dyn DirentVisitor) -> Result<usize> {
        let try_readdir = |offset: &mut usize, visitor: &mut dyn DirentVisitor| -> Result<()> {
            // Read the 3 special entries.
            if *offset == 0 {
                visitor.visit(".", self.ino(), self.type_(), *offset)?;
                *offset += 1;
            }
            if *offset == 1 {
                visitor.visit("..", self.ino(), self.type_(), *offset)?;
                *offset += 1;
            }
            if *offset == 2 {
                visitor.visit("ptmx", self.ptmx.ino(), self.ptmx.type_(), *offset)?;
                *offset += 1;
            }

            // Read the slaves.
            let slaves = self.slaves.read();
            let start_offset = *offset;
            for (idx, (name, node)) in slaves
                .idxes_and_items()
                .map(|(idx, (name, node))| (idx + 3, (name, node)))
                .skip_while(|(idx, _)| idx < &start_offset)
            {
                visitor.visit(name.as_ref(), node.ino(), node.type_(), idx)?;
                *offset = idx + 1;
            }
            Ok(())
        };

        let mut iterate_offset = offset;
        match try_readdir(&mut iterate_offset, visitor) {
            Err(e) if offset == iterate_offset => Err(e),
            _ => Ok(iterate_offset - offset),
        }
    }
}

impl Inode for RootInode {
    fn size(&self) -> usize {
        self.metadata.read().size
    }

    fn resize(&self, _self_dentry: &Dentry, new_size: usize) -> Result<()> {
        Err(Error::new(Errno::EISDIR))
    }

    fn metadata(&self) -> Result<Metadata> {
        Ok(*self.metadata.read())
    }

    fn extension(&self) -> &Extension {
        &self.extension
    }

    fn ino(&self) -> u64 {
        self.metadata.read().ino as _
    }

    fn type_(&self) -> InodeType {
        self.metadata.read().type_
    }

    fn mode(&self) -> Result<InodeMode> {
        Ok(self.metadata.read().mode)
    }

    fn set_mode(&self, _self_dentry: &Dentry, mode: InodeMode) -> Result<()> {
        self.metadata.write().mode = mode;
        Ok(())
    }

    fn owner(&self) -> Result<Uid> {
        Ok(self.metadata.read().uid)
    }

    fn set_owner(&self, _self_dentry: &Dentry, uid: Uid) -> Result<()> {
        self.metadata.write().uid = uid;
        Ok(())
    }

    fn group(&self) -> Result<Gid> {
        Ok(self.metadata.read().gid)
    }

    fn set_group(&self, _self_dentry: &Dentry, gid: Gid) -> Result<()> {
        self.metadata.write().gid = gid;
        Ok(())
    }

    fn atime(&self) -> Duration {
        self.metadata.read().last_access_at
    }

    fn set_atime(&self, _self_dentry: &Dentry, time: Duration) {
        self.metadata.write().last_access_at = time;
    }

    fn mtime(&self) -> Duration {
        self.metadata.read().last_modify_at
    }

    fn set_mtime(&self, _self_dentry: &Dentry, time: Duration) {
        self.metadata.write().last_modify_at = time;
    }

    fn ctime(&self) -> Duration {
        self.metadata.read().last_meta_change_at
    }

    fn set_ctime(&self, _self_dentry: &Dentry, time: Duration) {
        self.metadata.write().last_meta_change_at = time;
    }

    fn create(
        &self,
        _self_dentry: &Dentry,
        name: &str,
        type_: InodeType,
        mode: InodeMode,
    ) -> Result<Arc<dyn Inode>> {
        Err(Error::new(Errno::EPERM))
    }

    fn mknod(
        &self,
        _self_dentry: &Dentry,
        name: &str,
        mode: InodeMode,
        type_: MknodType,
    ) -> Result<Arc<dyn Inode>> {
        Err(Error::new(Errno::EPERM))
    }

    fn link(&self, _self_dentry: &Dentry, _old_dentry: &Dentry, _name: &str) -> Result<()> {
        Err(Error::new(Errno::EPERM))
    }

    fn unlink(&self, child_dentry: &Dentry) -> Result<()> {
        let name = child_dentry.name();
        match name.as_str() {
            "." | ".." => {
                return_errno_with_message!(Errno::EISDIR, "the devpts directory cannot be unlinked")
            }
            "ptmx" => return_errno_with_message!(Errno::EPERM, "the ptmx inode cannot be unlinked"),
            slave => {
                if self.slaves.read().find_entry_by_name(slave).is_none() {
                    return_errno_with_message!(Errno::ENOENT, "the slave inode does not exist");
                }
                return_errno_with_message!(Errno::EPERM, "the slave inode cannot be unlinked");
            }
        }
    }

    fn rmdir(&self, _child_dentry: &Dentry) -> Result<()> {
        Err(Error::new(Errno::EPERM))
    }

    fn lookup(&self, name: &str) -> Result<Arc<dyn Inode>> {
        let inode = match name {
            "." | ".." => self.fs().root_inode(),
            // Call the "open" method of ptmx to create a master and slave pair.
            "ptmx" => self.ptmx.clone(),
            slave => self
                .slaves
                .read()
                .find_entry_by_name(slave)
                .cloned()
                .ok_or(Error::new(Errno::ENOENT))?,
        };
        Ok(inode)
    }

    fn rename(
        &self,
        _old_child_dentry: &Dentry,
        _new_dir_dentry: &Dentry,
        _new_name: &str,
        _replaced_inode: Option<&Arc<dyn Inode>>,
        _mode: RenameMode,
    ) -> Result<()> {
        Err(Error::new(Errno::EPERM))
    }

    fn fs(&self) -> Arc<dyn FileSystem> {
        self.fs.upgrade().unwrap()
    }

    fn revalidation_policy(&self) -> RevalidationPolicy {
        RevalidationPolicy::REVALIDATE_EXISTS | RevalidationPolicy::REVALIDATE_ABSENT
    }

    fn revalidate_exists(&self, _name: &str, _child: &dyn Inode) -> bool {
        // Slave entries are created by opening `ptmx` and removed when the
        // master is dropped, bypassing VFS dentry updates. Always retry lookup
        // so a cached dentry cannot refer to a removed or reused pty index.
        //
        // TODO: Add a devpts-to-VFS dentry invalidation/update path for slave
        // add/remove, similar to Linux devpts dropping slave dentries on pty
        // teardown. Then this conservative revalidation can be relaxed.
        false
    }

    fn revalidate_absent(&self, _name: &str) -> bool {
        false
    }
}
