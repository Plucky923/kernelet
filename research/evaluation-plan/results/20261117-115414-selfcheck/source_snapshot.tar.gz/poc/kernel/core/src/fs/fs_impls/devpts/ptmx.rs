// SPDX-License-Identifier: MPL-2.0

use core::time::Duration;

use device_id::{DeviceId, MajorId, MinorId};

use super::{BLOCK_SIZE, DevPts, PTMX_INO};
use crate::{
    device::{Device, DeviceType},
    fs::{
        devtmpfs::DevtmpfsNodeMeta,
        file::{AccessMode, InodeMode, InodeType, PerOpenFileOps, StatusFlags, mkmod},
        vfs::{
            file_system::{FileSystem, SuperBlock},
            inode::{Extension, FileOps, Inode, Metadata},
            path::Dentry,
        },
    },
    prelude::*,
    process::{Gid, Uid},
};

/// Same major number with Linux.
const PTMX_MAJOR_NUM: u16 = 5;
/// Same minor number with Linux.
const PTMX_MINOR_NUM: u32 = 2;

/// Ptmx is the multiplexing master of devpts.
///
/// Every time the multiplexing master is opened, a new instance of pty master inode is returned
/// and an corresponding pty slave inode is also created.
pub(crate) struct Ptmx {
    inner: Inner,
    metadata: RwLock<Metadata>,
    extension: Extension,
}

#[derive(Clone)]
struct Inner(Weak<DevPts>);

impl Ptmx {
    pub(crate) fn new(fs: Weak<DevPts>, sb: &SuperBlock) -> Arc<Self> {
        let inner = Inner(fs.clone());
        let metadata = Metadata::new_device(
            PTMX_INO,
            mkmod!(a+rw),
            BLOCK_SIZE,
            &inner,
            sb.container_dev_id,
        );
        Arc::new(Self {
            inner,
            metadata: RwLock::new(metadata),
            extension: Extension::new(),
        })
    }

    pub(crate) fn devpts(&self) -> Option<Arc<DevPts>> {
        self.inner.0.upgrade()
    }
}

// Many methods are left to do nothing because every time the ptmx is being opened,
// it returns the pty master. So the ptmx can not be used at upper layer.
impl FileOps for Ptmx {
    fn read_at(
        &self,
        _offset: usize,
        _writer: &mut VmWriter,
        _status_flags: StatusFlags,
    ) -> Result<usize> {
        Ok(0)
    }

    fn write_at(
        &self,
        _offset: usize,
        _reader: &mut VmReader,
        _status_flags: StatusFlags,
    ) -> Result<usize> {
        Ok(0)
    }
}

impl Inode for Ptmx {
    fn size(&self) -> usize {
        self.metadata.read().size
    }

    fn resize(&self, _self_dentry: &Dentry, new_size: usize) -> Result<()> {
        Ok(())
    }

    fn metadata(&self) -> Result<Metadata> {
        Ok(*self.metadata.read())
    }

    fn extension(&self) -> &Extension {
        &self.extension
    }

    fn ino(&self) -> u64 {
        self.metadata.read().ino as _
    }

    fn type_(&self) -> InodeType {
        self.metadata.read().type_
    }

    fn mode(&self) -> Result<InodeMode> {
        Ok(self.metadata.read().mode)
    }

    fn set_mode(&self, _self_dentry: &Dentry, mode: InodeMode) -> Result<()> {
        self.metadata.write().mode = mode;
        Ok(())
    }

    fn owner(&self) -> Result<Uid> {
        Ok(self.metadata.read().uid)
    }

    fn set_owner(&self, _self_dentry: &Dentry, uid: Uid) -> Result<()> {
        self.metadata.write().uid = uid;
        Ok(())
    }

    fn group(&self) -> Result<Gid> {
        Ok(self.metadata.read().gid)
    }

    fn set_group(&self, _self_dentry: &Dentry, gid: Gid) -> Result<()> {
        self.metadata.write().gid = gid;
        Ok(())
    }

    fn atime(&self) -> Duration {
        self.metadata.read().last_access_at
    }

    fn set_atime(&self, _self_dentry: &Dentry, time: Duration) {
        self.metadata.write().last_access_at = time;
    }

    fn mtime(&self) -> Duration {
        self.metadata.read().last_modify_at
    }

    fn set_mtime(&self, _self_dentry: &Dentry, time: Duration) {
        self.metadata.write().last_modify_at = time;
    }

    fn ctime(&self) -> Duration {
        self.metadata.read().last_meta_change_at
    }

    fn set_ctime(&self, _self_dentry: &Dentry, time: Duration) {
        self.metadata.write().last_meta_change_at = time;
    }

    fn fs(&self) -> Arc<dyn FileSystem> {
        // FIXME: The below code may panic if the devpts is dropped.
        self.devpts().unwrap()
    }

    fn open(
        &self,
        _self_dentry: &Dentry,
        access_mode: AccessMode,
        status_flags: StatusFlags,
    ) -> Option<Result<Box<dyn PerOpenFileOps>>> {
        Some(self.inner.open())
    }
}

impl Device for Inner {
    fn type_(&self) -> DeviceType {
        DeviceType::Char
    }

    fn id(&self) -> DeviceId {
        DeviceId::new(MajorId::new(PTMX_MAJOR_NUM), MinorId::new(PTMX_MINOR_NUM))
    }

    fn devtmpfs_meta(&self) -> Option<DevtmpfsNodeMeta> {
        None
    }

    fn open(&self) -> Result<Box<dyn PerOpenFileOps>> {
        let devpts = self.0.upgrade().unwrap();
        Ok(devpts.create_master_slave_pair()?.0)
    }
}
