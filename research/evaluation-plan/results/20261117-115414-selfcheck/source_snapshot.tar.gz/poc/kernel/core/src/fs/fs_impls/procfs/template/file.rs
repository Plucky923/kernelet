// SPDX-License-Identifier: MPL-2.0

#![short_vis_path::add(procfs)]

use core::time::Duration;

use inherit_methods_macro::inherit_methods;

use super::Common;
use crate::{
    fs::{
        file::{AccessMode, InodeMode, InodeType, PerOpenFileOps, StatusFlags},
        procfs::{BLOCK_SIZE, ProcFs},
        vfs::{
            file_system::FileSystem,
            inode::{Extension, FileOps, Inode, Metadata, SymbolicLink},
            path::Dentry,
        },
    },
    prelude::*,
    process::{Gid, Uid},
    thread::Thread,
};

pub(in procfs) struct ProcFile<F: ProcFileOps> {
    inner: F,
    common: Common,
}

impl<F: ProcFileOps> ProcFile<F> {
    pub(in procfs) fn new(file: F, parent: Weak<dyn Inode>, mode: InodeMode) -> Arc<Self> {
        let common = {
            let fs = parent.upgrade().unwrap().fs();
            let procfs = fs.downcast_ref::<ProcFs>().unwrap();
            let metadata = Metadata::new_file(
                procfs.alloc_id(),
                mode,
                BLOCK_SIZE,
                procfs.sb().container_dev_id,
            );
            Common::new(metadata, Arc::downgrade(&fs))
        };
        Arc::new(Self {
            inner: file,
            common,
        })
    }

    pub(in procfs) fn inner(&self) -> &F {
        &self.inner
    }
}

impl<F: ProcFileOps + 'static> FileOps for ProcFile<F> {
    fn read_at(
        &self,
        offset: usize,
        writer: &mut VmWriter,
        _status_flags: StatusFlags,
    ) -> Result<usize> {
        self.inner.read_at(offset, writer)
    }

    fn write_at(
        &self,
        offset: usize,
        reader: &mut VmReader,
        _status_flags: StatusFlags,
    ) -> Result<usize> {
        self.inner.write_at(offset, reader)
    }
}

#[inherit_methods(from = "self.common")]
impl<F: ProcFileOps + 'static> Inode for ProcFile<F> {
    fn size(&self) -> usize;
    fn extension(&self) -> &Extension;
    fn ino(&self) -> u64;
    fn mode(&self) -> Result<InodeMode>;
    fn set_mode(&self, self_dentry: &Dentry, mode: InodeMode) -> Result<()>;
    fn owner(&self) -> Result<Uid>;
    fn set_owner(&self, self_dentry: &Dentry, uid: Uid) -> Result<()>;
    fn group(&self) -> Result<Gid>;
    fn set_group(&self, self_dentry: &Dentry, gid: Gid) -> Result<()>;
    fn atime(&self) -> Duration;
    fn set_atime(&self, self_dentry: &Dentry, time: Duration);
    fn mtime(&self) -> Duration;
    fn set_mtime(&self, self_dentry: &Dentry, time: Duration);
    fn ctime(&self) -> Duration;
    fn set_ctime(&self, self_dentry: &Dentry, time: Duration);
    fn fs(&self) -> Arc<dyn FileSystem>;

    fn metadata(&self) -> Result<Metadata> {
        let owner_thread = self.inner.owner_thread();
        Ok(self.common.metadata_with_owner(owner_thread))
    }

    fn resize(&self, _self_dentry: &Dentry, _new_size: usize) -> Result<()> {
        // Resizing files under `/proc` will succeed, but will do nothing.
        Ok(())
    }

    fn type_(&self) -> InodeType {
        InodeType::File
    }

    fn create_symlink(
        &self,
        _self_dentry: &Dentry,
        _name: &str,
        _target: &str,
        _mode: InodeMode,
    ) -> Result<Arc<dyn Inode>> {
        Err(Error::new(Errno::EINVAL))
    }

    fn read_link(&self) -> Result<SymbolicLink> {
        Err(Error::new(Errno::EINVAL))
    }

    fn seek_end(&self) -> Option<usize> {
        // Seeking regular files under `/proc` with `SEEK_END` will fail.
        None
    }

    fn open(
        &self,
        _self_dentry: &Dentry,
        access_mode: AccessMode,
        status_flags: StatusFlags,
    ) -> Option<Result<Box<dyn PerOpenFileOps>>> {
        self.inner.open(access_mode, status_flags)
    }
}

pub(in procfs) trait ProcFileOps: Sync + Send {
    /// Returns the thread whose credentials own this procfs inode.
    fn owner_thread(&self) -> Option<Arc<Thread>> {
        None
    }

    fn read_at(&self, offset: usize, writer: &mut VmWriter) -> Result<usize>;

    fn write_at(&self, _offset: usize, _reader: &mut VmReader) -> Result<usize> {
        return_errno_with_message!(Errno::EPERM, "the file is not writable");
    }

    fn open(
        &self,
        _access_mode: AccessMode,
        _status_flags: StatusFlags,
    ) -> Option<Result<Box<dyn PerOpenFileOps>>> {
        None
    }
}

pub(in procfs) trait ProcFileOpsByHandle: Sync + Send {
    /// Returns the thread whose credentials own this procfs inode.
    fn owner_thread(&self) -> Option<Arc<Thread>> {
        None
    }

    fn open(
        &self,
        access_mode: AccessMode,
        status_flags: StatusFlags,
    ) -> Result<Box<dyn PerOpenFileOps>>;
}

impl<T: ProcFileOpsByHandle> ProcFileOps for T {
    fn owner_thread(&self) -> Option<Arc<Thread>> {
        ProcFileOpsByHandle::owner_thread(self)
    }

    fn read_at(&self, _offset: usize, _writer: &mut VmWriter) -> Result<usize> {
        unreachable!("`read_at` is never called when `open` returns `Some(_)`")
    }

    fn write_at(&self, _offset: usize, _reader: &mut VmReader) -> Result<usize> {
        unreachable!("`write_at` is never called when `open` returns `Some(_)`")
    }

    fn open(
        &self,
        access_mode: AccessMode,
        status_flags: StatusFlags,
    ) -> Option<Result<Box<dyn PerOpenFileOps>>> {
        Some(self.open(access_mode, status_flags))
    }
}

/// Reads a string from `reader` and parses it as an `i32`.
pub(in procfs) fn read_i32_from(reader: &mut VmReader) -> Result<(i32, usize)> {
    /// Worst case buffer size needed for holding an integer.
    ///
    /// The longest possible string is `"-2147483648\n\0"`,
    /// whose length is 13 bytes.
    const BUF_SIZE_I32: usize = 13;

    let (cstr, read_bytes) = reader.read_cstring_until_end(BUF_SIZE_I32 - 1)?;
    let val = cstr
        .to_str()
        .ok()
        .map(|str| str.trim())
        .and_then(|str| str.parse::<i32>().ok())
        .ok_or_else(|| Error::with_message(Errno::EINVAL, "the value is not a valid integer"))?;

    Ok((val, read_bytes))
}

/// Reads a string from `reader` and parses it as a `u64`.
pub(in procfs) fn read_u64_from(reader: &mut VmReader) -> Result<(u64, usize)> {
    /// Worst case buffer size needed for holding a `u64`.
    ///
    /// The longest possible string is `"18446744073709551615\n\0"`,
    /// whose length is 23 bytes.
    const BUF_SIZE_U64: usize = 23;

    let (cstr, read_bytes) = reader.read_cstring_until_end(BUF_SIZE_U64 - 1)?;
    let val = cstr
        .to_str()
        .ok()
        .map(|str| str.trim())
        .and_then(|str| str.parse::<u64>().ok())
        .ok_or_else(|| Error::with_message(Errno::EINVAL, "the value is not a valid integer"))?;

    Ok((val, read_bytes))
}
