// SPDX-License-Identifier: MPL-2.0

use aster_util::printer::VmPrinter;

use crate::{
    fs::{
        file::mkmod,
        procfs::template::{ProcFile, ProcFileOps},
        vfs::inode::Inode,
    },
    prelude::*,
    process::credentials::capabilities::CapSet,
};

/// Represents the inode at `/proc/sys/kernel/cap_last_cap`.
pub(super) struct CapLastCapFileOps;

impl CapLastCapFileOps {
    pub(super) fn new_inode(parent: Weak<dyn Inode>) -> Arc<dyn Inode> {
        // Reference: <https://elixir.bootlin.com/linux/v6.16.5/source/kernel/sysctl.c#L1701>
        ProcFile::new(Self, parent, mkmod!(a+r))
    }
}

impl ProcFileOps for CapLastCapFileOps {
    fn read_at(&self, offset: usize, writer: &mut VmWriter) -> Result<usize> {
        let mut printer = VmPrinter::new_skip(writer, offset);

        let cap_last_cap_value = CapSet::most_significant_bit();
        writeln!(printer, "{}", cap_last_cap_value)?;

        Ok(printer.bytes_written())
    }
}
