// SPDX-License-Identifier: MPL-2.0

//! The architecture support of context switch.

use crate::task::TaskContextApi;

#[cfg(not(feature = "kernelet"))]
core::arch::global_asm!(include_str!("switch.S"));
#[cfg(feature = "kernelet")]
core::arch::global_asm!(include_str!("kernelet_switch.S"));

#[repr(C)]
#[derive(Clone, Debug)]
pub(crate) struct TaskContext {
    regs: CalleeRegs,
    rip: usize,
}

impl TaskContext {
    pub(crate) const fn new() -> Self {
        Self {
            regs: CalleeRegs::new(),
            rip: 0,
        }
    }
}

/// Callee-saved registers.
#[repr(C)]
#[derive(Clone, Debug)]
struct CalleeRegs {
    rsp: u64,
    rbx: u64,
    rbp: u64,
    r12: u64,
    r13: u64,
    r14: u64,
    r15: u64,
}

impl CalleeRegs {
    /// Creates new `CalleeRegs`
    pub(self) const fn new() -> Self {
        CalleeRegs {
            rsp: 0,
            rbx: 0,
            rbp: 0,
            r12: 0,
            r13: 0,
            r14: 0,
            r15: 0,
        }
    }
}

impl TaskContextApi for TaskContext {
    fn set_instruction_pointer(&mut self, ip: usize) {
        self.rip = ip;
    }

    fn set_stack_pointer(&mut self, sp: usize) {
        self.regs.rsp = sp as u64;
    }
}

unsafe extern "C" {
    #[cfg(not(feature = "kernelet"))]
    pub(crate) unsafe fn context_switch(nxt: *const TaskContext, cur: *mut TaskContext);
    #[cfg(not(feature = "kernelet"))]
    pub(crate) unsafe fn first_context_switch(nxt: *const TaskContext);
    #[cfg(feature = "kernelet")]
    pub(crate) unsafe fn context_switch(
        nxt: *const TaskContext,
        cur: *mut TaskContext,
        stack_limit: usize,
        vcpu_record: *const crate::kernelet::abi::VcpuRecord,
    );
    #[cfg(feature = "kernelet")]
    pub(crate) unsafe fn first_context_switch(
        nxt: *const TaskContext,
        stack_limit: usize,
        vcpu_record: *const crate::kernelet::abi::VcpuRecord,
    );
    pub(crate) unsafe fn kernel_task_entry_wrapper();
    #[cfg(feature = "kernelet")]
    pub(crate) unsafe fn first_user_task_entry_wrapper();
}
