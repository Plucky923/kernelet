/* SPDX-License-Identifier: MPL-2.0 */

.text
.code64

// Atomically loads a 32-bit integer value. This function works with exception handling
// and can recover from a page fault.
//
// Returns the loaded value or `!0u64` if failed to load.
.global __atomic_load_fallible
.type __atomic_load_fallible, @function
__atomic_load_fallible: # (ptr: *const u32) -> u64;
.load:
    mov eax, [rdi]
    ret
.load_fault:
    mov rax, -1
    ret
.size __atomic_load_fallible, .-__atomic_load_fallible

.pushsection .ex_table, "a", @progbits
    .balign 8
    .if {RELATIVE_EX_TABLE}
        .quad .load - .
        .quad .load_fault - .
    .else
        .quad .load
        .quad .load_fault
    .endif
.popsection
