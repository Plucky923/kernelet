// SPDX-License-Identifier: MPL-2.0

//! Power management.

use spin::Once;

#[cfg(not(feature = "kernelet"))]
use crate::{arch::irq::disable_local_and_halt, cpu::CpuSet};

/// An exit code that denotes the reason for restarting or powering off.
///
/// Whether or not the code is used depends on the hardware. In a virtualization environment, it
/// can be passed to the hypervisor (e.g., as QEMU's exit code). In a bare-metal environment, it
/// can be passed to the firmware. In either case, the code may be silently ignored if reporting
/// the code is not supported.
#[derive(Clone, Copy)]
pub enum ExitCode {
    /// The code that indicates a successful exit.
    Success,
    /// The code that indicates a failed exit.
    Failure,
}

/// Marks a kernelet exit as a restart request to its runtime.
pub const EXIT_RESTART: u32 = 1 << 31;

#[cfg(feature = "kernelet")]
fn exit_code_value(code: ExitCode) -> u32 {
    match code {
        ExitCode::Success => 0,
        ExitCode::Failure => 1,
    }
}

/// Ends a kernelet with an arbitrary status code.
///
/// A native kernel maps zero to a successful power-off and other codes to a
/// failed power-off, as its firmware interface accepts only these two states.
pub fn exit_with_code(code: u32) -> ! {
    #[cfg(feature = "kernelet")]
    (crate::kernelet::entry::services().stop)(
        crate::kernelet::abi::STOP_EXIT,
        code,
        core::ptr::null(),
        0,
    );

    #[cfg(not(feature = "kernelet"))]
    poweroff(if code == 0 {
        ExitCode::Success
    } else {
        ExitCode::Failure
    });
}

static RESTART_HANDLER: Once<fn(ExitCode)> = Once::new();

/// Injects a handler that can restart the system.
///
/// If no handler is injected, [`restart`] calls [`crate::arch::power::try_restart`].
/// Injection replaces that behavior: [`restart`] invokes only the injected handler, which may call
/// the architecture-specific operation as part of its own policy.
///
/// ```no_run
/// use ostd::power::{self, ExitCode};
///
/// fn init() {
///     power::inject_restart_handler(restart_policy);
/// }
///
/// fn restart_policy(code: ExitCode) {
///     try_platform_restart();
///     ostd::arch::power::try_restart(code);
/// }
///
/// fn try_platform_restart() {
///     // Try a platform-specific restart mechanism, if available.
/// }
/// ```
///
/// The function may be called only once; subsequent calls take no effect.
pub fn inject_restart_handler(handler: fn(ExitCode)) {
    RESTART_HANDLER.call_once(|| handler);
}

/// Restarts the system.
///
/// This function will not return. If the restart mechanism fails, this function will halt all CPUs
/// on the machine.
pub fn restart(code: ExitCode) -> ! {
    #[cfg(feature = "kernelet")]
    exit_with_code(exit_code_value(code) | EXIT_RESTART);

    #[cfg(not(feature = "kernelet"))]
    {
        if let Some(handler) = RESTART_HANDLER.get() {
            (handler)(code);
        } else {
            crate::arch::power::try_restart(code);
        }
        crate::error!("Failed to restart the system");
        machine_halt();
    }
}

static POWEROFF_HANDLER: Once<fn(ExitCode)> = Once::new();

/// Injects a handler that can power off the system.
///
/// If no handler is injected, [`poweroff`] calls [`crate::arch::power::try_poweroff`].
/// Injection replaces that behavior: [`poweroff`] invokes only the injected handler, which may call
/// the architecture-specific operation as part of its own policy.
///
/// ```no_run
/// use ostd::power::{self, ExitCode};
///
/// fn init() {
///     power::inject_poweroff_handler(poweroff_policy);
/// }
///
/// fn poweroff_policy(code: ExitCode) {
///     try_platform_poweroff();
///     ostd::arch::power::try_poweroff(code);
/// }
///
/// fn try_platform_poweroff() {
///     // Try a platform-specific poweroff mechanism, if available.
/// }
/// ```
///
/// The function may be called only once; subsequent calls take no effect.
pub fn inject_poweroff_handler(handler: fn(ExitCode)) {
    POWEROFF_HANDLER.call_once(|| handler);
}

/// Powers off the system.
///
/// This function will not return. If the poweroff mechanism fails, this function will halt all CPUs
/// on the machine.
pub fn poweroff(code: ExitCode) -> ! {
    #[cfg(feature = "coverage")]
    crate::coverage::on_system_exit();

    #[cfg(feature = "kernelet")]
    exit_with_code(exit_code_value(code));

    #[cfg(not(feature = "kernelet"))]
    {
        if let Some(handler) = POWEROFF_HANDLER.get() {
            (handler)(code);
        } else {
            crate::arch::power::try_poweroff(code);
        }
        crate::error!("Failed to power off the system");
        machine_halt();
    }
}

#[cfg(not(feature = "kernelet"))]
fn machine_halt() -> ! {
    crate::error!("Halting the machine...");

    // TODO: `inter_processor_call` may panic again (e.g., if there is an out-of-memory error). We
    // should find a way to make it panic-free.
    if let Some(ipi_sender) = crate::smp::IPI_SENDER.get() {
        ipi_sender.inter_processor_call(&CpuSet::new_full(), || disable_local_and_halt());
    }
    disable_local_and_halt();
}
