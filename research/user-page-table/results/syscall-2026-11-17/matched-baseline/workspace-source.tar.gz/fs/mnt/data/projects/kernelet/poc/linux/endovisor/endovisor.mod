/mnt/data/projects/kernelet/poc/linux/endovisor/main.o
/mnt/data/projects/kernelet/poc/linux/endovisor/image.o
/mnt/data/projects/kernelet/poc/linux/endovisor/grant.o
/mnt/data/projects/kernelet/poc/linux/endovisor/space.o
/mnt/data/projects/kernelet/poc/linux/endovisor/carrier.o
/mnt/data/projects/kernelet/poc/linux/endovisor/watch.o
/mnt/data/projects/kernelet/poc/linux/endovisor/switch.o
