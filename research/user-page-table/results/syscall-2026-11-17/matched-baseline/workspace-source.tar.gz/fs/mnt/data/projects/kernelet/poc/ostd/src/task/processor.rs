// SPDX-License-Identifier: MPL-2.0

use alloc::sync::Arc;
use core::{ptr::NonNull, sync::atomic::Ordering};

use super::{POST_SCHEDULE_HANDLER, PRE_SCHEDULE_HANDLER, Task};
use crate::{
    arch::task::{context_switch, first_context_switch},
    cpu_local_cell,
    irq::DisabledLocalIrqGuard,
};

cpu_local_cell! {
    /// The `Arc<Task>` (casted by [`Arc::into_raw`]) that is the current task.
    static CURRENT_TASK_PTR: *const Task = core::ptr::null();
    /// The previous task on the processor before switching to the current task.
    /// It is used for delayed resource release since it would be the current
    /// task's job to recycle the previous resources.
    static PREVIOUS_TASK_PTR: *const Task = core::ptr::null();
}

#[cfg(feature = "kernelet")]
cpu_local_cell! {
    // The first switch discards the bootstrap continuation. Release its Host
    // pool slot only once we are executing on the first ordinary Task's stack.
    static BOOT_STACK_TO_RELEASE: usize = 0;
    // Captured at the logical handoff; settled for PREVIOUS_TASK_PTR before
    // that Task can migrate. Host physical IRQs never access this Image cell.
    static PREVIOUS_TASK_TICKS: u64 = 0;
}

/// Returns a pointer to the current task running on the processor.
///
/// It returns `None` in Native bootstrap or before Guest boot adopts its Task.
pub(super) fn current_task() -> Option<NonNull<Task>> {
    NonNull::new(CURRENT_TASK_PTR.load().cast_mut())
}

#[cfg(feature = "kernelet")]
#[inline(always)]
pub(super) fn current_task_ptr_offset() -> usize {
    CURRENT_TASK_PTR.offset()
}

#[cfg(feature = "kernelet")]
pub(super) fn current_task_with(
    access: &crate::arch::cpu::local::CpuLocalAccess<'_>,
) -> Option<NonNull<Task>> {
    NonNull::new(access.load(&CURRENT_TASK_PTR).cast_mut())
}

#[cfg(feature = "kernelet")]
pub(super) fn adopt_current_boot_task(task: Arc<Task>) {
    assert!(!crate::arch::irq::is_local_enabled());
    assert!(CURRENT_TASK_PTR.load().is_null());
    assert!(PREVIOUS_TASK_PTR.load().is_null());
    assert!(task.kstack.is_boot());
    task.schedule_info
        .cpu
        .set_anyway(crate::cpu::CpuId::current_racy());
    super::preempt::cpu_local::enter_boot_task();
    CURRENT_TASK_PTR.store(Arc::into_raw(task));
}

/// Calls this function to switch to other task
///
/// If current task is none, then it will use the default task context and it
/// will not return to this function again.
///
/// # Panics
///
/// This function will panic if called while holding preemption locks or with
/// local IRQ disabled.
#[track_caller]
pub(super) fn switch_to_task(next_task: Arc<Task>) {
    #[cfg(feature = "kernelet")]
    assert!(
        !next_task.kstack.is_boot(),
        "cannot switch back to a boot Task"
    );
    super::atomic_mode::might_sleep();

    let irq_guard = crate::irq::disable_local();

    // A task can be woken and picked again between the scheduler's decision and
    // this point. Its context is already running on this CPU, so there is no
    // context switch to perform. Check under disabled IRQs to exclude local
    // preemption before acquiring the next task's execution ownership.
    if core::ptr::eq(CURRENT_TASK_PTR.load(), Arc::as_ptr(&next_task)) {
        return;
    }

    before_switching_to(&next_task, &irq_guard);

    // `before_switching_to` guarantees that from now on, and while the next task is running on the
    // CPU, its context can be used exclusively.
    let next_task_ctx_ptr = next_task.ctx().get().cast_const();
    #[cfg(feature = "kernelet")]
    let next_stack_limit = next_task.kstack.lower_bound();
    #[cfg(feature = "kernelet")]
    let vcpu_record = crate::kernelet::entry::vcpu_record() as *const _;

    let current_task_ptr = CURRENT_TASK_PTR.load();
    #[cfg(feature = "kernelet")]
    {
        // One atomic take defines the accounting boundary for both privilege
        // counts. Later ticks belong to the incoming Task. Keep callbacks off
        // this path until the old owner is settled on the new stack.
        let batch = crate::kernelet::entry::vcpu_record().task_ticks.take();
        debug_assert_eq!(PREVIOUS_TASK_TICKS.load(), 0);
        // Bootstrap without an adopted Task has no CPU clock to charge.
        if !current_task_ptr.is_null() {
            PREVIOUS_TASK_TICKS.store(batch);
        }
    }
    CURRENT_TASK_PTR.store(Arc::into_raw(next_task));
    debug_assert!(PREVIOUS_TASK_PTR.load().is_null());
    PREVIOUS_TASK_PTR.store(current_task_ptr);

    // We must disable IRQs when switching, see `after_switching_to`.
    core::mem::forget(irq_guard);

    let current_task_ctx_ptr = if !current_task_ptr.is_null() {
        // SAFETY: The pointer is set by `switch_to_task` and is guaranteed to be
        // built with `Arc::into_raw`. It will only be dropped as a previous task,
        // so its reference will be valid until `after_switching_to`.
        let current_task = unsafe { &*current_task_ptr };
        // Until `after_switching_to`, the task's context is alive and can be exclusively used.
        current_task.ctx.get()
    } else {
        // SAFETY:
        // 1. We have exclusive access to the next context (see above).
        // 2. The next context is valid (because it is either correctly initialized or written by a
        //    previous `context_switch`).
        #[cfg(not(feature = "kernelet"))]
        unsafe {
            first_context_switch(next_task_ctx_ptr)
        };
        #[cfg(feature = "kernelet")]
        unsafe {
            BOOT_STACK_TO_RELEASE.store(
                crate::kernelet::entry::vcpu_record()
                    .stack_limit
                    .load(Ordering::Acquire) as usize,
            );
            first_context_switch(next_task_ctx_ptr, next_stack_limit, vcpu_record)
        };
        // We've switched to the first task on the current CPU.
        unreachable!("`first_context_switch` should never return");
    };

    // SAFETY:
    // 1. We have exclusive access to both the current context and the next context (see above).
    // 2. The next context is valid (because it is either correctly initialized or written by a
    //    previous `context_switch`).
    unsafe {
        // This function may not return, for example, when the current task exits. So make sure
        // that all variables on the stack can be forgotten without causing resource leakage.
        #[cfg(not(feature = "kernelet"))]
        context_switch(next_task_ctx_ptr, current_task_ctx_ptr);
        #[cfg(feature = "kernelet")]
        context_switch(
            next_task_ctx_ptr,
            current_task_ctx_ptr,
            next_stack_limit,
            vcpu_record,
        );
    }

    // SAFETY: The task is just switched back, `after_switching_to` hasn't been called yet.
    unsafe { after_switching_to() };
}

fn before_switching_to(next_task: &Task, irq_guard: &DisabledLocalIrqGuard) {
    if let Some(handler) = PRE_SCHEDULE_HANDLER.get() {
        handler(irq_guard);
    }

    // Ensure that the mapping to the kernel stack is valid.
    next_task.kstack.flush_tlb(irq_guard);

    // Ensure that we are not switching to a task that is already running.
    while next_task
        .switched_to_cpu
        .compare_exchange(false, true, Ordering::AcqRel, Ordering::Relaxed)
        .is_err()
    {
        crate::warn!("Switching to a task already running in the foreground");
        core::hint::spin_loop();
    }
}

/// Does cleanups after switching to a task.
///
/// # Safety
///
/// This function must be called only once after switching to a task.
pub(crate) unsafe fn after_switching_to() {
    #[cfg(feature = "kernelet")]
    {
        let boot_stack = BOOT_STACK_TO_RELEASE.load();
        if boot_stack != 0 {
            BOOT_STACK_TO_RELEASE.store(0);
            // The first switch never saves a resumable bootstrap context.
            // Guest IRQs are still masked, so this vCPU cannot switch Tasks
            // while returning its own obsolete bootstrap slot to the Host.
            let result = (crate::kernelet::entry::services().kstack_free)(boot_stack as u64);
            assert_eq!(result, 0, "Host refused to retire a bootstrap stack");
        }
    }
    let prev = PREVIOUS_TASK_PTR.load();
    #[cfg(feature = "kernelet")]
    {
        let urec = crate::kernelet::entry::user_event_record();
        let pt_regs_ptr =
            urec.pt_regs.load(Ordering::Acquire) as *mut crate::arch::cpu::context::LinuxPtRegs;
        if !prev.is_null() {
            // SAFETY: `prev` is alive and still owns `switched_to_cpu == true` on
            // this vCPU until released below, so saving its live `pt_regs` frame
            // into its stack save area before cross-vCPU migration is race-free.
            let prev_ref = unsafe { &*prev };
            if prev_ref.is_user() && !prev_ref.is_exiting() {
                assert!(
                    !pt_regs_ptr.is_null(),
                    "user task switched out without Host pt_regs pointer"
                );
                let saved = unsafe { pt_regs_ptr.read() };
                let save_area = prev_ref.pt_regs_save_area();
                unsafe { save_area.write(saved) };
                prev_ref.active_pt_regs().store(save_area, Ordering::Release);
            }
        }
        if let Some(current) = Task::current()
            && current.is_user()
            && !current.is_exiting()
        {
            urec.event_rsp
                .store(current.event_rsp() as u64, Ordering::Release);
            urec.event_stack_limit
                .store(current.kstack.lower_bound() as u64, Ordering::Release);
            assert!(
                !pt_regs_ptr.is_null(),
                "user task switched in without Host pt_regs pointer"
            );
            // SAFETY: `current` exclusively owns its stack save area (`switched_to_cpu`
            // was acquired in `before_switching_to`), and `pt_regs_ptr` is this vCPU's frame.
            let incoming = unsafe { current.pt_regs_save_area().read() };
            unsafe { pt_regs_ptr.write(incoming) };
            current
                .active_pt_regs()
                .store(pt_regs_ptr, Ordering::Relaxed);
        }
    }
    // Release the previous task.
    let prev = if !prev.is_null() {
        PREVIOUS_TASK_PTR.store(core::ptr::null());

        // SAFETY: The pointer is set by `switch_to_task` and is guaranteed to
        // be built with `Arc::into_raw`. We couldn't do it twice since we set
        // it to NULL after the read.
        let prev_task = unsafe { Arc::from_raw(prev) };

        #[cfg(feature = "kernelet")]
        {
            let batch = PREVIOUS_TASK_TICKS.load();
            PREVIOUS_TASK_TICKS.store(0);
            // Settle only the captured old batch. New per-vCPU samples belong
            // to the incoming Task and stay pending until its own boundary.
            prev_task.account_sampled_ticks(batch);
        }

        #[cfg(feature = "kernelet")]
        if prev_task.kstack.is_boot() {
            // SAFETY: A boot Task can only switch here through its permanent
            // exit. IRQs remain disabled and this new stack is still on the
            // original vCPU, before any handler can schedule or migrate us.
            unsafe { prev_task.kstack.retire_boot() };
            prev_task.schedule_info.cpu.set_to_none();
        }

        // Releases execution ownership. Ordinary Tasks can be switched to
        // again; the permanent Boot identity still forbids its rescheduling.
        prev_task.switched_to_cpu.store(false, Ordering::Release);

        Some(prev_task)
    } else {
        None
    };

    if let Some(handler) = POST_SCHEDULE_HANDLER.get() {
        handler();
    }

    // The resumed context and previous Task ownership are now settled. Clear
    // its transition mark before IRQ handlers or local-data destructors can
    // schedule again. The guard still handles paths that never switch Tasks.
    super::finish_scheduling();

    // See `switch_to_task`, where we forgot an IRQ guard.
    crate::arch::irq::enable_local();

    // It was forgotten using `Arc::into_raw` at `switch_to_task`.
    // We drop it after enabling the IRQ in case dropping user-provided
    // resources would violate the atomic mode.
    drop(prev);
}
