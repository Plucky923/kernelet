/* SPDX-License-Identifier: MPL-2.0 */

.text

.global context_switch
.type context_switch, @function
context_switch: # (nxt: *const TaskContext, cur: *mut TaskContext)
  # Save cur's register
  st.d  $sp, $a1, 0x0
  st.d  $fp, $a1, 0x8
  st.d  $s0, $a1, 0x10
  st.d  $s1, $a1, 0x18
  st.d  $s2, $a1, 0x20
  st.d  $s3, $a1, 0x28
  st.d  $s4, $a1, 0x30
  st.d  $s5, $a1, 0x38
  st.d  $s6, $a1, 0x40
  st.d  $s7, $a1, 0x48
  st.d  $s8, $a1, 0x50
  st.d  $ra, $a1, 0x58 # return address
  # Fallthrough

.global first_context_switch
.type first_context_switch, @function
first_context_switch: # (nxt: *const TaskContext)
  # Restore nxt's registers
  ld.d  $sp, $a0, 0x0
  ld.d  $fp, $a0, 0x8
  ld.d  $s0, $a0, 0x10
  ld.d  $s1, $a0, 0x18
  ld.d  $s2, $a0, 0x20
  ld.d  $s3, $a0, 0x28
  ld.d  $s4, $a0, 0x30
  ld.d  $s5, $a0, 0x38
  ld.d  $s6, $a0, 0x40
  ld.d  $s7, $a0, 0x48
  ld.d  $s8, $a0, 0x50
  ld.d  $ra, $a0, 0x58 # return address

  ret
.size context_switch, .-context_switch
.size first_context_switch, .-first_context_switch

.global kernel_task_entry_wrapper
.type kernel_task_entry_wrapper, @function
kernel_task_entry_wrapper:
  .cfi_startproc
  .cfi_undefined 1 # mark return address as undefined to indicate end of call stack
  bl kernel_task_entry
  .cfi_endproc
.size kernel_task_entry_wrapper, .-kernel_task_entry_wrapper
