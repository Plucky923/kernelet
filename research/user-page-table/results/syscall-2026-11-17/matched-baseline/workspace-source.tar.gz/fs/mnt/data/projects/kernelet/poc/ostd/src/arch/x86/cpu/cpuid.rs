// SPDX-License-Identifier: MPL-2.0

//! CPU information from the CPUID instruction.

use core::arch::x86_64::CpuidResult;

use spin::Once;

static MAX_LEAF: Once<u32> = Once::new();
static MAX_HYPERVISOR_LEAF: Once<u32> = Once::new();
static MAX_EXTENDED_LEAF: Once<u32> = Once::new();

#[repr(u32)]
enum Leaf {
    Base = 0x00,
    Xstate = 0x0d,
    Tsc = 0x15,

    HypervisorBase = 0x40000000,
    KvmFeatures = 0x40000001,
    ExtBase = 0x80000000,
}

/// Executes the CPUID instruction for the given leaf and subleaf.
///
/// This method will return `None` if the leaf is not supported.
pub fn cpuid(leaf: u32, subleaf: u32) -> Option<CpuidResult> {
    fn raw_cpuid(leaf: u32, subleaf: u32) -> CpuidResult {
        core::arch::x86_64::__cpuid_count(leaf, subleaf)
    }

    let max_leaf = if leaf < Leaf::HypervisorBase as u32 {
        // Standard leaves (0x0000_0000 - 0x3FFF_FFFF)
        *MAX_LEAF.call_once(|| raw_cpuid(Leaf::Base as u32, 0).eax)
    } else if leaf < Leaf::ExtBase as u32 {
        // Hypervisor leaves (0x4000_0000 - 0x7FFF_FFFF)
        *MAX_HYPERVISOR_LEAF.call_once(|| raw_cpuid(Leaf::HypervisorBase as u32, 0).eax)
    } else {
        // Extended leaves (0x8000_0000 - 0xFFFF_FFFF)
        *MAX_EXTENDED_LEAF.call_once(|| raw_cpuid(Leaf::ExtBase as u32, 0).eax)
    };

    if leaf > max_leaf {
        None
    } else {
        Some(raw_cpuid(leaf, subleaf))
    }
}

/// Queries the frequency in Hz of the Time Stamp Counter (TSC).
///
/// This is based on the information given by the CPUID instruction in the Time Stamp Counter and
/// Nominal Core Crystal Clock Information Leaf.
///
/// Note that the CPUID leaf is currently only supported by new Intel CPUs. This method will return
/// `None` if it is not supported.
pub(in crate::arch) fn query_tsc_freq() -> Option<u64> {
    let CpuidResult {
        eax: denominator,
        ebx: numerator,
        ecx: crystal_freq,
        ..
    } = cpuid(Leaf::Tsc as u32, 0)?;

    if denominator == 0 || numerator == 0 {
        return None;
    }

    // If the nominal core crystal clock frequency is not enumerated, we can either obtain that
    // information from a hardcoded table or rely on the processor base frequency. The Intel
    // documentation recommends the first approach [1], but Linux uses the second approach because
    // the first approach is difficult to implement correctly for all corner cases [2]. However,
    // the second approach does not provide 100% accurate frequencies, so Linux must adjust them at
    // runtime [2]. For now, we avoid these headaches by faithfully reporting that the TSC
    // frequency is unavailable.
    //
    // [1]: Intel(R) 64 and IA-32 Architectures Software Developer’s Manual,
    //      Section 20.7.3, Determining the Processor Base Frequency
    // [2]: https://github.com/torvalds/linux/commit/604dc9170f2435d27da5039a3efd757dceadc684
    if crystal_freq == 0 {
        return None;
    }

    Some((crystal_freq as u64) * (numerator as u64) / (denominator as u64))
}

/// Queries the supported XSTATE features, i.e., the supported bits of `XCR0` and `IA32_XSS`.
pub(in crate::arch) fn query_xstate_max_features() -> Option<u64> {
    let res0 = cpuid(Leaf::Xstate as u32, 0)?;
    let res1 = cpuid(Leaf::Xstate as u32, 1)?;

    // Supported bits in `XCR0`.
    let xcr_bits = (res0.eax as u64) | ((res0.edx as u64) << 32);
    // Supported bits in `IA32_XSS`.
    let xss_bits = (res1.ecx as u64) | ((res1.edx as u64) << 32);

    Some(xcr_bits | xss_bits)
}

/// Queries the standard XSAVE layout size for the states enabled in `XCR0`.
///
/// XSAVE/XRSTOR use subleaf zero's size. Subleaf one's size describes the
/// compacted XSAVEC/XSAVES layout and cannot size or copy a standard area.
pub(in crate::arch) fn query_xsave_area_size() -> Option<u32> {
    cpuid(Leaf::Xstate as u32, 0).map(|res| res.ebx)
}

#[cfg(ktest)]
mod test {
    use super::*;
    use crate::prelude::ktest;

    #[ktest]
    fn xsave_size_covers_the_standard_format() {
        let _guard = crate::task::disable_preempt();
        let Some(features) = cpuid(1, 0) else {
            return;
        };
        const XSAVE_AND_OSXSAVE: u32 = (1 << 26) | (1 << 27);
        if features.ecx & XSAVE_AND_OSXSAVE != XSAVE_AND_OSXSAVE {
            return;
        }
        // SAFETY: CPUID confirms XSAVE support and CR4.OSXSAVE is enabled.
        // XCR0 is the architectural XGETBV index0; the CPU is pinned above.
        let enabled = unsafe { core::arch::x86_64::_xgetbv(0) };
        let area_size = query_xsave_area_size().unwrap();
        // Standard XSAVE always includes the 512-byte legacy area followed
        // by its 64-byte header, independently of extended components.
        assert!(area_size >= 512 + 64);
        for component in 2..64 {
            if enabled & (1u64 << component) == 0 {
                continue;
            }
            let layout = cpuid(Leaf::Xstate as u32, component).unwrap();
            assert_ne!(
                layout.eax, 0,
                "enabled xstate component {component} has no storage"
            );
            assert_eq!(
                layout.ecx & 1,
                0,
                "XCR0 component {component} must be user state"
            );
            // EAX gives this component's bytes and EBX its standard-layout
            // offset. Bits5/6/7 cover AVX-512 opmask/ZMM_Hi256/Hi16_ZMM;
            // bit7 therefore checks the tail containing ZMM16 through ZMM31.
            let required_end = layout.ebx.checked_add(layout.eax).unwrap();
            assert!(
                area_size >= required_end,
                "XSAVE area {area_size} truncates enabled component {component} ending at {required_end}"
            );
        }
    }
}

/// Queries whether the system is running in QEMU.
///
/// This function uses the CPUID instruction to detect the QEMU hypervisor signature.
pub(in crate::arch) fn query_if_running_in_qemu() -> bool {
    let Some(signature) = query_hypervisor_signature() else {
        return false;
    };

    // Check for the QEMU hypervisor signature: "TCGTCGTCGTCG" or "KVMKVMKVM\0\0\0".
    // Reference: <https://wiki.osdev.org/QEMU_fw_cfg#Detecting_QEMU>
    //
    // TODO: The "KVMKVMKVM\0\0\0" signature is commonly shared by KVM-based VMMs
    // (not unique to QEMU). Detecting QEMU via its ACPI tables
    // (e.g., OEM IDs or the QEMU0002 device) would generally be more accurate.
    matches!(&signature, b"TCGTCGTCGTCG" | b"KVMKVMKVM\0\0\0")
}

/// Queries whether the system is running under KVM.
pub(in crate::arch) fn query_if_running_under_kvm() -> bool {
    let Some(signature) = query_hypervisor_signature() else {
        return false;
    };

    matches!(&signature, b"KVMKVMKVM\0\0\0")
}

/// Queries the 12-byte hypervisor signature.
fn query_hypervisor_signature() -> Option<[u8; 12]> {
    let result = cpuid(Leaf::HypervisorBase as u32, 0)?;

    let mut signature = [0u8; 12];
    signature[0..4].copy_from_slice(&result.ebx.to_ne_bytes());
    signature[4..8].copy_from_slice(&result.ecx.to_ne_bytes());
    signature[8..12].copy_from_slice(&result.edx.to_ne_bytes());

    Some(signature)
}

/// Queries if the KVM feature indicated by `bit` is available.
pub(in crate::arch) fn query_kvm_feature(bit: u32) -> bool {
    cpuid(Leaf::KvmFeatures as u32, 0).is_some_and(|result| result.eax & (1 << bit) != 0)
}
