// SPDX-License-Identifier: MPL-2.0

//! The IOMMU support.

use crate::mm::{Daddr, Paddr};

/// An enumeration representing possible errors related to IOMMU.
#[derive(Debug)]
pub(crate) enum IommuError {
    /// No IOMMU is available.
    NoIommu,
}

/// # Safety
///
/// While the physical address is mapped as the device address (i.e. from calling this method to
/// calling [`unmap`]), it must point to an untyped memory page. Otherwise, the device may corrupt
/// kernel data, which could lead to memory safety issues.
pub(crate) unsafe fn map(_daddr: Daddr, _paddr: Paddr) -> Result<(), IommuError> {
    Err(IommuError::NoIommu)
}

pub(crate) fn unmap(_daddr: Daddr) -> Result<(), IommuError> {
    Err(IommuError::NoIommu)
}

pub(crate) fn init() -> Result<(), IommuError> {
    // TODO: We will support IOMMU on RISC-V
    Err(IommuError::NoIommu)
}

pub(crate) fn has_dma_remapping() -> bool {
    false
}

pub(crate) fn has_interrupt_remapping() -> bool {
    false
}
