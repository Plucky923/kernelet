// SPDX-License-Identifier: MPL-2.0

use core::time::Duration;

use inherit_methods_macro::inherit_methods;

use crate::{
    fs::{
        file::{AccessMode, InodeHandle, InodeMode, InodeType, PerOpenFileOps, StatusFlags, mkmod},
        pipe::Pipe,
        pseudofs::{PipeFs, PseudoInode, PseudoInodeType},
        utils,
        vfs::{
            file_system::FileSystem,
            inode::{Extension, FileOps, Inode, Metadata},
            path::Dentry,
        },
    },
    prelude::*,
    process::{Gid, Uid},
};

/// Creates a pair of connected pipe file handles with the default capacity.
pub(crate) fn new_file_pair(
    status_flags: StatusFlags,
) -> Result<(Arc<InodeHandle>, Arc<InodeHandle>)> {
    let pipe_inode = Arc::new(AnonPipeInode::new());
    let path = PipeFs::new_path(pipe_inode);

    // Remove `O_DIRECT` for the reader, which conforms to the Linux behavior:
    // the writer's status flags decide whether the pipe is in "packet" mode.
    let reader_status_flags = status_flags & StatusFlags::O_NONBLOCK;
    let writer_status_flags = status_flags & (StatusFlags::O_NONBLOCK | StatusFlags::O_DIRECT);

    let reader =
        InodeHandle::new_unchecked_access(path.clone(), AccessMode::O_RDONLY, reader_status_flags)?;
    let writer =
        InodeHandle::new_unchecked_access(path, AccessMode::O_WRONLY, writer_status_flags)?;

    Ok((Arc::new(reader), Arc::new(writer)))
}

/// An anonymous pipe inode.
pub(crate) struct AnonPipeInode {
    /// The underlying pipe backend.
    pipe: Pipe,
    pseudo_inode: PseudoInode,
}

impl AnonPipeInode {
    fn new() -> Self {
        let pipe = Pipe::new();
        let (uid, gid) = utils::current_fs_ids();

        let pseudo_inode =
            PipeFs::singleton().alloc_inode(PseudoInodeType::Pipe, mkmod!(u+rw), uid, gid);

        Self { pipe, pseudo_inode }
    }
}

#[inherit_methods(from = "self.pseudo_inode")]
impl FileOps for AnonPipeInode {
    fn read_at(
        &self,
        _offset: usize,
        _writer: &mut VmWriter,
        _status: StatusFlags,
    ) -> Result<usize>;
    fn write_at(
        &self,
        _offset: usize,
        _reader: &mut VmReader,
        _status: StatusFlags,
    ) -> Result<usize>;
}

#[inherit_methods(from = "self.pseudo_inode")]
impl Inode for AnonPipeInode {
    fn size(&self) -> usize;
    fn resize(&self, self_dentry: &Dentry, _new_size: usize) -> Result<()>;
    fn metadata(&self) -> Result<Metadata>;
    fn extension(&self) -> &Extension;
    fn ino(&self) -> u64;
    fn type_(&self) -> InodeType;
    fn mode(&self) -> Result<InodeMode>;
    fn set_mode(&self, self_dentry: &Dentry, mode: InodeMode) -> Result<()>;
    fn owner(&self) -> Result<Uid>;
    fn set_owner(&self, self_dentry: &Dentry, uid: Uid) -> Result<()>;
    fn group(&self) -> Result<Gid>;
    fn set_group(&self, self_dentry: &Dentry, gid: Gid) -> Result<()>;
    fn atime(&self) -> Duration;
    fn set_atime(&self, self_dentry: &Dentry, time: Duration);
    fn mtime(&self) -> Duration;
    fn set_mtime(&self, self_dentry: &Dentry, time: Duration);
    fn ctime(&self) -> Duration;
    fn set_ctime(&self, self_dentry: &Dentry, time: Duration);
    fn fs(&self) -> Arc<dyn FileSystem>;

    fn open(
        &self,
        _self_dentry: &Dentry,
        access_mode: AccessMode,
        status_flags: StatusFlags,
    ) -> Option<Result<Box<dyn PerOpenFileOps>>> {
        Some(self.pipe.open_anon(access_mode, status_flags))
    }
}
