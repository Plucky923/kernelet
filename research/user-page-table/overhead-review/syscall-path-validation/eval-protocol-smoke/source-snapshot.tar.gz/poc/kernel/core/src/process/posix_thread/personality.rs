// SPDX-License-Identifier: MPL-2.0

use core::sync::atomic::Ordering;

use bitflags::bitflags;

use super::PosixThread;

bitflags! {
    pub(crate) struct Personality: u32 {
        const ADDR_NO_RANDOMIZE = 0x0040000;
        const STICKY_TIMEOUTS = 0x4000000;
    }
}

impl PosixThread {
    /// Returns the personality value of this thread.
    pub(crate) fn personality(&self) -> u32 {
        self.personality.load(Ordering::Relaxed)
    }

    /// Sets the personality value of this thread.
    pub(crate) fn set_personality(&self, personality: u32) {
        self.personality.store(personality, Ordering::Relaxed);
    }
}
