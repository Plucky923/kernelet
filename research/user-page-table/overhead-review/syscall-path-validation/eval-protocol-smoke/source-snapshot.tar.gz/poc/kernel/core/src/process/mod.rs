// SPDX-License-Identifier: MPL-2.0

mod clone;
pub mod credentials;
mod execve;
mod exit;
mod kill;
mod namespace;
mod pid_file;
pub(crate) mod pid_table;
pub mod posix_thread;
#[expect(clippy::module_inception)]
mod process;
mod process_filter;
mod process_vm;
mod program_loader;
pub(crate) mod rlimit;
pub mod signal;
mod stats;
mod status;
pub(crate) mod sync;
pub(crate) mod task_set;
mod term_status;
mod wait;

pub(crate) use clone::{CloneArgs, CloneFlags, clone_child};
pub(crate) use credentials::{Credentials, Gid, Uid};
pub(crate) use execve::do_execve;
pub(crate) use kill::{kill, kill_all, kill_group, tgkill};
pub use namespace::user_ns::UserNamespace;
pub(crate) use namespace::{
    nsproxy::{ContextSetNsAdminApi, NsProxy, NsProxyBuilder, check_unsupported_ns_flags},
    unshare::ContextUnshareAdminApi,
};
pub(crate) use pid_file::PidFile;
pub use process::Process;
pub(crate) use process::{
    ExitCode, INIT_PROCESS_PID, JobControl, Pgid, Pid, ProcessGroup, ReapedChildrenStats, Session,
    Sid, Terminal, broadcast_signal_async, enqueue_signal_async, spawn_init_process,
};
pub(crate) use process_filter::ProcessFilter;
pub(crate) use process_vm::{INIT_STACK_SIZE, LockedHeap, ProcessVm, VmarSnapshot};
pub(crate) use program_loader::{ShebangScriptPath, UndetectedExecutable};
pub(crate) use rlimit::ResourceType;
pub(crate) use stats::collect_process_creation_count;
pub(crate) use term_status::TermStatus;
pub(crate) use wait::{WaitOptions, WaitStatus, do_wait};

pub(super) fn init() {
    posix_thread::futex::init();
    stats::init();
}

pub(super) fn init_on_each_cpu() {
    process::init_on_each_cpu();
}
