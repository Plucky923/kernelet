// SPDX-License-Identifier: MPL-2.0

//! Form file paths within and across FSes with dentries and mount points.

use core::time::Duration;

pub(crate) use dentry::Dentry;
use inherit_methods_macro::inherit_methods;
use mount::MountTreeCloneMode;
pub(crate) use mount::{MNT_UNIQUE_ID_MIN, Mount, PerMountFlags};
pub(in crate::fs) use mount::{RecyclableMountId, UniqueMountId};
pub(crate) use mount_namespace::MountNamespace;
pub(crate) use mount_propagation::MountPropType;
pub(in crate::fs) use mount_propagation::MountTopology;
use mount_propagation::PendingPropagationChanges;
pub(crate) use resolver::{
    AT_FDCWD, AbsPathResult, EmptyPathStr, FsPath, LookupResult, PathResolver, SplitPath,
    SplitPathError,
};

use crate::{
    fs::{
        file::{
            CreationFlags, InodeHandle, InodeMode, InodeType, OpenArgs, Permission, StatusFlags,
            SyncMode,
        },
        pseudofs::NsInode,
        vfs::{
            file_system::{FileSystem, FsFlags},
            inode::{HardLinkability, Inode, Metadata, MknodType, RenameMode},
            notify,
            registry::FsAndRoot,
            xattr::{self, XattrName, XattrNamespace, XattrSetFlags},
        },
    },
    prelude::*,
    process::{
        Gid, Uid, UserNamespace, credentials::capabilities::CapSet, posix_thread::AsPosixThread,
    },
    security::lsm::hooks as lsm_hooks,
};

mod dentry;
mod mount;
mod mount_namespace;
mod mount_propagation;
mod resolver;

/// A `Path` is used to represent an exact location in the VFS tree.
///
/// Each `Path` corresponds to a node in the VFS tree, and a single node
/// may have multiple `Path` instances referencing it due to mount operations.
#[derive(Clone, Debug)]
pub struct Path {
    mount: Arc<Mount>,
    dentry: Arc<Dentry>,
}

impl PartialEq for Path {
    fn eq(&self, other: &Self) -> bool {
        self.mount.id() == other.mount.id() && Arc::ptr_eq(&self.dentry, &other.dentry)
    }
}

impl Eq for Path {}

impl Path {
    /// Creates a new `Path` to represent the root directory of a file system.
    pub(crate) fn new_root(mount: Arc<Mount>) -> Self {
        let inner = mount.root_dentry().clone();
        Self::new(mount, inner)
    }

    /// Creates a new child `Path` in a file system.
    ///
    /// This API is for non-symbolic-link children.
    /// Use [`Self::new_symlink_child`] to create a symbolic link, because a
    /// symbolic link should be created atomically with its target.
    pub(crate) fn new_child(&self, name: &str, type_: InodeType, mode: InodeMode) -> Result<Self> {
        debug_assert_ne!(type_, InodeType::SymLink);

        let dir_dentry = self.dentry.as_dir_dentry_or_err()?;
        self.check_dir_entry_mutation()?;
        let new_child_dentry = dir_dentry.create_child(name, || {
            dir_dentry.inode().create(&dir_dentry, name, type_, mode)
        })?;
        Ok(Self::new(self.mount.clone(), new_child_dentry))
    }

    /// Creates a new symbolic-link child `Path` in a file system.
    ///
    /// Use this API instead of [`Self::new_child`] when creating symbolic
    /// links so the link target is supplied at creation time.
    pub(crate) fn new_symlink_child(
        &self,
        name: &str,
        target: &str,
        mode: InodeMode,
    ) -> Result<Self> {
        let dir_dentry = self.dentry.as_dir_dentry_or_err()?;
        self.check_dir_entry_mutation()?;
        let new_child_dentry = dir_dentry.create_child(name, || {
            dir_dentry
                .inode()
                .create_symlink(&dir_dentry, name, target, mode)
        })?;
        Ok(Self::new(self.mount.clone(), new_child_dentry))
    }

    /// Looks up a direct child within the current mount.
    ///
    /// This does not interpret special names, check search permissions, or traverse mount points.
    pub(crate) fn lookup_child(&self, name: &str) -> Result<Self> {
        let dir_dentry = self.dentry.as_dir_dentry_or_err()?;
        let child_dentry = dir_dentry.lookup_child(name)?;
        Ok(Self::new(self.mount.clone(), child_dentry))
    }

    /// Creates a new `Path` to represent an unnamed temporary file.
    ///
    /// The returned inode has no directory entry and is invisible to `readdir`.
    /// If created hard-linkable, it may later be given a name via a link
    /// operation; otherwise it can never be linked.
    pub(crate) fn create_tmpfile(
        &self,
        mode: InodeMode,
        hard_linkability: HardLinkability,
    ) -> Result<Self> {
        let dir_dentry = self.dentry.as_dir_dentry_or_err()?;
        self.check_dir_entry_mutation()?;
        let tmp_inode = self
            .inode()
            .create_tmpfile(&self.dentry, mode, hard_linkability)?;
        let tmp_dentry = Dentry::new_anonymous(tmp_inode, &dir_dentry);
        Ok(Self::new(self.mount.clone(), tmp_dentry))
    }

    /// Creates a new pseudo `Path`.
    pub(in crate::fs) fn new_pseudo(
        mount: Arc<Mount>,
        inode: Arc<dyn Inode>,
        name_fn: fn(&dyn Inode) -> String,
    ) -> Self {
        let dentry = Dentry::new_pseudo(inode, name_fn);
        Self::new(mount, dentry)
    }

    pub(in crate::fs) fn new(mount: Arc<Mount>, dentry: Arc<Dentry>) -> Self {
        Self { mount, dentry }
    }

    /// Gets the mount node of current `Path`.
    pub(crate) fn mount_node(&self) -> &Arc<Mount> {
        &self.mount
    }

    /// Gets the dentry of current `Path`.
    pub(in crate::fs) fn dentry(&self) -> &Arc<Dentry> {
        &self.dentry
    }

    /// Returns true if the current `Path` is the root of its mount.
    pub(crate) fn is_mount_root(&self) -> bool {
        Arc::ptr_eq(&self.dentry, self.mount.root_dentry())
    }

    /// Opens the `Path` with the given `OpenArgs`.
    ///
    /// Returns an `InodeHandle` on success.
    pub(crate) fn open(&self, open_args: OpenArgs) -> Result<InodeHandle> {
        let inode = self.inode().as_ref();
        let inode_type = inode.type_();
        let creation_flags = &open_args.creation_flags;
        let status_flags = &open_args.status_flags;

        if creation_flags.contains(CreationFlags::O_CREAT)
            && creation_flags.contains(CreationFlags::O_EXCL)
        {
            return_errno_with_message!(Errno::EEXIST, "the file already exists");
        }
        if creation_flags.contains(CreationFlags::O_CREAT) && inode_type == InodeType::Dir {
            return_errno_with_message!(
                Errno::EISDIR,
                "O_CREAT is specified but the file is a directory"
            );
        }

        if inode_type == InodeType::SymLink
            && creation_flags.contains(CreationFlags::O_NOFOLLOW)
            && !status_flags.contains(StatusFlags::O_PATH)
        {
            return_errno_with_message!(Errno::ELOOP, "the file is a symlink");
        }
        if creation_flags.contains(CreationFlags::O_DIRECTORY) && inode_type != InodeType::Dir {
            return_errno_with_message!(
                Errno::ENOTDIR,
                "O_DIRECTORY is specified but the file is not a directory"
            );
        }

        if inode_type.is_regular_file()
            && creation_flags.contains(CreationFlags::O_TRUNC)
            && !status_flags.contains(StatusFlags::O_PATH)
        {
            self.resize(0)?;
        }

        InodeHandle::new(self.clone(), open_args.access_mode, *status_flags)
    }

    /// Gets the parent `Path` within the same mount.
    ///
    /// This method returns the parent path within the same filesystem/mount.
    /// It does NOT cross mount boundaries. If the current path is the root of a mount,
    /// it will return `None`.
    ///
    /// For cross-filesystem parent lookup, use `effective_parent()` instead.
    pub(super) fn parent_within_mount(&self) -> Option<Self> {
        let parent = self.dentry.parent()?;
        Some(Self::new(self.mount.clone(), parent))
    }

    /// Gets the top `Path` of the current.
    ///
    /// Used when different file systems are mounted on the same mount point.
    ///
    /// For example, first `mount /dev/sda1 /mnt` and then `mount /dev/sda2 /mnt`.
    /// After the second mount is completed, the content of the first mount will be overridden.
    /// We need to recursively obtain the top `Path`.
    pub(crate) fn get_top_path(mut self) -> Self {
        while self.dentry.is_mountpoint() {
            if let Some(child_mount) = self.mount.get(&self.dentry) {
                let inner = child_mount.root_dentry().clone();
                self = Self::new(child_mount, inner);
            } else {
                break;
            }
        }

        self
    }

    /// Finds the corresponding `Path` in the given mount namespace.
    fn find_corresponding_mount(
        &self,
        mnt_ns: &Arc<MountNamespace>,
        topology: &MountTopology,
    ) -> Option<Self> {
        let corresponding_mount = self.mount.find_corresponding_mount(mnt_ns, topology)?;
        let corresponding_path = Self::new(corresponding_mount, self.dentry.clone());

        Some(corresponding_path)
    }

    /// Checks if this path is reachable from the given `root` path.
    ///
    /// A path is considered reachable if it is the same as or a descendant
    /// of the `root` path. The check traverses upwards from the current path,
    /// crossing mount point boundaries as necessary, until it either finds
    /// the `root` path or reaches the global root.
    fn is_reachable_from(&self, root: &Path, _topology: &MountTopology) -> bool {
        let mut owned;
        let mut current = self;

        loop {
            if current.mount.id() == root.mount.id() {
                return current.dentry.is_equal_or_descendant_of(&root.dentry);
            }

            let Some(parent_mount) = current.mount.parent().and_then(|mount| mount.upgrade())
            else {
                // `upgrade()` may fail if `current` is in a mount namespace that has been
                // dropped. In this situation, `current` is not reachable from `root` because
                // `root` holds strong reference counts for all its descendant mounts.
                return false;
            };

            owned = Path::new(
                parent_mount,
                current
                    .mount
                    .mountpoint()
                    .expect("Mounts with parents must have a mount point")
                    .clone(),
            );
            current = &owned;
        }
    }

    /// Returns true if the `Path` represents a pseudo file.
    fn is_pseudo(&self) -> bool {
        self.dentry.is_pseudo()
    }

    fn this(&self) -> Self {
        self.clone()
    }

    /// Checks whether this path is a searchable directory.
    fn check_dir_search_permission(&self) -> Result<()> {
        if self.type_() != InodeType::Dir {
            return_errno_with_message!(Errno::ENOTDIR, "only directories are searchable");
        }

        self.inode()
            .check_permission(Permission::MAY_EXEC | Permission::MAY_CHDIR)
    }

    /// Checks whether the path is on a writable mount and filesystem.
    fn check_mount_writable(&self) -> Result<()> {
        if self.mount.flags().contains(PerMountFlags::RDONLY)
            || self.fs().flags().contains(FsFlags::RDONLY)
        {
            return_errno_with_message!(Errno::EROFS, "the mount or filesystem is read-only");
        }

        Ok(())
    }

    /// Checks whether a directory entry may be modified in this directory.
    fn check_dir_entry_mutation(&self) -> Result<()> {
        self.check_mount_writable()?;
        self.inode()
            .check_permission(Permission::MAY_WRITE | Permission::MAY_EXEC)
    }

    /// Checks whether an inode may be used as the source of a hard link.
    fn check_hardlink_source(&self) -> Result<()> {
        let current_thread = current_thread!();
        let Some(posix_thread) = current_thread.as_posix_thread() else {
            return Ok(());
        };

        let metadata = self.metadata()?;
        let fsuid = posix_thread.credentials().fsuid();

        // The source inode owner can hardlink all they like.
        if fsuid == metadata.uid {
            return Ok(());
        }

        // Hardlinking to unreadable or unwritable sources is dangerous.
        if self
            .inode()
            .check_permission(Permission::MAY_READ | Permission::MAY_WRITE)
            .is_err()
        {
            return_errno_with_message!(
                Errno::EPERM,
                "the source is not permitted to be hard-linked"
            );
        }

        // Non-owners may only hard-link regular files.
        if self.type_() != InodeType::File {
            return_errno_with_message!(
                Errno::EPERM,
                "the source is not permitted to be hard-linked"
            );
        }

        // Hardlinking to setuid or executable setgid files requires CAP_FOWNER.
        if (metadata.mode.has_set_uid()
            || (metadata.mode.has_set_gid() && metadata.mode.is_group_executable()))
            && lsm_hooks::on_capable(lsm_hooks::CapableContext::new(
                UserNamespace::get_init_singleton().as_ref(),
                posix_thread,
                CapSet::FOWNER,
            ))
            .is_err()
        {
            return_errno_with_message!(
                Errno::EPERM,
                "the source is not permitted to be hard-linked"
            );
        }

        Ok(())
    }
}

fn try_get_mnt_ns_inode(dentry: &Dentry) -> Option<&NsInode<MountNamespace>> {
    dentry
        .inode()
        .as_ref()
        .downcast_ref::<NsInode<MountNamespace>>()
}

impl Path {
    /// Mounts a filesystem at the current path.
    ///
    /// This method attaches a given filesystem to the VFS tree at the location
    /// represented by `self`. The current path becomes the mountpoint for the new
    /// filesystem.
    ///
    /// Returns the newly created child mount on success.
    ///
    /// # Errors
    ///
    /// Returns `ENOTDIR` if the path is not a directory.
    /// Returns `EINVAL` if attempting to mount on root or if the path is not
    /// in the current mount namespace.
    pub(crate) fn mount(
        &self,
        fs_and_root: FsAndRoot,
        flags: PerMountFlags,
        source: Option<String>,
        ctx: &Context,
    ) -> Result<Arc<Mount>> {
        if self.type_() != InodeType::Dir {
            return_errno_with_message!(Errno::ENOTDIR, "the path is not a directory");
        }

        let fs_ref = ctx.thread_local.borrow_fs();
        let path_resolver = fs_ref.resolver().read();

        if path_resolver.root() == self {
            return_errno_with_message!(Errno::EINVAL, "the root cannot be mounted on");
        }

        let current_ns_proxy = ctx.thread_local.borrow_ns_proxy();
        let current_mnt_ns = current_ns_proxy.unwrap().mnt_ns();
        if !current_mnt_ns.owns(&self.mount) {
            return_errno_with_message!(Errno::EINVAL, "the path is not in this mount namespace");
        }

        let mut topology_guard = MountTopology::write_lock();
        self.mount.do_mount(
            fs_and_root,
            flags,
            &self.dentry,
            source,
            &mut topology_guard,
        )
    }

    /// Unmounts the filesystem mounted at the current path.
    ///
    /// Returns the unmounted child mount on success.
    ///
    /// # Errors
    ///
    /// Returns `EINVAL` in the following cases:
    /// - The current path is not a mount root.
    /// - The mount of the current path is the root mount.
    /// - The current path is not in the current mount namespace.
    pub(crate) fn unmount(&self, ctx: &Context) -> Result<Arc<Mount>> {
        if !self.is_mount_root() {
            return_errno_with_message!(Errno::EINVAL, "the path is not a mount root");
        }

        let Some(_mountpoint) = self.mount.mountpoint() else {
            return_errno_with_message!(Errno::EINVAL, "the root mount cannot be unmounted");
        };

        let current_ns_proxy = ctx.thread_local.borrow_ns_proxy();
        let current_mnt_ns = current_ns_proxy.unwrap().mnt_ns();
        if !current_mnt_ns.owns(&self.mount) {
            return_errno_with_message!(Errno::EINVAL, "the path is not in this mount namespace");
        }

        self.mount.sync()?;

        let mut topology_guard = MountTopology::write_lock();
        let Some(mountpoint) = self.mount.mountpoint() else {
            return_errno_with_message!(Errno::EINVAL, "the mount has been detached");
        };
        let parent_mount = self.mount.parent().unwrap().upgrade().unwrap();
        let child_mount = parent_mount.do_unmount(&mountpoint, &mut topology_guard)?;

        Ok(child_mount)
    }

    /// Remounts the filesystem with new `PerMountFlags` and optionally new `FsFlags`.
    ///
    /// If `fs_flags` is provided, it will update the flags of the mounted filesystem,
    /// otherwise, only the flags of the current mount will be updated.
    ///
    /// # Errors
    ///
    /// Returns `EINVAL` in the following cases:
    /// - The current path is not a mount root.
    /// - The current path is not in the current mount namespace.
    pub(crate) fn remount(
        &self,
        mount_flags: PerMountFlags,
        fs_flags: Option<FsFlags>,
        data: Option<&str>,
        ctx: &Context,
    ) -> Result<()> {
        if !self.is_mount_root() {
            return_errno_with_message!(Errno::EINVAL, "the path is not a mount root");
        };

        let current_ns_proxy = ctx.thread_local.borrow_ns_proxy();
        let current_mnt_ns = current_ns_proxy.unwrap().mnt_ns();
        if !current_mnt_ns.owns(&self.mount) {
            return_errno_with_message!(Errno::EINVAL, "the path is not in this mount namespace");
        }

        let mut topology_guard = MountTopology::write_lock();
        self.mount
            .remount(mount_flags, fs_flags, data, ctx, &mut topology_guard)
    }

    /// Creates a bind mount from the current path to the destination path.
    ///
    /// Creates a new mount tree that mirrors either the root mount (non-recursive)
    /// or the entire mount subtree (recursive), and attaches it to the destination path.
    ///
    /// A recursive bind omits unbindable subtrees.
    /// If the destination parent is shared,
    /// the new tree is also attached below its propagation receivers.
    ///
    /// # Errors
    ///
    /// Returns `ENOTDIR` if one of the source and destination is a directory
    /// and the other is not.
    ///
    /// Returns `EINVAL` if any of the following holds:
    /// - The destination path is not in the current mount namespace.
    /// - The source path is a mount namespace file that would create a namespace loop.
    /// - The source mount is unbindable.
    pub(crate) fn bind_mount_to(
        &self,
        dst_path: Self,
        recursive: bool,
        ctx: &Context,
    ) -> Result<()> {
        let can_bind = {
            let src_is_dir = self.type_() == InodeType::Dir;
            let dst_is_dir = dst_path.type_() == InodeType::Dir;
            (src_is_dir && dst_is_dir) || (!src_is_dir && !dst_is_dir)
        };
        if !can_bind {
            return_errno_with_message!(
                Errno::ENOTDIR,
                "the source and destination must both be directories or both be non-directories"
            );
        }

        let current_ns_proxy = ctx.thread_local.borrow_ns_proxy();
        let current_mnt_ns = current_ns_proxy.unwrap().mnt_ns();

        // Linux does not require the source path to belong to the current
        // mount namespace, but still rejects source mount namespace files that
        // would form loops.
        if !current_mnt_ns.owns(&dst_path.mount) {
            return_errno_with_message!(
                Errno::EINVAL,
                "the destination path is not in this mount namespace"
            );
        }
        if current_mnt_ns.would_form_mnt_ns_loop(&self.dentry) {
            return_errno_with_message!(
                Errno::EINVAL,
                "the source is a mount namespace file that would create a namespace loop"
            );
        }

        let mut topology_guard = MountTopology::write_lock();
        let current_mnt_ns_weak = Arc::downgrade(current_mnt_ns);
        let mut pending_changes = PendingPropagationChanges::default();
        let new_mount = self.mount.clone_mount_tree_deferred(
            &self.dentry,
            &current_mnt_ns_weak,
            recursive,
            MountTreeCloneMode::Bind,
            &mut pending_changes,
            &topology_guard,
        )?;
        let attachment =
            new_mount.prepare_mount_tree_attachment(dst_path, pending_changes, &topology_guard)?;
        attachment.attach(&mut topology_guard);
        Ok(())
    }

    /// Moves a mount tree from the current path to the destination path.
    ///
    /// If the destination parent is shared,
    /// corresponding clones are also attached below its propagation receivers.
    ///
    /// # Errors
    ///
    /// Returns `EINVAL` in the following cases:
    /// - The current path is not a mount root.
    /// - The mount of the current path is the root mount.
    /// - The source is a non-root mount in a detached mount tree.
    /// - The destination is in a detached mount tree while the source is not.
    /// - The source and destination are in the same detached mount tree.
    /// - One of the source and destination is a directory and the other is not.
    /// - The source mount's current parent is shared.
    /// - The destination mount is shared and the source tree contains an
    ///   unbindable mount.
    ///
    /// Returns `ELOOP` in the following cases:
    /// - The destination path is inside the subtree being moved.
    /// - The mount tree contains a mount namespace file that would create a namespace loop.
    pub(crate) fn move_mount_to(&self, dst_path: Self, ctx: &Context) -> Result<()> {
        if !self.is_mount_root() {
            return_errno_with_message!(Errno::EINVAL, "the path is not a mount root");
        };

        let current_ns_proxy = ctx.thread_local.borrow_ns_proxy();
        let current_mnt_ns = current_ns_proxy.unwrap().mnt_ns();
        if self.mount.id() == current_mnt_ns.root().id() {
            return_errno_with_message!(Errno::EINVAL, "the root mount can not be moved");
        }
        if !current_mnt_ns.owns(&self.mount) {
            return_errno_with_message!(
                Errno::EINVAL,
                "the source path is not in this mount namespace"
            );
        }
        if !current_mnt_ns.owns(&dst_path.mount) {
            return_errno_with_message!(
                Errno::EINVAL,
                "the destination path is not in this mount namespace"
            );
        }

        let mut topology_guard = MountTopology::write_lock();
        let source_tree_root = mount_tree_root(self.mount_node(), &topology_guard);
        let target_tree_root = mount_tree_root(dst_path.mount_node(), &topology_guard);
        let current_tree_root = current_mnt_ns.root();
        let source_is_detached = source_tree_root.id() != current_tree_root.id();
        let target_is_detached = target_tree_root.id() != current_tree_root.id();

        // Since Linux v6.15, a detached anonymous-namespace root can be
        // moved onto either the current mount namespace or an acceptable
        // anonymous namespace. Asterinas does not model anonymous mount
        // namespaces yet, so compare detached mount tree roots instead.
        // TODO: Once anonymous mount namespaces are modeled, determine
        // detachedness from the mount namespace directly instead of inferring it
        // from whether the mount tree root is the current namespace root.
        if source_is_detached && self.mount.id() != source_tree_root.id() {
            return_errno_with_message!(
                Errno::EINVAL,
                "only a detached mount tree root can be moved out of the detached tree"
            );
        }
        if !source_is_detached && target_is_detached {
            return_errno_with_message!(
                Errno::EINVAL,
                "the destination path is in a detached mount tree"
            );
        }
        if source_is_detached && source_tree_root.id() == target_tree_root.id() {
            return_errno_with_message!(
                Errno::EINVAL,
                "the source and destination are in the same detached mount tree"
            );
        }
        let source_is_dir = self.type_() == InodeType::Dir;
        let target_is_dir = dst_path.type_() == InodeType::Dir;
        if source_is_dir != target_is_dir {
            return_errno_with_message!(
                Errno::EINVAL,
                "the source and destination must both be directories or both be non-directories"
            );
        }

        current_mnt_ns.check_no_mnt_ns_loop_in_tree(self.mount_node(), &topology_guard)?;
        if dst_path
            .mount_node()
            .is_equal_or_descendant_of(self.mount_node(), &topology_guard)
        {
            // Reject moves that would place a mount beneath itself, because the mount tree
            // must remain acyclic.
            return_errno_with_message!(
                Errno::ELOOP,
                "the destination path is inside the mount subtree being moved"
            );
        }
        if self
            .mount
            .parent()
            .and_then(|parent| parent.upgrade())
            .is_some_and(|parent| parent.is_shared())
        {
            return_errno_with_message!(
                Errno::EINVAL,
                "moving a mount under a shared parent is not supported"
            );
        }
        if dst_path.mount_node().is_shared() {
            self.mount.try_walk_tree(|mount| {
                if mount.is_unbindable() {
                    return_errno_with_message!(
                        Errno::EINVAL,
                        "an unbindable mount tree cannot be moved under a shared mount"
                    );
                }
                Ok(())
            })?;
        }

        let pending_changes = PendingPropagationChanges::default();
        let attachment =
            self.mount
                .prepare_mount_tree_attachment(dst_path, pending_changes, &topology_guard)?;
        attachment.attach(&mut topology_guard);

        Ok(())
    }

    /// Sets the propagation policy of this path's mount.
    ///
    /// If `recursive` is `true`,
    /// the same requested transition is applied independently
    /// to every mount in the subtree.
    ///
    /// # Errors
    ///
    /// Returns `EINVAL` if this path is not a mount root
    /// or its mount does not belong to the current mount namespace.
    /// Returns `ENOMEM` if the transition requires a new peer group
    /// and the peer-group ID pool is exhausted.
    pub(crate) fn set_propagation(
        &self,
        prop: MountPropType,
        recursive: bool,
        ctx: &Context,
    ) -> Result<()> {
        if !self.is_mount_root() {
            return_errno_with_message!(Errno::EINVAL, "the path is not a mount root");
        };

        let current_ns_proxy = ctx.thread_local.borrow_ns_proxy();
        let current_mnt_ns = current_ns_proxy.unwrap().mnt_ns();
        if !current_mnt_ns.owns(&self.mount) {
            return_errno_with_message!(Errno::EINVAL, "the path is not in this mount namespace");
        }

        let mut topology_guard = MountTopology::write_lock();
        let mut pending_changes = PendingPropagationChanges::default();
        self.mount.set_propagation_deferred(
            prop,
            recursive,
            &mut pending_changes,
            &topology_guard,
        )?;
        pending_changes.commit(&mut topology_guard);
        Ok(())
    }
}

fn mount_tree_root(mount: &Arc<Mount>, _topology: &MountTopology) -> Arc<Mount> {
    let mut root = mount.clone();
    while let Some(parent) = root.parent().and_then(|parent| parent.upgrade()) {
        root = parent;
    }

    root
}

// Methods inherited from `Dentry`.
#[inherit_methods(from = "self.dentry")]
impl Path {
    pub(crate) fn inode(&self) -> &Arc<dyn Inode>;
    pub(crate) fn type_(&self) -> InodeType;
    pub(crate) fn name(&self) -> String;

    /// Creates a `Path` by making an inode of the `type_` with the `mode`.
    pub(crate) fn mknod(&self, name: &str, mode: InodeMode, type_: MknodType) -> Result<Self> {
        let dir_dentry = self.dentry.as_dir_dentry_or_err()?;
        self.check_dir_entry_mutation()?;
        let inner = dir_dentry.mknod(name, mode, type_)?;
        Ok(Self::new(self.mount.clone(), inner))
    }

    /// Links a new name for the `Path`.
    pub(crate) fn link(&self, old: &Self, name: &str) -> Result<()> {
        if !Arc::ptr_eq(&old.mount, &self.mount) {
            return_errno_with_message!(Errno::EXDEV, "the operation cannot cross mounts");
        }

        let dir_dentry = self.dentry.as_dir_dentry_or_err()?;
        old.check_hardlink_source()?;
        self.check_dir_entry_mutation()?;
        dir_dentry.link(&old.dentry, name)
    }

    /// Unlinks a name from the `Path`.
    pub(crate) fn unlink(&self, name: &str) -> Result<()> {
        let dir_dentry = self.dentry.as_dir_dentry_or_err()?;
        self.check_dir_entry_mutation()?;
        dir_dentry.unlink(name)
    }

    /// Removes a directory by `rmdir()` the inner inode.
    pub(crate) fn rmdir(&self, name: &str) -> Result<()> {
        let dir_dentry = self.dentry.as_dir_dentry_or_err()?;
        self.check_dir_entry_mutation()?;
        dir_dentry.rmdir(name)
    }

    /// Renames a `Path` to the new `Path` by `rename()` the inner inode.
    pub(crate) fn rename(
        &self,
        old_name: &str,
        new_dir: &Self,
        new_name: &str,
        mode: RenameMode,
    ) -> Result<()> {
        if !Arc::ptr_eq(&self.mount, &new_dir.mount) {
            return_errno_with_message!(Errno::EXDEV, "the operation cannot cross mounts");
        }

        let old_dir_dentry = self.dentry.as_dir_dentry_or_err()?;
        let new_dir_dentry = new_dir.dentry.as_dir_dentry_or_err()?;

        self.check_dir_entry_mutation()?;
        if !Arc::ptr_eq(&self.dentry, &new_dir.dentry) {
            new_dir.check_dir_entry_mutation()?;
        }

        old_dir_dentry.rename(old_name, &new_dir_dentry, new_name, mode)
    }

    /// Changes the mode after checking mount writability and the caller's permissions.
    pub(crate) fn chmod(&self, mut mode: InodeMode, ctx: &Context) -> Result<()> {
        self.check_mount_writable()?;

        // FIXME: Keep the ownership checks and mode update in one inode critical
        // section. `metadata()` returns a snapshot, so a concurrent `chown()` can
        // change the owner or group before `set_mode()` runs.
        let metadata = self.metadata()?;
        let credentials = ctx.posix_thread.credentials();
        let user_ns = ctx.thread_local.borrow_user_ns();

        if credentials.fsuid() != metadata.uid {
            lsm_hooks::on_capable(lsm_hooks::CapableContext::new(
                user_ns.as_ref(),
                ctx.posix_thread,
                CapSet::FOWNER,
            ))?;
        }

        // If the caller is not in the file's group and lacks `CAP_FSETID`,
        // Linux silently clears the requested `S_ISGID` bit.
        // Reference: <https://man7.org/linux/man-pages/man2/chmod.2.html>.
        if mode.contains(InodeMode::S_ISGID)
            && !credentials.has_group_for_fs_access(metadata.gid)
            && lsm_hooks::on_capable(lsm_hooks::CapableContext::new(
                user_ns.as_ref(),
                ctx.posix_thread,
                CapSet::FSETID,
            ))
            .is_err()
        {
            mode.remove(InodeMode::S_ISGID);
        }

        self.set_mode(mode)?;
        notify::on_attr_change(self);
        Ok(())
    }
}

// Methods inherited from `Inode`.
#[inherit_methods(from = "self.inode()")]
impl Path {
    pub(crate) fn fs(&self) -> Arc<dyn FileSystem>;
    pub(crate) fn sync(&self, mode: SyncMode) -> Result<()>;
    pub(crate) fn metadata(&self) -> Result<Metadata>;
    pub(crate) fn mode(&self) -> Result<InodeMode>;
    pub(crate) fn size(&self) -> usize;
    pub(crate) fn owner(&self) -> Result<Uid>;
    pub(crate) fn group(&self) -> Result<Gid>;
    pub(crate) fn atime(&self) -> Duration;
    pub(crate) fn mtime(&self) -> Duration;
    pub(crate) fn ctime(&self) -> Duration;
    pub(crate) fn list_xattr(
        &self,
        namespace: XattrNamespace,
        list_writer: &mut VmWriter,
    ) -> Result<usize>;

    pub(crate) fn set_mode(&self, mode: InodeMode) -> Result<()> {
        self.inode().set_mode(&self.dentry, mode)
    }

    pub(crate) fn set_owner(&self, uid: Uid) -> Result<()> {
        self.inode().set_owner(&self.dentry, uid)
    }

    pub(crate) fn set_group(&self, gid: Gid) -> Result<()> {
        self.inode().set_group(&self.dentry, gid)
    }

    pub(crate) fn set_atime(&self, time: Duration) {
        self.inode().set_atime(&self.dentry, time)
    }

    pub(crate) fn set_mtime(&self, time: Duration) {
        self.inode().set_mtime(&self.dentry, time)
    }

    pub(crate) fn set_ctime(&self, time: Duration) {
        self.inode().set_ctime(&self.dentry, time)
    }

    /// Updates explicit timestamps and propagates backing-store preparation errors.
    pub(crate) fn set_times(
        &self,
        atime: Option<Duration>,
        mtime: Option<Duration>,
        ctime: Duration,
    ) -> Result<()> {
        self.check_mount_writable()?;
        self.inode().set_times(&self.dentry, atime, mtime, ctime)
    }

    /// Resizes the file.
    pub(crate) fn resize(&self, size: usize) -> Result<()> {
        self.inode().check_permission(Permission::MAY_WRITE)?;
        self.resize_unchecked_access(size)
    }

    /// Resizes the file without permission checks.
    pub(in crate::fs) fn resize_unchecked_access(&self, size: usize) -> Result<()> {
        let inode = self.inode();
        xattr::clear_file_priv(&self.dentry)?;
        inode.resize(&self.dentry, size)
    }

    /// Sets an xattr of the file.
    pub(crate) fn set_xattr(
        &self,
        name: XattrName,
        value_reader: &mut VmReader,
        flags: XattrSetFlags,
        ctx: &Context,
    ) -> Result<()> {
        let inode = self.inode();
        if name.full_name() == xattr::SECURITY_CAPABILITY_XATTR_NAME {
            capable_modify_file_cap(inode.as_ref(), ctx)?;
        } else {
            inode.check_permission(Permission::MAY_WRITE)?;
        }
        inode.set_xattr(&self.dentry, name, value_reader, flags)
    }

    /// Gets an xattr of the file.
    pub(crate) fn get_xattr(&self, name: XattrName, value_writer: &mut VmWriter) -> Result<usize> {
        let inode = self.inode();
        inode.check_permission(Permission::MAY_READ)?;
        inode.get_xattr(name, value_writer)
    }

    /// Removes an xattr of the file.
    pub(crate) fn remove_xattr(&self, name: XattrName, ctx: &Context) -> Result<()> {
        let inode = self.inode();
        if name.full_name() == xattr::SECURITY_CAPABILITY_XATTR_NAME {
            capable_modify_file_cap(inode.as_ref(), ctx)?;
        } else {
            inode.check_permission(Permission::MAY_WRITE)?;
        }
        inode.remove_xattr(&self.dentry, name)
    }
}

fn capable_modify_file_cap(inode: &dyn Inode, ctx: &Context) -> Result<()> {
    lsm_hooks::on_capable(lsm_hooks::CapableContext::new(
        ctx.thread_local.borrow_user_ns().as_ref(),
        ctx.posix_thread,
        CapSet::SETFCAP,
    ))?;

    // With the currently supported identity user-namespace mapping, only invalid IDs are
    // unmapped. Replace this with mount-idmap-aware namespace mapping checks when supported.
    let metadata = inode.metadata()?;
    if metadata.uid == Uid::INVALID || metadata.gid == Gid::INVALID {
        return_errno_with_message!(
            Errno::EPERM,
            "the inode owner or group is not mapped in the current user namespace"
        );
    }

    Ok(())
}

/// Checks if the file name is ".", indicating it's the current directory.
pub(crate) const fn is_dot(filename: &str) -> bool {
    let name_bytes = filename.as_bytes();
    name_bytes.len() == 1 && name_bytes[0] == DOT_BYTE
}

/// Checks if the file name is "..", indicating it's the parent directory.
pub(crate) const fn is_dotdot(filename: &str) -> bool {
    let name_bytes = filename.as_bytes();
    name_bytes.len() == 2 && name_bytes[0] == DOT_BYTE && name_bytes[1] == DOT_BYTE
}

/// Checks if the file name is "." or "..", indicating it's the current or parent directory.
pub(crate) const fn is_dot_or_dotdot(filename: &str) -> bool {
    let name_bytes = filename.as_bytes();
    let name_len = name_bytes.len();
    if name_len == 1 {
        name_bytes[0] == DOT_BYTE
    } else if name_len == 2 {
        name_bytes[0] == DOT_BYTE && name_bytes[1] == DOT_BYTE
    } else {
        false
    }
}

const DOT_BYTE: u8 = b'.';

pub(super) fn init() {
    mount::init();
}
