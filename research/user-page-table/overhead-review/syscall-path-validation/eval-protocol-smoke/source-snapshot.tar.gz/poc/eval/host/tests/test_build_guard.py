"""Tests for build_guard.py."""

import gzip
from pathlib import Path
import tempfile
import unittest

from host.build_guard import (
    check_kernel_config_text,
    generate_and_write_archive,
    verify_shared_payload,
)
from host.qemu_driver import _cpio_newc_file_entry, _cpio_newc_trailer


VALID_PERF_BASE = """
CONFIG_CC_OPTIMIZE_FOR_PERFORMANCE=y
# CONFIG_CC_OPTIMIZE_FOR_SIZE is not set
# CONFIG_INIT_STACK_ALL_ZERO is not set
# CONFIG_DEBUG_ATOMIC_SLEEP is not set
# CONFIG_SCHEDSTATS is not set
# CONFIG_TRANSPARENT_HUGEPAGE_ALWAYS is not set
# CONFIG_X86_VSYSCALL_EMULATION is not set
CONFIG_ADVISE_SYSCALLS=y
CONFIG_PERF_EVENTS=y
CONFIG_KERNELET=y
CONFIG_VM_EVENT_COUNTERS=y
CONFIG_TMPFS=y
CONFIG_SHMEM=y
CONFIG_CGROUPS=y
CONFIG_MODULES=y
CONFIG_MODULE_UNLOAD=y
CONFIG_KALLSYMS=y
# CONFIG_CPU_MITIGATIONS is not set
# CONFIG_MITIGATION_PAGE_TABLE_ISOLATION is not set
"""


class BuildGuardTests(unittest.TestCase):
    def test_valid_perf_base(self) -> None:
        self.assertEqual(check_kernel_config_text(VALID_PERF_BASE, "perf-base"), [])

    def test_rejects_os_and_debug_atomic_sleep(self) -> None:
        bad = VALID_PERF_BASE.replace(
            "# CONFIG_CC_OPTIMIZE_FOR_SIZE is not set", "CONFIG_CC_OPTIMIZE_FOR_SIZE=y"
        ).replace(
            "# CONFIG_DEBUG_ATOMIC_SLEEP is not set", "CONFIG_DEBUG_ATOMIC_SLEEP=y"
        )
        errs = check_kernel_config_text(bad, "perf-base")
        self.assertTrue(any("CONFIG_CC_OPTIMIZE_FOR_SIZE" in e for e in errs))
        self.assertTrue(any("CONFIG_DEBUG_ATOMIC_SLEEP" in e for e in errs))

    def test_perf_pti_profile(self) -> None:
        errs = check_kernel_config_text(VALID_PERF_BASE, "perf-pti")
        self.assertEqual(len(errs), 2)
        pti_ok = (
            VALID_PERF_BASE
            + "\nCONFIG_CPU_MITIGATIONS=y\nCONFIG_MITIGATION_PAGE_TABLE_ISOLATION=y\n"
        )
        self.assertEqual(check_kernel_config_text(pti_ok, "perf-pti"), [])

    def _make_initrd(
        self,
        path: Path,
        payload_bytes: bytes,
        *,
        include_kernelet: bool = True,
    ) -> None:
        parts = [
            _cpio_newc_file_entry("payload/eval-payload.cpio", payload_bytes, mode=0o100644),
        ]
        if include_kernelet:
            parts.extend(
                [
                    _cpio_newc_file_entry("modules/endovisor.ko", b"ko-bytes", mode=0o100644),
                    _cpio_newc_file_entry("bin/run-kernelet", b"runner-bytes", mode=0o100755),
                    _cpio_newc_file_entry("kernelet-image.elf", b"elf-bytes", mode=0o100755),
                ]
            )
        parts.append(_cpio_newc_trailer())
        path.write_bytes(gzip.compress(b"".join(parts)))

    def test_verify_shared_payload_embedded_and_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tdp = Path(td)
            ext = tdp / "eval-payload.cpio"
            ext.write_bytes(b"identical-cpio")
            initrd_ok = tdp / "initrd-ok.cpio.gz"
            self._make_initrd(initrd_ok, b"identical-cpio", include_kernelet=True)
            h, embedded = verify_shared_payload(
                payload_path=ext,
                host_initrd_path=initrd_ok,
                targets=["L", "A", "K", "K_vma"],
            )
            self.assertEqual(len(h), 64)
            self.assertEqual(embedded["payload/eval-payload.cpio"], h)

            initrd_stale = tdp / "initrd-stale.cpio.gz"
            self._make_initrd(initrd_stale, b"stale-cpio", include_kernelet=True)
            with self.assertRaises(ValueError):
                verify_shared_payload(
                    payload_path=ext,
                    host_initrd_path=initrd_stale,
                    targets=["L", "K"],
                )

            initrd_no_k = tdp / "initrd-no-k.cpio.gz"
            self._make_initrd(initrd_no_k, b"identical-cpio", include_kernelet=False)
            with self.assertRaises(ValueError):
                verify_shared_payload(
                    payload_path=ext,
                    host_initrd_path=initrd_no_k,
                    targets=["K"],
                )

    def test_generate_and_write_archive(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tdp = Path(td)
            ext = tdp / "eval-payload.cpio"
            ext.write_bytes(b"payload-data")
            initrd = tdp / "host.cpio.gz"
            self._make_initrd(initrd, b"payload-data", include_kernelet=True)
            cfg = tdp / "perf-base.config"
            cfg.write_text(VALID_PERF_BASE, encoding="utf-8")
            out_dir = tdp / "out"
            manifest = generate_and_write_archive(
                run_id="r1",
                out_dir=out_dir,
                repo_root=tdp,
                targets=["L", "K"],
                rounds=1,
                seed=42,
                payload_path=ext,
                host_initrd_path=initrd,
                artifacts={"payload": ext},
                kernel_configs={"perf_base": (cfg, "perf-base")},
            )
            self.assertTrue((out_dir / "manifest.json").exists())
            self.assertTrue((out_dir / "perf_base.config").exists())
            self.assertEqual(manifest.kernel_config_checks["perf_base"], [])
            self.assertIn("modules/endovisor.ko", manifest.embedded_artifacts_sha256)


if __name__ == "__main__":
    unittest.main()
