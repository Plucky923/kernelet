"""Tests for report.py and perf_sym.py."""

from pathlib import Path
import tempfile
import unittest

from host.cli import _linux_mitigation_cmdline, _verify_batch_completeness
from host.perf_sym import (
    parse_readelf_module_symbols,
    parse_readelf_pie_symbols,
    synthesize_guest_kallsyms,
)
from host.report import render_csv_report, render_markdown_report, schedule_rounds
from host.schema import CaseRecord, CaseSpec, InvariantSpec


class ReportAndPerfSymTests(unittest.TestCase):
    def test_schedule_rounds_deterministic(self) -> None:
        s1 = schedule_rounds(["L", "A", "K"], 5, 20261116)
        s2 = schedule_rounds(["L", "A", "K"], 5, 20261116)
        self.assertEqual(s1, s2)
        self.assertEqual(len(s1), 5)
        for row in s1:
            self.assertEqual(sorted(row), ["A", "K", "L"])

    def test_render_markdown_and_csv(self) -> None:
        spec = CaseSpec(
            case_id="sys.lm.null",
            group="syscall",
            suite="lmbench",
            binary="/bin/lat_syscall",
            args=("-P", "1", "null"),
            cpus=(0,),
            tmpfiles=(),
            parser="lmbench_latency",
            unit="us/op",
            higher_is_better=False,
            invariants=InvariantSpec(),
        )
        recs = [
            CaseRecord(1, "L", "sys.lm.null", 0, 100, 0, 0, 1, 1, 0, 0, False, 0, "", "", 0.10, "us/op", True),
            CaseRecord(1, "A", "sys.lm.null", 0, 100, 0, 0, 1, 1, 0, 0, False, -1, "", "", 0.20, "us/op", True),
            CaseRecord(1, "K", "sys.lm.null", 0, 100, 0, 0, 1, 1, 0, 0, False, -1, "", "", 0.30, "us/op", True),
        ]
        md = render_markdown_report({"sys.lm.null": spec}, recs, ["L", "A", "K"])
        self.assertIn("sys.lm.null", md)
        self.assertIn("3.00x", md)
        self.assertIn("1.50x", md)
        csv_text = render_csv_report({"sys.lm.null": spec}, recs, ["L", "A", "K"])
        self.assertIn("sys.lm.null,syscall,lmbench,K,us/op,False,OK,1,0.300000", csv_text)

        skipped_rec = CaseRecord(
            1, "L", "sys.lm.null", -1, 0, 0, 0, 0, 0, -1, -1, False, None, "", "", None, "us/op", True, [], None, True, "no timer window fault obs"
        )
        md_skip = render_markdown_report({"sys.lm.null": spec}, [skipped_rec], ["L"])
        self.assertIn("SKIPPED (no timer window fault obs)", md_skip)
        csv_skip = render_csv_report({"sys.lm.null": spec}, [skipped_rec], ["L"])
        self.assertIn("SKIPPED:no timer window fault obs", csv_skip)

    def test_perf_sym_relocation_and_batch_completeness(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            sysmap = Path(td) / "System.map"
            sysmap.write_text("ffffffff81000000 T startup_64\nffffffff81001234 t do_syscall_64\n")
            merged = synthesize_guest_kallsyms(vmlinux_system_map=sysmap)
            self.assertIn("ffffffff81000000 T startup_64", merged)
            self.assertIn("ffffffff81001234 t do_syscall_64", merged)

        sec_text = (
            "  [ 1] .text PROGBITS 0000000000000000\n"
            "  [ 2] .init.text PROGBITS 0000000000000000\n"
            "  [ 3] .exit.text PROGBITS 0000000000000000\n"
        )
        sym_text = (
            "   1: 0000000000000010   64 FUNC    GLOBAL DEFAULT    1 run_sandbox\n"
            "   2: 0000000000000020   32 FUNC    LOCAL  DEFAULT    2 init_endovisor\n"
            "   3: 0000000000000000   16 FUNC    LOCAL  DEFAULT    3 exit_endovisor\n"
        )
        syms = parse_readelf_module_symbols(
            sec_text,
            sym_text,
            {".text": 0xFFFFFFFFC0001000, ".init.text": 0xFFFFFFFFC0020000},
        )
        by_name = {s.name: s for s in syms}
        self.assertEqual(by_name["run_sandbox"].addr, 0xFFFFFFFFC0001010)
        self.assertEqual(by_name["init_endovisor"].addr, 0xFFFFFFFFC0020020)
        self.assertNotIn("exit_endovisor", by_name)

        pie_syms = parse_readelf_pie_symbols(
            "   4: 0000000000004000  128 FUNC    GLOBAL DEFAULT   10 kernel_main\n",
            0xFFFF800000100000,
        )
        self.assertEqual(pie_syms[0].addr, 0xFFFF800000104000)

        self.assertEqual(_linux_mitigation_cmdline("perf-base"), "mitigations=off")
        self.assertEqual(_linux_mitigation_cmdline("perf-pti"), "pti=on")

        spec = CaseSpec(
            case_id="c1",
            group="g",
            suite="s",
            binary="/b",
            args=(),
            cpus=(0,),
            tmpfiles=(),
            parser="noop_rc",
            unit="rc",
            higher_is_better=False,
            invariants=InvariantSpec(),
        )
        with self.assertRaises(RuntimeError):
            _verify_batch_completeness([], round_idx=1, target="L", runnable_specs={"c1": spec})


if __name__ == "__main__":
    unittest.main()
