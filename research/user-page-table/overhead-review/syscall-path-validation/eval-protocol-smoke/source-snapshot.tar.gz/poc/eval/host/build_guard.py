"""Build isolation checks, embedded CPIO SHA-256 verification, and RunManifest archival."""

from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from typing import Any

from .schema import RunManifest


REQUIRED_BASE_OPTIONS: dict[str, str] = {
    "CONFIG_CC_OPTIMIZE_FOR_PERFORMANCE": "y",
    "CONFIG_ADVISE_SYSCALLS": "y",
    "CONFIG_PERF_EVENTS": "y",
    "CONFIG_KERNELET": "y",
    "CONFIG_VM_EVENT_COUNTERS": "y",
    "CONFIG_TMPFS": "y",
    "CONFIG_SHMEM": "y",
    "CONFIG_CGROUPS": "y",
    "CONFIG_MODULES": "y",
    "CONFIG_MODULE_UNLOAD": "y",
    "CONFIG_KALLSYMS": "y",
}

FORBIDDEN_PERF_OPTIONS: tuple[str, ...] = (
    "CONFIG_CC_OPTIMIZE_FOR_SIZE",
    "CONFIG_INIT_STACK_ALL_ZERO",
    "CONFIG_DEBUG_ATOMIC_SLEEP",
    "CONFIG_SCHEDSTATS",
    "CONFIG_TRANSPARENT_HUGEPAGE_ALWAYS",
    "CONFIG_X86_VSYSCALL_EMULATION",
)


def parse_kernel_config(config_text: str) -> dict[str, str]:
    """Parse a Linux .config file into option -> value ('y', 'm', 'n', or string)."""
    options: dict[str, str] = {}
    for raw_line in config_text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("# CONFIG_") and line.endswith(" is not set"):
            key = line[2 : -len(" is not set")].strip()
            options[key] = "n"
            continue
        if line.startswith("#") or "=" not in line:
            continue
        key, val = line.split("=", 1)
        options[key.strip()] = val.strip()
    return options


def check_kernel_config_text(config_text: str, profile: str = "perf-base") -> list[str]:
    """Return a list of config violations for the given profile ('perf-base' or 'perf-pti')."""
    if profile not in ("perf-base", "perf-pti"):
        raise ValueError(f"unknown kernel config profile: {profile!r}")

    opts = parse_kernel_config(config_text)
    errors: list[str] = []

    for key, expected in REQUIRED_BASE_OPTIONS.items():
        actual = opts.get(key)
        if actual != expected:
            errors.append(f"{key}: expected {expected!r}, got {actual!r}")

    for key in FORBIDDEN_PERF_OPTIONS:
        if opts.get(key) in ("y", "m"):
            errors.append(f"{key}: forbidden in perf build (got {opts.get(key)!r})")

    if profile == "perf-base":
        for key in ("CONFIG_CPU_MITIGATIONS", "CONFIG_MITIGATION_PAGE_TABLE_ISOLATION"):
            if opts.get(key) == "y":
                errors.append(f"{key}: must be disabled in perf-base")
    elif profile == "perf-pti":
        for key in ("CONFIG_CPU_MITIGATIONS", "CONFIG_MITIGATION_PAGE_TABLE_ISOLATION"):
            if opts.get(key) != "y":
                errors.append(f"{key}: expected 'y' in perf-pti, got {opts.get(key)!r}")

    return errors


def check_kernel_config(config_path: Path, profile: str = "perf-base") -> list[str]:
    """Read and validate a Linux .config file; raises FileNotFoundError if missing."""
    return check_kernel_config_text(config_path.read_text(encoding="utf-8"), profile=profile)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    """Compute hex SHA-256 of a file."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1 << 20)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def extract_cpio_member_hashes(
    cpio_or_gz_path: Path,
    members: tuple[str, ...],
) -> dict[str, str]:
    """Hash selected archive inputs using GNU gzip and cpio."""
    raw = subprocess.run(
        ["gzip", "--decompress", "--stdout", "--force", "--", str(cpio_or_gz_path)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
    ).stdout
    listing = subprocess.run(
        ["cpio", "--list", "--quiet"], input=raw,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
    )
    names = {
        name.removeprefix("./"): name
        for name in listing.stdout.decode("utf-8").splitlines()
    }
    hashes: dict[str, str] = {}
    for member in members:
        if member not in names:
            continue
        content = subprocess.run(
            ["cpio", "--extract", "--to-stdout", "--quiet", "--", names[member]],
            input=raw, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
        ).stdout
        if not content:
            raise ValueError(f"{cpio_or_gz_path}: empty required artifact {member}")
        hashes[member] = sha256_bytes(content)
    return hashes


def verify_shared_payload(
    *,
    payload_path: Path,
    host_initrd_path: Path | None,
    targets: list[str],
) -> tuple[str, dict[str, str]]:
    """Verify external payload SHA-256 matches the embedded payload in host initrd."""
    ext_hash = sha256_file(payload_path)
    embedded_hashes: dict[str, str] = {}
    if any(t != "A" for t in targets):
        if host_initrd_path is None or not host_initrd_path.exists():
            raise FileNotFoundError(f"missing host initramfs: {host_initrd_path}")
        members = ("payload/eval-payload.cpio",)
        if any(t.startswith("K") for t in targets):
            members += ("modules/endovisor.ko", "bin/run-kernelet", "kernelet-image.elf")
        embedded_hashes = extract_cpio_member_hashes(host_initrd_path, members)
        embedded_payload = embedded_hashes.get("payload/eval-payload.cpio")
        if embedded_payload is None:
            raise ValueError(f"{host_initrd_path}: missing embedded payload/eval-payload.cpio")
        if embedded_payload != ext_hash:
            raise ValueError(
                f"embedded payload SHA-256 ({embedded_payload}) != external payload ({ext_hash})"
            )
        if any(t.startswith("K") for t in targets):
            for required in ("modules/endovisor.ko", "bin/run-kernelet", "kernelet-image.elf"):
                if required not in embedded_hashes:
                    raise ValueError(f"{host_initrd_path}: missing required Kernelet artifact {required}")
    return ext_hash, embedded_hashes


def _git_info(repo_dir: Path) -> tuple[str, bool, str]:
    try:
        commit = subprocess.check_output(
            ["git", "-C", str(repo_dir), "rev-parse", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        status = subprocess.check_output(
            ["git", "-C", str(repo_dir), "status", "--porcelain"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        diff = subprocess.check_output(
            ["git", "-C", str(repo_dir), "diff", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return commit, bool(status), diff
    except Exception:
        return "unknown", False, ""


def _host_cpu_info() -> tuple[str, int, list[str], list[dict[str, Any]]]:
    model = "unknown"
    cpuinfo = Path("/proc/cpuinfo")
    if cpuinfo.exists():
        for line in cpuinfo.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith("model name"):
                model = line.split(":", 1)[1].strip()
                break
    cpu_dirs = sorted(
        (p for p in Path("/sys/devices/system/cpu").glob("cpu[0-9]*") if p.name[3:].isdigit()),
        key=lambda p: int(p.name[3:]),
    )
    governors: list[str] = []
    topology: list[dict[str, Any]] = []
    for cpu_dir in cpu_dirs:
        cpu_id = int(cpu_dir.name[3:])
        entry: dict[str, Any] = {"cpu": cpu_id}
        sib = cpu_dir / "topology" / "thread_siblings_list"
        if sib.exists():
            entry["thread_siblings"] = sib.read_text(encoding="utf-8").strip()
        core_id = cpu_dir / "topology" / "core_id"
        if core_id.exists():
            entry["core_id"] = core_id.read_text(encoding="utf-8").strip()
        gov_file = cpu_dir / "cpufreq" / "scaling_governor"
        if gov_file.exists():
            gov = gov_file.read_text(encoding="utf-8").strip()
            governors.append(gov)
            entry["scaling_governor"] = gov
        cur_freq = cpu_dir / "cpufreq" / "scaling_cur_freq"
        if cur_freq.exists():
            entry["scaling_cur_freq"] = cur_freq.read_text(encoding="utf-8").strip()
        topology.append(entry)
    return model, len(cpu_dirs), sorted(set(governors)), topology


def generate_and_write_archive(
    *,
    run_id: str,
    out_dir: Path,
    repo_root: Path,
    targets: list[str],
    rounds: int,
    seed: int,
    payload_path: Path,
    host_initrd_path: Path | None,
    artifacts: dict[str, Path],
    kernel_configs: dict[str, tuple[Path, str]],
) -> RunManifest:
    """Verify artifacts, archive patches/configs, and write manifest.json."""
    out_dir.mkdir(parents=True, exist_ok=True)
    payload_hash, embedded_hashes = verify_shared_payload(
        payload_path=payload_path,
        host_initrd_path=host_initrd_path,
        targets=targets,
    )

    root_commit, root_dirty, root_diff = _git_info(repo_root)
    poc_dir = repo_root / "poc"
    poc_commit, poc_dirty, poc_diff = _git_info(poc_dir)

    if root_diff:
        (out_dir / "root_git_diff.patch").write_text(root_diff, encoding="utf-8")
    if poc_diff:
        (out_dir / "poc_git_diff.patch").write_text(poc_diff, encoding="utf-8")

    artifact_hashes: dict[str, str] = {}
    for name, path in sorted(artifacts.items()):
        if path.exists():
            artifact_hashes[name] = sha256_file(path)

    config_checks: dict[str, list[str]] = {}
    for name, (cfg_path, profile) in sorted(kernel_configs.items()):
        if cfg_path.exists():
            config_checks[name] = check_kernel_config(cfg_path, profile)
            shutil.copy2(cfg_path, out_dir / f"{name}.config")
        else:
            config_checks[name] = [f"missing config: {cfg_path}"]

    cpu_model, cpu_count, governors, topology = _host_cpu_info()
    manifest = RunManifest(
        run_id=run_id,
        created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        git_commit=root_commit,
        git_dirty=root_dirty,
        poc_git_commit=poc_commit,
        poc_git_dirty=poc_dirty,
        targets=list(targets),
        rounds=rounds,
        seed=seed,
        payload_sha256=payload_hash,
        artifacts_sha256=artifact_hashes,
        embedded_artifacts_sha256=embedded_hashes,
        kernel_config_checks=config_checks,
        host_cpu_model=cpu_model,
        host_cpu_count=cpu_count,
        host_governors=governors,
        host_cpu_topology=topology,
    )
    (out_dir / "manifest.json").write_text(
        json.dumps(manifest.to_dict(), indent=2) + "\n", encoding="utf-8"
    )
    return manifest
