"""Host-side orchestration, parsing, invariant checks, and reporting for poc/eval."""
