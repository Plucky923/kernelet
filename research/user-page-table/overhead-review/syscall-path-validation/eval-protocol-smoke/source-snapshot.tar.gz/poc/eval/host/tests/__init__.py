"""Offline unit tests for poc/eval host control plane."""
