// SPDX-License-Identifier: GPL-2.0
//
// Universal single-case guest runner shared identically by L, A, and K.
//
// Prepares declared temporary files and executable copies, verifies helper
// execution when requested, enforces CPU affinity across parent/child/procfs,
// captures wait4 rusage deltas, and emits one `EVAL_CASE_JSON {...}` frame.

#define _GNU_SOURCE

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <poll.h>
#include <sched.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mount.h>
#include <sys/reboot.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define MAX_TMPFILES 16
#define MAX_COPYFILES 16
#define MAX_IO_BYTES (512 * 1024)

struct tmpfile_req {
	char path[256];
	long size_mb;
};

struct copyfile_req {
	char src[256];
	char dst[256];
};

struct mem_buf {
	uint8_t *data;
	size_t len;
	size_t cap;
};

static int buf_append(struct mem_buf *b, const uint8_t *src, size_t n)
{
	if (n > MAX_IO_BYTES - b->len) {
		errno = EOVERFLOW;
		return -1;
	}
	if (b->len + n > b->cap) {
		size_t ncap = b->cap ? b->cap * 2 : 4096;
		while (ncap < b->len + n)
			ncap *= 2;
		uint8_t *nd = realloc(b->data, ncap);
		if (!nd)
			return -1;
		b->data = nd;
		b->cap = ncap;
	}
	memcpy(b->data + b->len, src, n);
	b->len += n;
	return 0;
}

static void print_base64(const uint8_t *data, size_t len)
{
	static const char tbl[] =
		"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	for (size_t i = 0; i < len; i += 3) {
		uint32_t v = (uint32_t)data[i] << 16;
		int rem = (int)(len - i);
		if (rem > 1)
			v |= (uint32_t)data[i + 1] << 8;
		if (rem > 2)
			v |= (uint32_t)data[i + 2];
		putchar(tbl[(v >> 18) & 0x3f]);
		putchar(tbl[(v >> 12) & 0x3f]);
		putchar(rem > 1 ? tbl[(v >> 6) & 0x3f] : '=');
		putchar(rem > 2 ? tbl[v & 0x3f] : '=');
	}
}

static void print_json_str(const char *s)
{
	putchar('"');
	for (; *s; s++) {
		unsigned char c = (unsigned char)*s;
		if (c == '"' || c == '\\') {
			putchar('\\');
			putchar(c);
		} else if (c < 0x20) {
			printf("\\u%04x", c);
		} else {
			putchar(c);
		}
	}
	putchar('"');
}

static int read_thp_fault_alloc(long long *out)
{
	FILE *f = fopen("/proc/vmstat", "re");
	if (!f)
		return -1;
	char key[128];
	long long val = -1;
	while (fscanf(f, "%127s %lld", key, &val) == 2) {
		if (strcmp(key, "thp_fault_alloc") == 0) {
			fclose(f);
			*out = val;
			return 0;
		}
	}
	fclose(f);
	return -1;
}

static uint64_t mono_ns(void)
{
	struct timespec ts;

	if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
		perror("clock_gettime");
		exit(EXIT_FAILURE);
	}
	return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

static void ensure_pid1_mounts(void)
{
	mkdir("/proc", 0755);
	(void)mount("proc", "/proc", "proc", 0, NULL);
	mkdir("/sys", 0755);
	(void)mount("sysfs", "/sys", "sysfs", 0, NULL);
	mkdir("/dev", 0755);
	(void)mount("devtmpfs", "/dev", "devtmpfs", 0, NULL);
	mkdir("/tmp", 01777);
	if (access("/tmp/.eval_mounted", F_OK) != 0)
		(void)mount("tmpfs", "/tmp", "tmpfs", 0, "mode=1777");
	chmod("/tmp", 01777);
}

static int prepare_tmpfile(const struct tmpfile_req *req)
{
	int fd = open(req->path, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
	if (fd < 0)
		return -1;
	static uint8_t block[65536];
	static int inited = 0;
	if (!inited) {
		for (size_t i = 0; i < sizeof(block); i++)
			block[i] = (uint8_t)((i * 131 + 17) & 0xff);
		inited = 1;
	}
	size_t total = (size_t)req->size_mb * 1024ULL * 1024ULL;
	size_t written = 0;
	while (written < total) {
		size_t chunk = total - written;
		if (chunk > sizeof(block))
			chunk = sizeof(block);
		ssize_t n = write(fd, block, chunk);
		if (n <= 0) {
			if (n < 0 && errno == EINTR)
				continue;
			close(fd);
			return -1;
		}
		written += (size_t)n;
	}
	(void)fsync(fd);
	close(fd);
	return 0;
}

static int prepare_copyfile(const struct copyfile_req *req)
{
	int sfd = open(req->src, O_RDONLY | O_CLOEXEC);
	if (sfd < 0)
		return -1;
	int dfd = open(req->dst, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0755);
	if (dfd < 0) {
		close(sfd);
		return -1;
	}
	uint8_t buf[32768];
	while (1) {
		ssize_t n = read(sfd, buf, sizeof(buf));
		if (n == 0)
			break;
		if (n < 0) {
			if (errno == EINTR)
				continue;
			close(sfd);
			close(dfd);
			return -1;
		}
		size_t off = 0;
		while (off < (size_t)n) {
			ssize_t w = write(dfd, buf + off, (size_t)n - off);
			if (w <= 0) {
				if (w < 0 && errno == EINTR)
					continue;
				close(sfd);
				close(dfd);
				return -1;
			}
			off += (size_t)w;
		}
	}
	(void)fchmod(dfd, 0755);
	close(sfd);
	close(dfd);
	return 0;
}

static int verify_executable_runs(const char *path)
{
	if (access(path, X_OK) != 0)
		return -1;
	pid_t pid = fork();
	if (pid < 0)
		return -1;
	if (pid == 0) {
		int nullfd = open("/dev/null", O_WRONLY);
		if (nullfd >= 0) {
			dup2(nullfd, STDOUT_FILENO);
			dup2(nullfd, STDERR_FILENO);
			close(nullfd);
		}
		char *const argv[] = { (char *)path, NULL };
		execv(path, argv);
		_exit(127);
	}
	int st = 0;
	pid_t waited;
	do {
		waited = waitpid(pid, &st, 0);
	} while (waited < 0 && errno == EINTR);
	if (waited < 0) {
		perror("waitpid");
		return -1;
	}
	return (WIFEXITED(st) && WEXITSTATUS(st) == 0) ? 0 : -1;
}

static int verify_mask_subset(const cpu_set_t *allowed)
{
	cpu_set_t actual;
	CPU_ZERO(&actual);
	if (sched_getaffinity(0, sizeof(actual), &actual) != 0)
		return -1;
	int any = 0;
	for (int c = 0; c < CPU_SETSIZE; c++) {
		if (CPU_ISSET(c, &actual)) {
			any = 1;
			if (!CPU_ISSET(c, allowed))
				return -1;
		}
	}
	return any ? 0 : -1;
}

static int check_proc_task_cpus(pid_t pid, const cpu_set_t *allowed)
{
	char task_dir[64];
	snprintf(task_dir, sizeof(task_dir), "/proc/%d/task", (int)pid);
	DIR *d = opendir(task_dir);
	if (!d)
		return 0;
	struct dirent *de;
	int bad = 0;
	while ((de = readdir(d)) != NULL) {
		if (de->d_name[0] < '0' || de->d_name[0] > '9')
			continue;
		char stat_path[sizeof(task_dir) + NAME_MAX + sizeof("/stat/")];
		snprintf(stat_path, sizeof(stat_path), "%s/%s/stat", task_dir, de->d_name);
		FILE *f = fopen(stat_path, "re");
		if (!f)
			continue;
		char line[1024];
		if (fgets(line, sizeof(line), f)) {
			char *rparen = strrchr(line, ')');
			if (rparen) {
				// Field 39 (processor) is the 37th token after ')'.
				char *tok = rparen + 1;
				int field = 0;
				int cpu = -1;
				for (char *p = strtok(tok, " \t"); p; p = strtok(NULL, " \t")) {
					field++;
					if (field == 37) {
						cpu = atoi(p);
						break;
					}
				}
				if (cpu >= 0 && !CPU_ISSET(cpu, allowed))
					bad = 1;
			}
		}
		fclose(f);
	}
	closedir(d);
	return bad;
}

static int drain_pipes(pid_t child_pid, const cpu_set_t *allowed,
			int out_fd, int err_fd,
			struct mem_buf *obuf, struct mem_buf *ebuf, int *migrated)
{
	struct pollfd pfds[2];
	pfds[0].fd = out_fd;
	pfds[0].events = POLLIN;
	pfds[1].fd = err_fd;
	pfds[1].events = POLLIN;

	int open_cnt = 2;
	int result = 0;
	uint8_t tmp[4096];
	while (open_cnt > 0) {
		int pr = poll(pfds, 2, 50);
		if (pr < 0) {
			if (errno == EINTR)
				continue;
			perror("poll");
			result = -1;
			goto out;
		}
		if (check_proc_task_cpus(child_pid, allowed) != 0)
			*migrated = 1;
		for (int i = 0; i < 2; i++) {
			if (pfds[i].fd < 0)
				continue;
			if (pfds[i].revents & POLLNVAL) {
				fprintf(stderr, "invalid child output pipe\n");
				result = -1;
				goto out;
			}
			if (pfds[i].revents & (POLLIN | POLLHUP | POLLERR)) {
				ssize_t n = read(pfds[i].fd, tmp, sizeof(tmp));
				if (n > 0) {
					if (buf_append(i == 0 ? obuf : ebuf, tmp, (size_t)n) != 0) {
						perror("capture child output");
						result = -1;
						goto out;
					}
				} else if (n < 0 && errno != EINTR) {
					perror("read child output");
					result = -1;
					goto out;
				} else if (n == 0) {
					close(pfds[i].fd);
					pfds[i].fd = -1;
					open_cnt--;
				}
			}
		}
	}
out:
	for (int i = 0; i < 2; i++) {
		if (pfds[i].fd >= 0)
			close(pfds[i].fd);
	}
	return result;
}

int main(int argc, char **argv)
{
	if (getpid() == 1)
		ensure_pid1_mounts();

	const char *case_id = "unknown";
	const char *cpus_csv = "0";
	const char *verify_exec_path = NULL;
	int poweroff_on_exit = 0;
	struct tmpfile_req tmpfiles[MAX_TMPFILES];
	struct copyfile_req copyfiles[MAX_COPYFILES];
	int n_tmpfiles = 0;
	int n_copyfiles = 0;
	int cmd_idx = -1;

	for (int i = 1; i < argc; i++) {
		if (strcmp(argv[i], "--case-id") == 0 && i + 1 < argc) {
			case_id = argv[++i];
		} else if (strcmp(argv[i], "--cpus") == 0 && i + 1 < argc) {
			cpus_csv = argv[++i];
		} else if (strcmp(argv[i], "--tmpfile") == 0 && i + 1 < argc) {
			if (n_tmpfiles < MAX_TMPFILES) {
				const char *spec = argv[++i];
				const char *colon = strrchr(spec, ':');
				if (colon) {
					size_t plen = (size_t)(colon - spec);
					if (plen >= sizeof(tmpfiles[0].path))
						plen = sizeof(tmpfiles[0].path) - 1;
					memcpy(tmpfiles[n_tmpfiles].path, spec, plen);
					tmpfiles[n_tmpfiles].path[plen] = '\0';
					tmpfiles[n_tmpfiles].size_mb = atol(colon + 1);
					n_tmpfiles++;
				}
			}
		} else if (strcmp(argv[i], "--copy-file") == 0 && i + 1 < argc) {
			if (n_copyfiles < MAX_COPYFILES) {
				const char *spec = argv[++i];
				const char *colon = strrchr(spec, ':');
				if (colon) {
					size_t slen = (size_t)(colon - spec);
					if (slen >= sizeof(copyfiles[0].src))
						slen = sizeof(copyfiles[0].src) - 1;
					memcpy(copyfiles[n_copyfiles].src, spec, slen);
					copyfiles[n_copyfiles].src[slen] = '\0';
					snprintf(copyfiles[n_copyfiles].dst,
						 sizeof(copyfiles[0].dst), "%s", colon + 1);
					n_copyfiles++;
				}
			}
		} else if (strcmp(argv[i], "--verify-exec") == 0 && i + 1 < argc) {
			verify_exec_path = argv[++i];
		} else if (strcmp(argv[i], "--poweroff") == 0) {
			poweroff_on_exit = 1;
		} else if (strcmp(argv[i], "--") == 0) {
			cmd_idx = i + 1;
			break;
		}
	}

	if (cmd_idx < 0 || cmd_idx >= argc) {
		fprintf(stderr, "usage: eval_guest_runner --case-id ID --cpus CSV [--tmpfile PATH:MB] [--copy-file SRC:DST] [--verify-exec PATH] [--poweroff] -- CMD...\n");
		return 2;
	}

	for (int i = 0; i < n_tmpfiles; i++) {
		if (prepare_tmpfile(&tmpfiles[i]) != 0) {
			fprintf(stderr, "failed to prepare tmpfile %s\n", tmpfiles[i].path);
			return 3;
		}
	}
	for (int i = 0; i < n_copyfiles; i++) {
		if (prepare_copyfile(&copyfiles[i]) != 0) {
			fprintf(stderr, "failed to copy %s -> %s\n",
				copyfiles[i].src, copyfiles[i].dst);
			return 3;
		}
	}
	if (verify_exec_path && verify_executable_runs(verify_exec_path) != 0) {
		fprintf(stderr, "pre-exec verification failed for %s\n", verify_exec_path);
		return 6;
	}

	cpu_set_t mask;
	CPU_ZERO(&mask);
	char cpus_buf[128];
	snprintf(cpus_buf, sizeof(cpus_buf), "%s", cpus_csv);
	for (char *tok = strtok(cpus_buf, ","); tok; tok = strtok(NULL, ","))
		CPU_SET(atoi(tok), &mask);
	if (sched_setaffinity(0, sizeof(mask), &mask) != 0 || verify_mask_subset(&mask) != 0) {
		perror("sched_setaffinity");
		return 4;
	}

	int out_pipe[2], err_pipe[2];
	if (pipe2(out_pipe, O_CLOEXEC) != 0 || pipe2(err_pipe, O_CLOEXEC) != 0)
		return 4;

	long long thp_before = 0;
	int thp_ok_before = (read_thp_fault_alloc(&thp_before) == 0);
	int cpu_start = sched_getcpu();
	uint64_t t0 = mono_ns();

	pid_t pid = fork();
	if (pid < 0)
		return 5;
	if (pid == 0) {
		if (sched_setaffinity(0, sizeof(mask), &mask) != 0 || verify_mask_subset(&mask) != 0)
			_exit(126);
		int ccpu = sched_getcpu();
		if (ccpu < 0 || !CPU_ISSET(ccpu, &mask))
			_exit(126);
		dup2(out_pipe[1], STDOUT_FILENO);
		dup2(err_pipe[1], STDERR_FILENO);
		close(out_pipe[0]);
		close(out_pipe[1]);
		close(err_pipe[0]);
		close(err_pipe[1]);
		execvp(argv[cmd_idx], &argv[cmd_idx]);
		perror("execvp");
		_exit(127);
	}

	close(out_pipe[1]);
	close(err_pipe[1]);

	int migrated = 0;
	struct mem_buf obuf = {0}, ebuf = {0};
	int captured = drain_pipes(pid, &mask, out_pipe[0], err_pipe[0], &obuf, &ebuf, &migrated);
	if (captured < 0)
		(void)kill(pid, SIGKILL);

	int status = 0;
	struct rusage ru;
	memset(&ru, 0, sizeof(ru));
	pid_t waited;
	do {
		waited = wait4(pid, &status, 0, &ru);
	} while (waited < 0 && errno == EINTR);
	if (waited < 0) {
		perror("wait4");
		free(obuf.data);
		free(ebuf.data);
		return 5;
	}

	uint64_t t1 = mono_ns();
	int cpu_end = sched_getcpu();
	long long thp_after = 0;
	int thp_ok_after = (read_thp_fault_alloc(&thp_after) == 0);

	for (int i = 0; i < n_tmpfiles; i++)
		(void)unlink(tmpfiles[i].path);
	for (int i = 0; i < n_copyfiles; i++)
		(void)unlink(copyfiles[i].dst);
	if (captured < 0) {
		free(obuf.data);
		free(ebuf.data);
		return 5;
	}

	int rc = WIFEXITED(status) ? WEXITSTATUS(status)
		: (WIFSIGNALED(status) ? 128 + WTERMSIG(status) : 1);
	if (cpu_start < 0 || !CPU_ISSET(cpu_start, &mask) ||
	    cpu_end < 0 || !CPU_ISSET(cpu_end, &mask))
		migrated = 1;
	long long utime_us = (long long)ru.ru_utime.tv_sec * 1000000LL + ru.ru_utime.tv_usec;
	long long stime_us = (long long)ru.ru_stime.tv_sec * 1000000LL + ru.ru_stime.tv_usec;

	printf("EVAL_CASE_JSON {\"case_id\":");
	print_json_str(case_id);
	printf(",\"rc\":%d,\"wall_ns\":%llu,\"minflt_delta\":%ld,\"majflt_delta\":%ld,"
	       "\"ru_utime_us\":%lld,\"ru_stime_us\":%lld,\"cpu_start\":%d,\"cpu_end\":%d,"
	       "\"migrated\":%s,\"thp_fault_alloc_delta\":",
	       rc, (unsigned long long)(t1 - t0), ru.ru_minflt, ru.ru_majflt,
	       utime_us, stime_us, cpu_start, cpu_end,
	       migrated ? "true" : "false");
	if (thp_ok_before && thp_ok_after)
		printf("%lld", thp_after - thp_before);
	else
		printf("null");
	printf(",\"stdout_b64\":\"");
	print_base64(obuf.data, obuf.len);
	printf("\",\"stderr_b64\":\"");
	print_base64(ebuf.data, ebuf.len);
	printf("\"}\n");
	fflush(stdout);

	free(obuf.data);
	free(ebuf.data);

	if (poweroff_on_exit) {
		sync();
		(void)reboot(RB_POWER_OFF);
	}
	return rc;
}
