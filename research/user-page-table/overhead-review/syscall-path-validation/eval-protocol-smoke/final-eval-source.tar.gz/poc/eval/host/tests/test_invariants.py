import unittest

from host.invariants import validate_case_record
from host.schema import CaseRecord, CaseSpec, InvariantSpec, SandboxStats


def _make_spec(**inv_kwargs) -> CaseSpec:
    return CaseSpec(
        case_id="mm.wis.pf_anon.p1",
        group="mm",
        suite="will-it-scale",
        binary="/bin/pf",
        args=("-t", "1"),
        cpus=(0,),
        tmpfiles=(),
        parser="will_it_scale_ops",
        unit="ops/s",
        higher_is_better=True,
        invariants=InvariantSpec(**inv_kwargs),
    )


def _make_record(**rec_kwargs) -> CaseRecord:
    defaults = dict(
        round_idx=1,
        target="L",
        case_id="mm.wis.pf_anon.p1",
        rc=0,
        wall_ns=1000,
        minflt_delta=40000,
        majflt_delta=0,
        ru_utime_us=100,
        ru_stime_us=200,
        cpu_start=0,
        cpu_end=0,
        migrated=False,
        thp_fault_alloc_delta=0,
        stdout="average:1000\n",
        stderr="",
        value=1000.0,
        unit="ops/s",
    )
    defaults.update(rec_kwargs)
    return CaseRecord(**defaults)


class InvariantsTests(unittest.TestCase):
    def test_valid_record_passes(self) -> None:
        ok, reasons = validate_case_record(_make_spec(min_minor_faults=32768), _make_record())
        self.assertTrue(ok, reasons)

    def test_thp_violation_fails(self) -> None:
        ok, reasons = validate_case_record(
            _make_spec(forbid_thp=True),
            _make_record(thp_fault_alloc_delta=1),
        )
        self.assertFalse(ok)
        self.assertTrue(any("THP" in r for r in reasons))

    def test_zero_faults_on_linux_fails(self) -> None:
        ok, reasons = validate_case_record(
            _make_spec(min_minor_faults=100),
            _make_record(target="L", minflt_delta=0),
        )
        self.assertFalse(ok)
        self.assertTrue(any("minor faults" in r for r in reasons))

    def test_migration_fails(self) -> None:
        ok, reasons = validate_case_record(
            _make_spec(forbid_migration=True),
            _make_record(cpu_end=1, migrated=True),
        )
        self.assertFalse(ok)

    def test_kernelet_stats_checks(self) -> None:
        st = SandboxStats(
            pt_mode=0, vcpus=2, grant_mb=512, exit_kind=0, exit_code=0, exit_msg="ok",
            fpu_saves=5, fpu_restores=5, vm_creates=4, vm_destroys=3, vm_flushes=0,
            vm_maps=0, vm_protects=0, vm_unmaps=0, exceptions=0, page_faults=40000,
            virqs=0, forced_yields=0, non_sysret=2,
        )
        ok, reasons = validate_case_record(
            _make_spec(min_minor_faults=32768, require_vm_balance=True, max_fpu_saves=0, max_non_sysret=0),
            _make_record(target="K", minflt_delta=0, sandbox_stats=st),
        )
        self.assertFalse(ok)
        self.assertTrue(any("VmSpace leak" in r for r in reasons))
        self.assertTrue(any("minor faults" in r for r in reasons))
        self.assertTrue(any("FPU" in r for r in reasons))
        self.assertTrue(any("non-SYSRET" in r for r in reasons))

    def test_rejects_missing_thp_missing_k_stats_and_zero_metric(self) -> None:
        ok, reasons = validate_case_record(
            _make_spec(forbid_thp=True),
            _make_record(target="L", thp_fault_alloc_delta=None, value=0.0),
        )
        self.assertFalse(ok)
        self.assertTrue(any("thp_fault_alloc" in r for r in reasons))
        self.assertTrue(any("non-positive" in r for r in reasons))

        ok_k, reasons_k = validate_case_record(
            _make_spec(),
            _make_record(target="K", sandbox_stats=None),
        )
        self.assertFalse(ok_k)
        self.assertTrue(any("STATS_JSON" in r for r in reasons_k))

    def test_skipped_record_passes(self) -> None:
        ok, reasons = validate_case_record(
            _make_spec(min_minor_faults=100),
            _make_record(rc=-1, value=None, skipped=True, skip_reason="not observable"),
        )
        self.assertTrue(ok, reasons)


if __name__ == "__main__":
    unittest.main()
