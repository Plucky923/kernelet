from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import subprocess


@dataclass(frozen=True)
class GuestSymbol:
    addr: int
    sym_type: str
    name: str
    module: str = ""


_KALLSYMS_LINE_RE = re.compile(r"^\s*([0-9a-fA-F]+)\s+([a-zA-Z?])\s+(\S+)(?:\s+\[(\S+)\])?")
_SECTION_RE = re.compile(r"^\s*\[\s*(\d+)\]\s+(\S+)\s+\S+\s+([0-9a-fA-F]+)")
_SYMTAB_RE = re.compile(
    r"^\s*\d+:\s+([0-9a-fA-F]+)\s+\d+\s+(\S+)\s+(\S+)\s+\S+\s+(\S+)\s+(\S+)"
)


def parse_kallsyms_text(text: str) -> list[GuestSymbol]:
    """Parse `/proc/kallsyms` or `System.map` formatted lines."""
    symbols: list[GuestSymbol] = []
    for line in text.splitlines():
        m = _KALLSYMS_LINE_RE.match(line)
        if not m:
            continue
        addr = int(m.group(1), 16)
        sym_type = m.group(2)
        name = m.group(3)
        mod = m.group(4) or ""
        symbols.append(GuestSymbol(addr=addr, sym_type=sym_type, name=name, module=mod))
    return symbols


def parse_readelf_sections(readelf_s_text: str) -> dict[str, str]:
    """Parse `readelf -S -W` output into section index string -> section name."""
    sections: dict[str, str] = {}
    for line in readelf_s_text.splitlines():
        m = _SECTION_RE.match(line)
        if m:
            sections[m.group(1)] = m.group(2)
    return sections


def parse_readelf_module_symbols(
    readelf_sec_text: str,
    readelf_sym_text: str,
    section_bases: dict[str, int],
    *,
    module_name: str = "endovisor",
) -> list[GuestSymbol]:
    """Relocate ET_REL kernel module symbols using per-section live load addresses."""
    sec_by_idx = parse_readelf_sections(readelf_sec_text)
    symbols: list[GuestSymbol] = []
    for line in readelf_sym_text.splitlines():
        m = _SYMTAB_RE.match(line)
        if not m:
            continue
        val = int(m.group(1), 16)
        sym_type_name = m.group(2)
        bind = m.group(3)
        ndx = m.group(4)
        name = m.group(5)
        if sym_type_name != "FUNC" or ndx in ("UND", "ABS", "COM"):
            continue
        sec_name = sec_by_idx.get(ndx)
        if not sec_name or sec_name not in section_bases:
            continue
        ktype = "T" if bind == "GLOBAL" else "t"
        symbols.append(
            GuestSymbol(
                addr=section_bases[sec_name] + val,
                sym_type=ktype,
                name=name,
                module=module_name,
            )
        )
    return symbols


def parse_readelf_pie_symbols(
    readelf_sym_text: str,
    load_base: int,
    *,
    module_name: str = "kernelet",
) -> list[GuestSymbol]:
    """Relocate ET_DYN PIE image function symbols by `load_base`."""
    symbols: list[GuestSymbol] = []
    for line in readelf_sym_text.splitlines():
        m = _SYMTAB_RE.match(line)
        if not m:
            continue
        val = int(m.group(1), 16)
        sym_type_name = m.group(2)
        bind = m.group(3)
        ndx = m.group(4)
        name = m.group(5)
        if sym_type_name != "FUNC" or ndx in ("UND", "ABS", "COM"):
            continue
        ktype = "T" if bind == "GLOBAL" else "t"
        symbols.append(
            GuestSymbol(
                addr=load_base + val,
                sym_type=ktype,
                name=name,
                module=module_name,
            )
        )
    return symbols


def _run_readelf(flag: str, binary_path: Path) -> str:
    return subprocess.check_output(
        ["readelf", flag, "-W", str(binary_path)],
        text=True,
    )


def format_kallsyms(symbols: list[GuestSymbol]) -> str:
    """Format symbols as Linux `/proc/kallsyms` lines."""
    ordered = sorted(symbols, key=lambda s: (s.addr, s.name))
    lines: list[str] = []
    for s in ordered:
        if s.module:
            lines.append(f"{s.addr:016x} {s.sym_type} {s.name}\t[{s.module}]")
        else:
            lines.append(f"{s.addr:016x} {s.sym_type} {s.name}")
    return "\n".join(lines) + ("\n" if lines else "")


def synthesize_guest_kallsyms(
    *,
    vmlinux_system_map: Path,
    endovisor_ko: Path | None = None,
    endovisor_section_bases: dict[str, int] | None = None,
    kernelet_image: Path | None = None,
    kernelet_load_base: int | None = None,
) -> str:
    """Merge vmlinux System.map, per-section endovisor.ko, and PIE kernelet-image.elf symbols."""
    all_syms: list[GuestSymbol] = parse_kallsyms_text(
        vmlinux_system_map.read_text(encoding="utf-8")
    )

    if endovisor_ko is not None and endovisor_section_bases:
        all_syms.extend(
            parse_readelf_module_symbols(
                _run_readelf("-S", endovisor_ko),
                _run_readelf("-s", endovisor_ko),
                endovisor_section_bases,
                module_name="endovisor",
            )
        )

    if kernelet_image is not None and kernelet_load_base is not None:
        all_syms.extend(
            parse_readelf_pie_symbols(
                _run_readelf("-s", kernelet_image),
                kernelet_load_base,
                module_name="kernelet",
            )
        )

    return format_kallsyms(all_syms)
