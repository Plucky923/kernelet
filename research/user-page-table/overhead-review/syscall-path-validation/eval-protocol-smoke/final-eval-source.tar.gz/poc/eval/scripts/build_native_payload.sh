#!/usr/bin/env bash
# Build the immutable shared `eval-payload.cpio` and `host-eval-initramfs.cpio.gz`
# natively using static gcc, real upstream libtirpc + hwloc, and gen_init_cpio.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EVAL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(cd "$EVAL_DIR/../.." && pwd)"
BUILD_DIR="${BUILD_DIR:-$EVAL_DIR/.build}"
SRC_CACHE="$BUILD_DIR/sources"
DEPS_DIR="$BUILD_DIR/deps"
PAYLOAD_ROOT="$BUILD_DIR/payload-root"
GUEST_BIN_DIR="$BUILD_DIR/guest"
JOBS="${JOBS:-$(nproc)}"

GEN_INIT_CPIO="${GEN_INIT_CPIO:-$BUILD_DIR/linux-perf-base/usr/gen_init_cpio}"
if [[ ! -x "$GEN_INIT_CPIO" ]]; then
    GEN_INIT_CPIO="$REPO_ROOT/prototype/.build/linux-6.12/usr/gen_init_cpio"
fi
if [[ ! -x "$GEN_INIT_CPIO" ]]; then
    echo "error: gen_init_cpio not found; run 'make build-kernels' first" >&2
    exit 1
fi

mkdir -p "$SRC_CACHE" "$DEPS_DIR" "$GUEST_BIN_DIR" "$PAYLOAD_ROOT"

fetch_and_verify() {
    local url="$1"
    local out="$2"
    local expected_sha="$3"
    if [[ ! -f "$out" ]]; then
        curl -fL --retry 3 -o "$out" "$url"
    fi
    local actual_sha
    actual_sha=$(sha256sum "$out" | awk '{print $1}')
    if [[ "$actual_sha" != "$expected_sha" ]]; then
        echo "error: sha256 mismatch for $out (expected $expected_sha, got $actual_sha)" >&2
        rm -f "$out"
        exit 1
    fi
}

# 1. Always recompile poc/eval guest & host-init C components statically.
CC="${CC:-gcc}"
CFLAGS="-O2 -Wall -Wextra -static -pthread"
$CC $CFLAGS -o "$GUEST_BIN_DIR/eval_guest_runner" "$EVAL_DIR/guest/eval_guest_runner.c"
$CC $CFLAGS -o "$GUEST_BIN_DIR/vdso_selfcheck" "$EVAL_DIR/guest/vdso_selfcheck.c"
$CC $CFLAGS -o "$GUEST_BIN_DIR/eval_init" "$EVAL_DIR/guest/eval_init.c"

# 2. Build real upstream static libtirpc (no abort stubs).
TIRPC_VER="1.3.6"
TIRPC_SHA="bbd26a8f0df5690a62a47f6aa30f797f3ef8d02560d1bc449a83066b5a1d3508"
TIRPC_TAR="$SRC_CACHE/libtirpc-$TIRPC_VER.tar.bz2"
TIRPC_SRC="$SRC_CACHE/libtirpc-$TIRPC_VER"
if [[ ! -f "$DEPS_DIR/lib/libtirpc.a" ]]; then
    fetch_and_verify \
        "https://downloads.sourceforge.net/project/libtirpc/libtirpc/$TIRPC_VER/libtirpc-$TIRPC_VER.tar.bz2" \
        "$TIRPC_TAR" "$TIRPC_SHA"
    rm -rf "$TIRPC_SRC"
    tar -xjf "$TIRPC_TAR" -C "$SRC_CACHE"
    (
        cd "$TIRPC_SRC"
        CFLAGS="-O2 -std=gnu11" ./configure \
            --prefix="$DEPS_DIR" \
            --enable-static \
            --disable-shared \
            --disable-gssapi
        make -j"$JOBS"
        make install
    )
fi

# 3. Build real upstream static hwloc (no fake hwloc.h shim).
HWLOC_VER="2.11.2"
HWLOC_SHA="f7f88fecae067100f1a1a915b658add0f4f71561259482910a69baea22fe8409"
HWLOC_TAR="$SRC_CACHE/hwloc-$HWLOC_VER.tar.bz2"
HWLOC_SRC="$SRC_CACHE/hwloc-$HWLOC_VER"
if [[ ! -f "$DEPS_DIR/lib/libhwloc.a" ]]; then
    fetch_and_verify \
        "https://download.open-mpi.org/release/hwloc/v2.11/hwloc-$HWLOC_VER.tar.bz2" \
        "$HWLOC_TAR" "$HWLOC_SHA"
    rm -rf "$HWLOC_SRC"
    tar -xjf "$HWLOC_TAR" -C "$SRC_CACHE"
    (
        cd "$HWLOC_SRC"
        ./configure \
            --prefix="$DEPS_DIR" \
            --enable-static \
            --disable-shared \
            --disable-libudev \
            --disable-pci \
            --disable-cairo \
            --disable-libxml2 \
            --disable-io \
            --disable-gl \
            --disable-opencl \
            --disable-cuda \
            --disable-nvml \
            --disable-rsmi \
            --disable-levelzero
        make -j"$JOBS"
        make install
    )
fi

# 4. Build static BusyBox 1.36.1.
BUSYBOX_VER="1.36.1"
BUSYBOX_SHA="b8cc24c9574d809e7279c3be349795c5d5ceb6fdf19ca709f80cde50e47de314"
BUSYBOX_TAR="$SRC_CACHE/busybox-$BUSYBOX_VER.tar.bz2"
BUSYBOX_DIR="$SRC_CACHE/busybox-$BUSYBOX_VER"
if [[ ! -x "$GUEST_BIN_DIR/busybox" ]]; then
    fetch_and_verify \
        "https://busybox.net/downloads/busybox-$BUSYBOX_VER.tar.bz2" \
        "$BUSYBOX_TAR" "$BUSYBOX_SHA"
    rm -rf "$BUSYBOX_DIR"
    tar -xjf "$BUSYBOX_TAR" -C "$SRC_CACHE"
    make -C "$BUSYBOX_DIR" defconfig >/dev/null
    sed -i 's/^# CONFIG_STATIC is not set$/CONFIG_STATIC=y/' "$BUSYBOX_DIR/.config"
    sed -i 's/^CONFIG_TC=y$/# CONFIG_TC is not set/' "$BUSYBOX_DIR/.config"
    make -C "$BUSYBOX_DIR" oldconfig </dev/null >/dev/null
    make -C "$BUSYBOX_DIR" -j"$JOBS" busybox
    cp "$BUSYBOX_DIR/busybox" "$GUEST_BIN_DIR/busybox"
fi

# 5. Build LMbench 3 subset linked statically against real libtirpc.a.
LMBENCH_REV="afb47eddaf10a411c1ea3cb64965461f1308a6ea"
LMBENCH_SHA="c718a3d761ab7b385fa9db17e00da8a8f11d40c0c694470909334ab7ee8c7bea"
LMBENCH_TAR="$SRC_CACHE/lmbench.tar.gz"
LMBENCH_DIR="$SRC_CACHE/lmbench-$LMBENCH_REV"
LMBENCH_OUT="$BUILD_DIR/lmbench-bin"
LMBENCH_TARGETS=(
    lat_syscall lat_pipe lat_select lat_proc lat_mmap
    bw_mmap_rd lat_pagefault lat_sig bw_mem hello
)
fetch_and_verify \
    "https://github.com/asterinas/lmbench/archive/${LMBENCH_REV}.tar.gz" \
    "$LMBENCH_TAR" "$LMBENCH_SHA"
if [[ ! -d "$LMBENCH_DIR" ]]; then
    tar -xzf "$LMBENCH_TAR" -C "$SRC_CACHE"
fi
mkdir -p "$LMBENCH_OUT"
OS="x86_64-linux-gnu"
LMBENCH_O="../bin/$OS"
LMBENCH_CFLAGS="-O2 -std=gnu89 -I$DEPS_DIR/include/tirpc -DRUSAGE -DHAVE_uint=1 -DHAVE_uint64_t=1 -DHAVE_int64_t=1 -DHAVE_DRAND48 -DHAVE_SCHED_SETAFFINITY=1 -Wno-error=format-security -Wno-implicit-function-declaration -Wno-return-type"
mkdir -p "$LMBENCH_DIR/bin/$OS"
# Clean and link with real libtirpc.a so no stubbed RPC symbols remain.
rm -f "$LMBENCH_DIR/bin/$OS/lat_select"
make -C "$LMBENCH_DIR/src" CC="$CC" OS="$OS" O="$LMBENCH_O" \
    CFLAGS="$LMBENCH_CFLAGS" LDFLAGS="-static -L$DEPS_DIR/lib" LDLIBS="-ltirpc -lm" \
    "$LMBENCH_O/lmbench.a" "${LMBENCH_TARGETS[@]/#/$LMBENCH_O/}"
for t in "${LMBENCH_TARGETS[@]}"; do
    cp "$LMBENCH_DIR/bin/$OS/$t" "$LMBENCH_OUT/$t"
done

# 6. Build pinned will-it-scale linked statically against real libhwloc.a.
WIS_REV="75f66e45697e6f5f49c33dd950c4e6b289198f8f"
WIS_SHA="1df7639725a8ae4e764f4408fb276d9903f39aa8665a3abd9042086c5018ebab"
WIS_TAR="$SRC_CACHE/will-it-scale-75f66e45.tar.gz"
WIS_DIR="$SRC_CACHE/will-it-scale-$WIS_REV"
WIS_OUT="$BUILD_DIR/will-it-scale-bin"
WIS_TESTS=(
    getppid1 open1 dup1 pipe1
    page_fault1 page_fault2 page_fault3
    mmap1 mmap2 brk1 malloc1
)
fetch_and_verify \
    "https://github.com/antonblanchard/will-it-scale/archive/${WIS_REV}.tar.gz" \
    "$WIS_TAR" "$WIS_SHA"
if [[ ! -d "$WIS_DIR" ]]; then
    tar -xzf "$WIS_TAR" -C "$SRC_CACHE"
fi
mkdir -p "$WIS_OUT"
for t in "${WIS_TESTS[@]}"; do
    $CC -O2 -Wall -static -pthread -I"$DEPS_DIR/include" -I"$WIS_DIR" \
        "$WIS_DIR/tests/$t.c" "$WIS_DIR/main.c" \
        -L"$DEPS_DIR/lib" -lhwloc -lm \
        -o "$WIS_OUT/${t}_processes"
done

# 7. Build static stress-ng V0.18.06.
STRESS_VER="V0.18.06"
STRESS_SHA="f3197c010b1ac23b015a6f8e8c84a24cee02750bf41a1527379ccb31ca4f889a"
STRESS_TAR="$SRC_CACHE/stress-ng-$STRESS_VER.tar.gz"
STRESS_DIR="$SRC_CACHE/stress-ng-${STRESS_VER#V}"
fetch_and_verify \
    "https://github.com/ColinIanKing/stress-ng/archive/refs/tags/${STRESS_VER}.tar.gz" \
    "$STRESS_TAR" "$STRESS_SHA"
if [[ ! -x "$GUEST_BIN_DIR/stress-ng" ]]; then
    rm -rf "$STRESS_DIR"
    tar -xzf "$STRESS_TAR" -C "$SRC_CACHE"
    make -C "$STRESS_DIR" -j"$JOBS" STATIC=1 CC="$CC"
    cp "$STRESS_DIR/stress-ng" "$GUEST_BIN_DIR/stress-ng"
fi

# 8. Assemble single immutable eval-payload.cpio.
rm -rf "$PAYLOAD_ROOT"
mkdir -p "$PAYLOAD_ROOT"/{bin,dev,etc,proc,sys,tmp,benchmark/bin/lmbench,benchmark/bin/will-it-scale}
chmod 1777 "$PAYLOAD_ROOT/tmp"

cp "$GUEST_BIN_DIR/busybox" "$PAYLOAD_ROOT/bin/busybox"
for applet in sh true false echo cat ls mkdir rm cp mv chmod; do
    ln -sf busybox "$PAYLOAD_ROOT/bin/$applet"
done
cp "$GUEST_BIN_DIR/eval_guest_runner" "$PAYLOAD_ROOT/bin/eval_guest_runner"
cp "$GUEST_BIN_DIR/vdso_selfcheck" "$PAYLOAD_ROOT/bin/vdso_selfcheck"
ln -sf /bin/eval_guest_runner "$PAYLOAD_ROOT/init"

cp "$LMBENCH_OUT"/* "$PAYLOAD_ROOT/benchmark/bin/lmbench/"
cp "$WIS_OUT"/* "$PAYLOAD_ROOT/benchmark/bin/will-it-scale/"
cp "$GUEST_BIN_DIR/stress-ng" "$PAYLOAD_ROOT/benchmark/bin/stress-ng"

(cd "$PAYLOAD_ROOT" && find . -print0 | LC_ALL=C sort -z | cpio -o -H newc --null > "$BUILD_DIR/eval-payload.cpio")
sha256sum "$BUILD_DIR/eval-payload.cpio" > "$BUILD_DIR/eval-payload.cpio.sha256"

# 9. Assemble host-eval-initramfs.cpio.gz (FAIL-CLOSED if any required Kernelet artifact is missing).
ENDOVISOR_KO="${ENDOVISOR_KO:-$BUILD_DIR/endovisor.ko}"
RUN_KERNELET="${RUN_KERNELET:-$BUILD_DIR/run-kernelet}"
KERNELET_IMAGE="${KERNELET_IMAGE:-$BUILD_DIR/kernelet-image.elf}"

for req in "$ENDOVISOR_KO" "$RUN_KERNELET" "$KERNELET_IMAGE"; do
    if [[ ! -s "$req" ]]; then
        echo "error: required host-initramfs artifact missing or empty: $req (run 'make build-kernels' first)" >&2
        exit 1
    fi
done
if [[ ! -x "$RUN_KERNELET" ]]; then
    echo "error: run-kernelet is not executable: $RUN_KERNELET" >&2
    exit 1
fi

HOST_LIST="$BUILD_DIR/host-eval-initramfs.list"
cat > "$HOST_LIST" <<EOF
dir /dev 0755 0 0
nod /dev/console 0600 0 0 c 5 1
dir /proc 0755 0 0
dir /sys 0755 0 0
dir /etc 0755 0 0
dir /bin 0755 0 0
dir /modules 0755 0 0
dir /payload 0755 0 0
dir /mnt 0755 0 0
dir /mnt/payload 0755 0 0
file /init $GUEST_BIN_DIR/eval_init 0755 0 0
file /bin/busybox $GUEST_BIN_DIR/busybox 0755 0 0
file /bin/run-kernelet $RUN_KERNELET 0755 0 0
file /modules/endovisor.ko $ENDOVISOR_KO 0644 0 0
file /kernelet-image.elf $KERNELET_IMAGE 0644 0 0
file /payload/eval-payload.cpio $BUILD_DIR/eval-payload.cpio 0644 0 0
EOF

"$GEN_INIT_CPIO" "$HOST_LIST" | gzip -9 > "$BUILD_DIR/host-eval-initramfs.cpio.gz"

# 10. Verify packed CPIO contents match current contract (no stale poc_endovisor/run-poc).
CONTENTS=$(gzip -dc "$BUILD_DIR/host-eval-initramfs.cpio.gz" | cpio -it 2>/dev/null)
for expected in "init" "bin/busybox" "bin/run-kernelet" "modules/endovisor.ko" "kernelet-image.elf" "payload/eval-payload.cpio"; do
    if ! grep -qx "$expected" <<<"$CONTENTS"; then
        echo "error: host-eval-initramfs.cpio.gz missing $expected" >&2
        exit 1
    fi
done
if grep -qE "poc_endovisor|run-poc" <<<"$CONTENTS"; then
    echo "error: host-eval-initramfs.cpio.gz contains stale poc_endovisor or run-poc" >&2
    exit 1
fi

ls -lh "$BUILD_DIR/eval-payload.cpio" "$BUILD_DIR/host-eval-initramfs.cpio.gz"
