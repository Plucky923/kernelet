#!/usr/bin/env bash
# Build isolated Linux perf kernels (O=poc/eval/.build/linux-perf-*), endovisor.ko,
# run-kernelet, Native Asterinas bzImage (A), and Kernelet ELF image (K).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EVAL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(cd "$EVAL_DIR/../.." && pwd)"
BUILD_DIR="${BUILD_DIR:-$EVAL_DIR/.build}"
JOBS="${JOBS:-$(nproc)}"

LINUX_SRC="$BUILD_DIR/linux-6.12-src"
REF_LINUX="$REPO_ROOT/reference/linux-6.12"
PATCH="$REPO_ROOT/prototype/linux/patches/0001-carrier-hooks.patch"

mkdir -p "$BUILD_DIR"

# 1. Prepare clean patched Linux 6.12 source tree via hardlink copy.
if [[ ! -f "$LINUX_SRC/.carrier-hooks-patch" ]]; then
    if [[ ! -d "$LINUX_SRC" ]]; then
        cp -al "$REF_LINUX" "$LINUX_SRC"
    fi
    (cd "$LINUX_SRC" && patch -p1 --force --silent < "$PATCH")
    touch "$LINUX_SRC/.carrier-hooks-patch"
fi

build_linux_profile() {
    local profile="$1"
    local out_dir="$BUILD_DIR/linux-$profile"
    mkdir -p "$out_dir"

    make -C "$LINUX_SRC" O="$out_dir" ARCH=x86_64 tinyconfig
    if [[ "$profile" == "perf-base" ]]; then
        (cd "$LINUX_SRC" && ARCH=x86_64 ./scripts/kconfig/merge_config.sh -m -O "$out_dir" \
            "$out_dir/.config" "$EVAL_DIR/configs/linux-perf-base.fragment")
    else
        (cd "$LINUX_SRC" && ARCH=x86_64 ./scripts/kconfig/merge_config.sh -m -O "$out_dir" \
            "$out_dir/.config" "$EVAL_DIR/configs/linux-perf-base.fragment" \
            "$EVAL_DIR/configs/linux-perf-$profile.fragment")
    fi
    make -C "$LINUX_SRC" O="$out_dir" ARCH=x86_64 CC="gcc -std=gnu11" olddefconfig
    PYTHONPATH="$EVAL_DIR" python3 -m host.cli check-config --config "$out_dir/.config" --profile "$profile"
    make -C "$LINUX_SRC" O="$out_dir" ARCH=x86_64 CC="gcc -std=gnu11" -j"$JOBS" bzImage modules modules_prepare
}

build_linux_profile "perf-base"
if [[ "${BUILD_PTI:-0}" == "1" ]]; then
    build_linux_profile "perf-pti"
fi

# 2. Build endovisor.ko from clean source files only (no stale poc_* objects).
ENDO_BUILD="$BUILD_DIR/endovisor"
rm -rf "$ENDO_BUILD"
mkdir -p "$ENDO_BUILD"
cp -a "$REPO_ROOT/poc/linux/endovisor/Makefile" \
    "$REPO_ROOT/poc/linux/endovisor/"*.c \
    "$REPO_ROOT/poc/linux/endovisor/"*.S \
    "$REPO_ROOT/poc/linux/endovisor/"*.h \
    "$REPO_ROOT/poc/linux/endovisor/uapi" \
    "$ENDO_BUILD/"
make -C "$BUILD_DIR/linux-perf-base" ARCH=x86_64 CC="gcc -std=gnu11" -j"$JOBS" M="$ENDO_BUILD" modules
cp "$ENDO_BUILD/endovisor.ko" "$BUILD_DIR/endovisor.ko"

# 3. Build run-kernelet into $BUILD_DIR/run-kernelet.
RUNNER_OUT="$BUILD_DIR/runner"
mkdir -p "$RUNNER_OUT"
make -C "$REPO_ROOT/poc/linux/runner" OUT_DIR="$RUNNER_OUT"
cp "$RUNNER_OUT/run-kernelet" "$BUILD_DIR/run-kernelet"

# 4. Build both Native Asterinas (A) and Kernelet PIE image (K) from identical poc/kernel source.
export PATH="$HOME/.cargo/bin:$PATH"
export VDSO_LIBRARY_DIR="${VDSO_LIBRARY_DIR:-$HOME/.local/share/asterinas/linux_vdso}"
export OSDK_TARGET_ARCH="x86_64"
export OSTD_TASK_STACK_SIZE_IN_PAGES=8
if [[ ! -f "$VDSO_LIBRARY_DIR/vdso_x86_64.so" ]]; then
    echo "error: missing $VDSO_LIBRARY_DIR/vdso_x86_64.so" >&2
    exit 1
fi

ASTER_OUT="$BUILD_DIR/asterinas-native-osdk"
mkdir -p "$ASTER_OUT"
(
    cd "$REPO_ROOT/poc/kernel"
    cargo osdk build \
        --release \
        --boot-method="vmm-direct" \
        --linux-x86-legacy-boot \
        --grub-boot-protocol="linux" \
        --strip-elf \
        --output="$ASTER_OUT"
)
if [[ -f "$ASTER_OUT/asterinas" ]]; then
    cp "$ASTER_OUT/asterinas" "$BUILD_DIR/asterinas-native.bzImage"
elif [[ -f "$ASTER_OUT/asterinas-osdk-bin" ]]; then
    cp "$ASTER_OUT/asterinas-osdk-bin" "$BUILD_DIR/asterinas-native.bzImage"
else
    found_img=$(find "$ASTER_OUT" -maxdepth 2 -type f -executable | head -n 1 || true)
    if [[ -z "$found_img" ]]; then
        echo "error: could not locate built native Asterinas image under $ASTER_OUT" >&2
        exit 1
    fi
    cp "$found_img" "$BUILD_DIR/asterinas-native.bzImage"
fi

KERNELET_OUT="$BUILD_DIR/asterinas-kernelet-osdk"
mkdir -p "$KERNELET_OUT"
(
    cd "$REPO_ROOT/poc/kernel"
    OSDK_KERNELET_IMAGE_ONLY=1 cargo osdk build \
        --kernelet \
        --release \
        --output="$KERNELET_OUT"
)
KLET_ELF=$(cat "$KERNELET_OUT/kernelet-image-path.txt")
if [[ ! -f "$KLET_ELF" ]]; then
    echo "error: kernelet image missing at $KLET_ELF" >&2
    exit 1
fi
cp "$KLET_ELF" "$BUILD_DIR/kernelet-image.elf"

ls -lh \
    "$BUILD_DIR/linux-perf-base/arch/x86/boot/bzImage" \
    "$BUILD_DIR/endovisor.ko" \
    "$BUILD_DIR/run-kernelet" \
    "$BUILD_DIR/asterinas-native.bzImage" \
    "$BUILD_DIR/kernelet-image.elf"
