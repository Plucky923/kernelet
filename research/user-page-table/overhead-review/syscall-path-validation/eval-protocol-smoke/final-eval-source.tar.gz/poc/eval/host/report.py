from __future__ import annotations

import csv
from dataclasses import dataclass
import io
import json
from pathlib import Path
import random
import statistics
from typing import Iterable

from .schema import CaseRecord, CaseSpec


@dataclass(frozen=True)
class SummaryStats:
    count: int
    median: float
    mean: float
    min_val: float
    max_val: float


def schedule_rounds(targets: list[str], rounds: int, seed: int) -> list[list[str]]:
    """Generate per-round shuffled target execution orders with a fixed RNG seed."""
    if rounds <= 0:
        raise ValueError("rounds must be positive")
    if not targets:
        raise ValueError("targets must not be empty")
    rng = random.Random(seed)
    schedule: list[list[str]] = []
    for _ in range(rounds):
        order = list(targets)
        rng.shuffle(order)
        schedule.append(order)
    return schedule


def compute_stats(values: Iterable[float]) -> SummaryStats:
    """Compute count, median, mean, min, and max for a non-empty sequence."""
    vals = list(values)
    if not vals:
        raise ValueError("cannot compute stats of empty values")
    return SummaryStats(
        count=len(vals),
        median=float(statistics.median(vals)),
        mean=float(statistics.fmean(vals)),
        min_val=float(min(vals)),
        max_val=float(max(vals)),
    )


def _fmt_stat(st: SummaryStats | None) -> str:
    if st is None:
        return "N/A"
    return f"{st.median:.3f} [{st.min_val:.3f}, {st.max_val:.3f}] (mean {st.mean:.3f})"


def _ratio(num: SummaryStats | None, den: SummaryStats | None) -> str:
    if num is None or den is None or den.median == 0.0:
        return "N/A"
    return f"{num.median / den.median:.2f}x"


def write_records_jsonl(records: Iterable[CaseRecord], out_path: Path) -> None:
    """Write all CaseRecords to a JSONL file."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec.to_dict(), sort_keys=True) + "\n")


def render_markdown_report(
    cases: dict[str, CaseSpec],
    records: list[CaseRecord],
    targets: list[str],
    *,
    title: str = "Kernelet Evaluation Summary",
) -> str:
    """Render a Markdown summary table with Median, [min, max], Mean, K/L, and K/A."""
    grouped: dict[tuple[str, str], list[float]] = {}
    skipped_notes: dict[str, str] = {}
    invalid_records: list[CaseRecord] = []
    for rec in records:
        if rec.skipped:
            skipped_notes[rec.case_id] = rec.skip_reason
            continue
        if not rec.valid or rec.value is None:
            invalid_records.append(rec)
            continue
        grouped.setdefault((rec.case_id, rec.target), []).append(rec.value)

    lines: list[str] = [f"# {title}", ""]
    if invalid_records:
        lines.append(
            f"> **WARNING:** {len(invalid_records)} invalid record(s) excluded from summary."
        )
        lines.append("")

    header = ["Case ID", "Unit", "Direction"]
    for t in targets:
        header.append(f"{t} Median [min, max] (Mean)")
    if "K" in targets and "L" in targets:
        header.append("K / L")
    if "K" in targets and "A" in targets:
        header.append("K / A")

    lines.append("| " + " | ".join(header) + " |")
    lines.append("|" + "|".join(["---"] * len(header)) + "|")

    for case_id, spec in cases.items():
        if case_id in skipped_notes:
            direction = "higher better" if spec.higher_is_better else "lower better"
            row = [f"`{case_id}`", spec.unit, direction]
            for _ in targets:
                row.append(f"SKIPPED ({skipped_notes[case_id]})")
            if "K" in targets and "L" in targets:
                row.append("SKIPPED")
            if "K" in targets and "A" in targets:
                row.append("SKIPPED")
            lines.append("| " + " | ".join(row) + " |")
            continue

        stats_by_target: dict[str, SummaryStats | None] = {}
        any_present = False
        for t in targets:
            vals = grouped.get((case_id, t), [])
            if vals:
                any_present = True
                stats_by_target[t] = compute_stats(vals)
            else:
                stats_by_target[t] = None
        if not any_present:
            continue

        direction = "higher better" if spec.higher_is_better else "lower better"
        row = [f"`{case_id}`", spec.unit, direction]
        for t in targets:
            row.append(_fmt_stat(stats_by_target[t]))
        if "K" in targets and "L" in targets:
            row.append(_ratio(stats_by_target.get("K"), stats_by_target.get("L")))
        if "K" in targets and "A" in targets:
            row.append(_ratio(stats_by_target.get("K"), stats_by_target.get("A")))
        lines.append("| " + " | ".join(row) + " |")

    lines.append("")
    return "\n".join(lines)


def render_csv_report(
    cases: dict[str, CaseSpec],
    records: list[CaseRecord],
    targets: list[str],
) -> str:
    """Render aggregated per-case, per-target statistics as CSV."""
    grouped: dict[tuple[str, str], list[float]] = {}
    skipped: dict[tuple[str, str], str] = {}
    for rec in records:
        if rec.skipped:
            skipped[(rec.case_id, rec.target)] = rec.skip_reason
        elif rec.valid and rec.value is not None:
            grouped.setdefault((rec.case_id, rec.target), []).append(rec.value)

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(
        [
            "case_id",
            "group",
            "suite",
            "target",
            "unit",
            "higher_is_better",
            "status",
            "n",
            "median",
            "mean",
            "min",
            "max",
        ]
    )
    for case_id, spec in cases.items():
        for t in targets:
            if (case_id, t) in skipped:
                writer.writerow(
                    [
                        case_id,
                        spec.group,
                        spec.suite,
                        t,
                        spec.unit,
                        spec.higher_is_better,
                        f"SKIPPED:{skipped[(case_id, t)]}",
                        0,
                        "",
                        "",
                        "",
                        "",
                    ]
                )
                continue
            vals = grouped.get((case_id, t), [])
            if not vals:
                continue
            st = compute_stats(vals)
            writer.writerow(
                [
                    case_id,
                    spec.group,
                    spec.suite,
                    t,
                    spec.unit,
                    spec.higher_is_better,
                    "OK",
                    st.count,
                    f"{st.median:.6f}",
                    f"{st.mean:.6f}",
                    f"{st.min_val:.6f}",
                    f"{st.max_val:.6f}",
                ]
            )
    return buf.getvalue()
