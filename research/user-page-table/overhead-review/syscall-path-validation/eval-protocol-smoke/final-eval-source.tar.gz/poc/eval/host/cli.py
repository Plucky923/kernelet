from __future__ import annotations

import argparse
import datetime
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

from .build_guard import check_kernel_config, generate_and_write_archive
from .invariants import check_kernel_log_clean, validate_case_record
from .perf_sym import synthesize_guest_kallsyms
from .qemu_driver import (
    build_batch_overlay_cpio_gz,
    format_batch_manifest,
    format_guest_runner_args,
    parse_serial_records,
    run_qemu_with_pinning,
)
from .report import (
    render_csv_report,
    render_markdown_report,
    schedule_rounds,
    write_records_jsonl,
)
from .schema import CaseRecord, CaseSpec, SandboxStats, load_cases_toml


EVAL_DIR = Path(__file__).resolve().parent.parent
REPO_ROOT = EVAL_DIR.parent.parent
TMP_ROOT = EVAL_DIR / ".build" / "tmp"


def _select_cases(
    all_cases: dict[str, CaseSpec],
    groups: list[str] | None,
    case_ids: list[str] | None,
) -> dict[str, CaseSpec]:
    unknown_cases = set(case_ids or ()) - all_cases.keys()
    if unknown_cases:
        raise ValueError(f"unknown cases: {sorted(unknown_cases)}")
    unknown_groups = set(groups or ()) - {spec.group for spec in all_cases.values()}
    if unknown_groups:
        raise ValueError(f"unknown groups: {sorted(unknown_groups)}")
    selected: dict[str, CaseSpec] = {}
    for cid, spec in all_cases.items():
        if case_ids and cid not in case_ids:
            continue
        if groups and spec.group not in groups:
            continue
        selected[cid] = spec
    if not selected:
        raise ValueError("no matching cases selected")
    return selected


def _build_host_initrd(
    base_initrd: Path,
    payload_path: Path,
    batch_text: str,
    out_path: Path,
) -> None:
    overlay = build_batch_overlay_cpio_gz(batch_text, payload_path.read_bytes())
    out_path.write_bytes(base_initrd.read_bytes() + overlay)


def _linux_mitigation_cmdline(profile: str) -> str:
    if profile == "perf-pti":
        return "pti=on"
    return "mitigations=off"


def _verify_batch_completeness(
    records: list[CaseRecord],
    *,
    round_idx: int,
    target: str,
    runnable_specs: dict[str, CaseSpec],
) -> None:
    seen: dict[str, int] = {}
    for rec in records:
        if rec.case_id not in runnable_specs:
            raise RuntimeError(
                f"{target} R{round_idx}: unexpected case_id {rec.case_id!r} in VM output"
            )
        seen[rec.case_id] = seen.get(rec.case_id, 0) + 1
    missing = [cid for cid in runnable_specs if cid not in seen]
    dups = [cid for cid, cnt in seen.items() if cnt != 1]
    if missing or dups:
        raise RuntimeError(
            f"{target} R{round_idx}: incomplete/duplicate records (missing={missing}, dups={dups})"
        )


def _run_target_batch(
    *,
    target: str,
    round_idx: int,
    specs: dict[str, CaseSpec],
    linux_bzimage: Path,
    linux_profile: str = "perf-base",
    aster_bzimage: Path,
    host_base_initrd: Path,
    payload_cpio: Path,
    grant_mb: int,
    vcpus: int,
    timeout_sec: int,
    log_dir: Path,
) -> list[CaseRecord]:
    skipped_records: list[CaseRecord] = []
    runnable_specs: dict[str, CaseSpec] = {}
    for cid, spec in specs.items():
        if spec.auto_skip_reason:
            skipped_records.append(
                CaseRecord(
                    round_idx=round_idx,
                    target=target,
                    case_id=cid,
                    rc=0,
                    wall_ns=0,
                    minflt_delta=0,
                    majflt_delta=0,
                    ru_utime_us=0,
                    ru_stime_us=0,
                    cpu_start=spec.cpus[0],
                    cpu_end=spec.cpus[0],
                    migrated=False,
                    thp_fault_alloc_delta=None,
                    stdout="",
                    stderr="",
                    value=None,
                    unit=spec.unit,
                    valid=True,
                    skipped=True,
                    skip_reason=spec.auto_skip_reason,
                )
            )
        else:
            runnable_specs[cid] = spec

    if not runnable_specs:
        return skipped_records

    if target == "A":
        all_records: list[CaseRecord] = []
        for spec in runnable_specs.values():
            runner_flags = " ".join(format_guest_runner_args(spec)[1:])
            cmdline = f"console=ttyS0 log_level=error -- --poweroff {runner_flags}"
            _, serial_text, _, _, _ = run_qemu_with_pinning(
                kernel_path=aster_bzimage,
                initrd_path=payload_cpio,
                cmdline=cmdline,
                vcpus=vcpus,
                mem_mb=2048,
                timeout_sec=timeout_sec,
                isa_debug_exit=True,
                expected_qemu_rcs=(33,),
                temp_root=TMP_ROOT,
                log_dir=log_dir,
                log_prefix=f"r{round_idx}_{target}_{spec.case_id}",
            )
            recs = parse_serial_records(
                serial_text, round_idx=round_idx, target=target, specs={spec.case_id: spec}
            )
            _verify_batch_completeness(
                recs, round_idx=round_idx, target=target, runnable_specs={spec.case_id: spec}
            )
            log_errors = check_kernel_log_clean(serial_text)
            for rec in recs:
                ok, reasons = validate_case_record(spec, rec)
                reasons.extend(log_errors)
                rec.valid = ok and not log_errors
                rec.invalid_reasons = reasons
            all_records.extend(recs)
        return skipped_records + all_records

    if target == "L":
        eval_role = "L"
        pt_mode = "direct"
    elif target == "K":
        eval_role = "K"
        pt_mode = "direct"
    elif target == "K_vma":
        eval_role = "K"
        pt_mode = "vma"
    else:
        raise ValueError(f"unsupported target: {target!r}")

    batch_text = format_batch_manifest(runnable_specs.values())
    TMP_ROOT.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=f"eval-{target}-", dir=str(TMP_ROOT)) as tmpdir:
        initrd = Path(tmpdir) / "host-initrd.cpio.gz"
        _build_host_initrd(host_base_initrd, payload_cpio, batch_text, initrd)
        mit_arg = _linux_mitigation_cmdline(linux_profile)
        cmdline = (
            f"console=ttyS0 panic=-1 transparent_hugepage=never {mit_arg} "
            f"eval_role={eval_role} eval_pt_mode={pt_mode} "
            f"eval_vcpus={vcpus} eval_grant_mb={grant_mb}"
        )
        _, serial_text, _, _, _ = run_qemu_with_pinning(
            kernel_path=linux_bzimage,
            initrd_path=initrd,
            cmdline=cmdline,
            vcpus=vcpus,
            mem_mb=2048,
            timeout_sec=max(timeout_sec, len(runnable_specs) * 30),
            isa_debug_exit=False,
            expected_qemu_rcs=(0,),
            temp_root=TMP_ROOT,
            log_dir=log_dir,
            log_prefix=f"r{round_idx}_{target}",
        )

    if "INIT: done" not in serial_text:
        raise RuntimeError(f"{target} round {round_idx}: missing 'INIT: done' in serial log")

    recs = parse_serial_records(
        serial_text, round_idx=round_idx, target=target, specs=runnable_specs
    )
    _verify_batch_completeness(
        recs, round_idx=round_idx, target=target, runnable_specs=runnable_specs
    )

    noop_stats: SandboxStats | None = None
    for rec in recs:
        if rec.case_id == "selfcheck.noop" and rec.sandbox_stats is not None:
            noop_stats = rec.sandbox_stats
            break

    log_errors = check_kernel_log_clean(serial_text)
    for rec in recs:
        spec = runnable_specs[rec.case_id]
        ok, reasons = validate_case_record(
            spec,
            rec,
            noop_stats=None if rec.case_id == "selfcheck.noop" else noop_stats,
        )
        reasons.extend(log_errors)
        if rec.sandbox_stats is not None:
            if rec.sandbox_stats.vcpus != vcpus:
                reasons.append(f"vCPU count mismatch: requested {vcpus}, got {rec.sandbox_stats.vcpus}")
            if rec.sandbox_stats.grant_mb != grant_mb:
                reasons.append(f"grant mismatch: requested {grant_mb} MiB, got {rec.sandbox_stats.grant_mb} MiB")
        rec.valid = ok and not reasons
        rec.invalid_reasons = reasons
    return skipped_records + recs


def cmd_check_config(args: argparse.Namespace) -> int:
    errors = check_kernel_config(Path(args.config), profile=args.profile)
    if errors:
        for err in errors:
            print(f"CONFIG ERROR: {err}", file=sys.stderr)
        return 1
    print(f"OK: {args.config} passed {args.profile} guard")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    suite = load_cases_toml(Path(args.cases))
    groups = args.group if args.group else None
    case_ids = args.case if args.case else None
    selected = _select_cases(suite.cases, groups, case_ids)

    targets = [t.strip() for t in args.targets.split(",") if t.strip()]
    if not targets or len(set(targets)) != len(targets):
        raise ValueError("targets must be nonempty and unique")
    unknown_targets = set(targets) - {"L", "A", "K", "K_vma"}
    if unknown_targets:
        raise ValueError(f"unsupported targets: {sorted(unknown_targets)}")
    rounds = args.rounds or suite.defaults.rounds
    seed = args.seed or suite.defaults.seed

    linux_config = Path(args.linux_config)
    cfg_errors = check_kernel_config(linux_config, profile=args.linux_profile)
    if cfg_errors:
        for err in cfg_errors:
            print(f"CONFIG GUARD FAIL: {err}", file=sys.stderr)
        return 1

    payload_cpio = Path(args.payload)
    host_initrd = Path(args.host_initrd)

    run_id = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d-%H%M%S") + f"-{args.tag}"
    out_dir = Path(args.results_dir) / run_id

    generate_and_write_archive(
        run_id=run_id,
        out_dir=out_dir,
        repo_root=REPO_ROOT,
        targets=targets,
        rounds=rounds,
        seed=seed,
        payload_path=payload_cpio,
        host_initrd_path=host_initrd,
        artifacts={
            "linux_bzimage": Path(args.linux_bzimage),
            "aster_bzimage": Path(args.aster_bzimage),
            "host_base_initrd": host_initrd,
            "payload_cpio": payload_cpio,
        },
        kernel_configs={args.linux_profile: (linux_config, args.linux_profile)},
    )

    # Step 0 gate: never start formal timed rounds if selfcheck fails.
    only_selfcheck = all(spec.group == "selfcheck" for spec in selected.values())
    if not only_selfcheck and not args.skip_selfcheck:
        sc_specs = _select_cases(suite.cases, ["selfcheck"], None)
        sc_records: list[CaseRecord] = []
        for t in targets:
            sc_records.extend(
                _run_target_batch(
                    target=t,
                    round_idx=0,
                    specs=sc_specs,
                    linux_bzimage=Path(args.linux_bzimage),
                    linux_profile=args.linux_profile,
                    aster_bzimage=Path(args.aster_bzimage),
                    host_base_initrd=host_initrd,
                    payload_cpio=payload_cpio,
                    grant_mb=suite.defaults.grant_mb,
                    vcpus=suite.defaults.vcpus,
                    timeout_sec=suite.defaults.timeout_sec,
                    log_dir=out_dir / "logs",
                )
            )
        sc_invalid = [r for r in sc_records if not r.valid]
        if not sc_records or sc_invalid:
            for rec in sc_invalid:
                print(
                    f"STEP 0 SELFCHECK FAIL [{rec.target} {rec.case_id}]: "
                    + "; ".join(rec.invalid_reasons),
                    file=sys.stderr,
                )
            return 1

    # Always include selfcheck.noop inside K batches for per-boot counter calibration.
    batch_specs = dict(selected)
    if "selfcheck.noop" in suite.cases and "selfcheck.noop" not in batch_specs and not only_selfcheck:
        batch_specs = {"selfcheck.noop": suite.cases["selfcheck.noop"], **batch_specs}

    schedule = schedule_rounds(targets, rounds, seed)
    all_records: list[CaseRecord] = []
    for round_idx, order in enumerate(schedule, start=1):
        for target in order:
            recs = _run_target_batch(
                target=target,
                round_idx=round_idx,
                specs=batch_specs,
                linux_bzimage=Path(args.linux_bzimage),
                linux_profile=args.linux_profile,
                aster_bzimage=Path(args.aster_bzimage),
                host_base_initrd=host_initrd,
                payload_cpio=payload_cpio,
                grant_mb=suite.defaults.grant_mb,
                vcpus=suite.defaults.vcpus,
                timeout_sec=suite.defaults.timeout_sec,
                log_dir=out_dir / "logs",
            )
            all_records.extend(recs)

    if not all_records:
        print("ERROR: zero benchmark records produced", file=sys.stderr)
        return 1

    write_records_jsonl(all_records, out_dir / "records.jsonl")
    md = render_markdown_report(selected, all_records, targets, title=f"Kernelet Eval ({run_id})")
    csv_text = render_csv_report(selected, all_records, targets)
    (out_dir / "report.md").write_text(md, encoding="utf-8")
    (out_dir / "report.csv").write_text(csv_text, encoding="utf-8")

    invalid = [r for r in all_records if not r.valid]
    if invalid:
        for rec in invalid:
            print(
                f"INVALID [{rec.target} R{rec.round_idx} {rec.case_id}]: "
                + "; ".join(rec.invalid_reasons),
                file=sys.stderr,
            )
        return 1

    print(f"Run complete: {out_dir}")
    print(md)
    return 0


def _parse_section_bases(items: list[str]) -> dict[str, int]:
    bases: dict[str, int] = {}
    for item in items:
        if "=" not in item:
            raise ValueError(f"expected SECTION=HEXADDR, got {item!r}")
        sec, addr = item.split("=", 1)
        bases[sec.strip()] = int(addr.strip(), 16)
    return bases


def cmd_perf_sym(args: argparse.Namespace) -> int:
    sec_bases = _parse_section_bases(args.ko_section)
    text = synthesize_guest_kallsyms(
        vmlinux_system_map=Path(args.system_map),
        endovisor_ko=Path(args.ko) if args.ko else None,
        endovisor_section_bases=sec_bases,
        kernelet_image=Path(args.kernelet_image) if args.kernelet_image else None,
        kernelet_load_base=int(args.kernelet_base, 16) if args.kernelet_base else None,
    )
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(text, encoding="utf-8")
    print(f"Wrote combined guestkallsyms to {out_path}")
    return 0


def cmd_profile(args: argparse.Namespace) -> int:
    perf_bin = shutil.which("perf")
    if not perf_bin:
        print(
            "ERROR: host 'perf' tool is not installed on PATH; cannot run 'perf kvm'",
            file=sys.stderr,
        )
        return 1
    out_kallsyms = Path(args.kallsyms_out)
    sec_bases = _parse_section_bases(args.ko_section)
    text = synthesize_guest_kallsyms(
        vmlinux_system_map=Path(args.system_map),
        endovisor_ko=Path(args.ko) if args.ko else None,
        endovisor_section_bases=sec_bases,
        kernelet_image=Path(args.kernelet_image) if args.kernelet_image else None,
        kernelet_load_base=int(args.kernelet_base, 16) if args.kernelet_base else None,
    )
    out_kallsyms.parent.mkdir(parents=True, exist_ok=True)
    out_kallsyms.write_text(text, encoding="utf-8")
    cmd = [
        perf_bin,
        "kvm",
        f"--guestkallsyms={out_kallsyms}",
        "record",
        "-F",
        str(args.freq),
        "-g",
        "-p",
        str(args.pid),
        "-o",
        str(args.perf_data),
        "--",
        "sleep",
        str(args.duration),
    ]
    return subprocess.call(cmd)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="kernelet-eval")
    sub = p.add_subparsers(dest="cmd", required=True)

    ck = sub.add_parser("check-config", help="Validate Linux .config against perf guard")
    ck.add_argument("--config", required=True)
    ck.add_argument("--profile", choices=["perf-base", "perf-pti"], default="perf-base")
    ck.set_defaults(func=cmd_check_config)

    rn = sub.add_parser("run", help="Run shuffled multi-round evaluation across L/A/K")
    rn.add_argument("--cases", default=str(EVAL_DIR / "configs" / "cases.toml"))
    rn.add_argument("--targets", default="L,A,K,K_vma")
    rn.add_argument("--rounds", type=int, default=0)
    rn.add_argument("--seed", type=int, default=0)
    rn.add_argument("--group", action="append", default=[])
    rn.add_argument("--case", action="append", default=[])
    rn.add_argument("--tag", default="eval")
    rn.add_argument("--skip-selfcheck", action="store_true")
    rn.add_argument("--results-dir", default=str(REPO_ROOT / "research" / "evaluation-plan" / "results"))
    rn.add_argument("--linux-bzimage", default=str(EVAL_DIR / ".build" / "linux-perf-base" / "arch" / "x86" / "boot" / "bzImage"))
    rn.add_argument("--linux-config", default=str(EVAL_DIR / ".build" / "linux-perf-base" / ".config"))
    rn.add_argument("--linux-profile", choices=["perf-base", "perf-pti"], default="perf-base")
    rn.add_argument("--aster-bzimage", default=str(EVAL_DIR / ".build" / "asterinas-native.bzImage"))
    rn.add_argument("--host-initrd", default=str(EVAL_DIR / ".build" / "host-eval-initramfs.cpio.gz"))
    rn.add_argument("--payload", default=str(EVAL_DIR / ".build" / "eval-payload.cpio"))
    rn.set_defaults(func=cmd_run)

    ps = sub.add_parser("perf-sym", help="Synthesize combined guestkallsyms for perf kvm")
    ps.add_argument("--system-map", required=True)
    ps.add_argument("--ko")
    ps.add_argument("--ko-section", action="append", default=[], help="SECTION=HEXADDR (e.g. .text=0xffffffffc0000000)")
    ps.add_argument("--kernelet-image")
    ps.add_argument("--kernelet-base")
    ps.add_argument("--out", required=True)
    ps.set_defaults(func=cmd_perf_sym)

    pf = sub.add_parser("profile", help="Synthesize guestkallsyms and run host perf kvm record")
    pf.add_argument("--system-map", required=True)
    pf.add_argument("--ko")
    pf.add_argument("--ko-section", action="append", default=[])
    pf.add_argument("--kernelet-image")
    pf.add_argument("--kernelet-base")
    pf.add_argument("--kallsyms-out", default=str(EVAL_DIR / ".build" / "guest.kallsyms"))
    pf.add_argument("--perf-data", default=str(EVAL_DIR / ".build" / "perf.data"))
    pf.add_argument("--pid", type=int, required=True)
    pf.add_argument("--freq", type=int, default=999)
    pf.add_argument("--duration", type=int, default=10)
    pf.set_defaults(func=cmd_profile)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
