{
  stdenv,
  fetchurl,
  hwloc,
}:
stdenv.mkDerivation rec {
  pname = "will-it-scale";
  version = "75f66e45";

  src = fetchurl {
    url = "https://github.com/antonblanchard/will-it-scale/archive/75f66e45697e6f5f49c33dd950c4e6b289198f8f.tar.gz";
    sha256 = "1df7639725a8ae4e764f4408fb276d9903f39aa8665a3abd9042086c5018ebab";
  };

  buildInputs = [ hwloc ];
  dontConfigure = true;

  buildPhase = ''
    runHook preBuild
    mkdir -p bin
    CC=${stdenv.cc.targetPrefix}cc
    TESTS="getppid1 open1 dup1 pipe1 page_fault1 page_fault2 page_fault3 mmap1 mmap2 brk1 malloc1"
    for t in $TESTS; do
      $CC -O2 -Wall -pthread -I. tests/$t.c main.c -lhwloc -o bin/${t}_processes
    done
    runHook postBuild
  '';

  installPhase = ''
    runHook preInstall
    mkdir -p $out/bin
    cp bin/*_processes $out/bin/
    runHook postInstall
  '';
}
