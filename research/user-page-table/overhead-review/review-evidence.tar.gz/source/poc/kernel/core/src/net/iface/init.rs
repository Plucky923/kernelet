// SPDX-License-Identifier: MPL-2.0

use core::slice::Iter;

use aster_bigtcp::{
    device::{AnyNetworkDevice, WithDevice},
    iface::{InterfaceFlags, InterfaceName, InterfaceType},
};
use aster_softirq::BottomHalfDisabled;
use spin::Once;

use super::{Iface, poll::poll_ifaces};
use crate::{net::iface::sched::PollScheduler, prelude::*};

static IFACES: Once<Vec<Arc<Iface>>> = Once::new();

#[cfg(ktest)]
pub(crate) fn poll_loopback_for_ktest() {
    IFACES.get().unwrap()[0].poll();
}

fn virtio_iface() -> Option<&'static Arc<Iface>> {
    IFACES.get().unwrap().get(1)
}

pub(in crate::net) fn iter_all_ifaces() -> Iter<'static, Arc<Iface>> {
    IFACES.get().unwrap().iter()
}

// TODO: Support multiple network devices and avoid the hardcoded device name.
const VIRTIO_DEVICE_NAME: &str = aster_virtio::device::network::DEVICE_NAME;

pub(in crate::net) fn init() {
    IFACES.call_once(|| {
        let mut ifaces = Vec::with_capacity(2);

        // Initialize loopback before virtio
        // to ensure the loopback interface index is ahead of virtio.
        ifaces.push(new_loopback());

        #[cfg(feature = "kernelet")]
        let shared = new_shared();
        #[cfg(not(feature = "kernelet"))]
        let shared = None;
        if let Some(iface_virtio) = shared.or_else(new_virtio) {
            ifaces.push(iface_virtio);
        }

        ifaces
    });

    if let Some(iface_virtio) = virtio_iface() {
        let callback = || iface_virtio.poll();
        #[cfg(feature = "kernelet")]
        let device_name =
            if aster_network::get_device(crate::net::device::shared::DEVICE_NAME).is_some() {
                crate::net::device::shared::DEVICE_NAME
            } else {
                VIRTIO_DEVICE_NAME
            };
        #[cfg(not(feature = "kernelet"))]
        let device_name = VIRTIO_DEVICE_NAME;
        aster_network::register_recv_callback(device_name, callback);
        aster_network::register_send_callback(device_name, callback);
    }

    poll_ifaces();
}

/// Initializes the real loopback interface without hardware components for kernel tests.
#[cfg(ktest)]
pub(crate) fn init_loopback_for_ktest() {
    IFACES.call_once(|| vec![new_loopback()]);
    crate::net::route::init();
    poll_ifaces();
}

fn new_loopback() -> Arc<Iface> {
    use aster_bigtcp::{
        device::Loopback,
        iface::IpIface,
        wire::{Ipv4Address, Ipv4Cidr, Ipv6Address, Ipv6Cidr},
    };

    const LOOPBACK_ADDRESS: Ipv4Address = Ipv4Address::new(127, 0, 0, 1);
    const LOOPBACK_ADDRESS_PREFIX_LEN: u8 = 8; // mask: 255.0.0.0
    const LOOPBACK_IPV6_ADDRESS: Ipv6Address = Ipv6Address::new(0, 0, 0, 0, 0, 0, 0, 1);
    const LOOPBACK_IPV6_PREFIX_LEN: u8 = 128;

    struct Wrapper(Mutex<Loopback>);

    impl WithDevice for Wrapper {
        type Device = Loopback;

        fn with<F, R>(&self, f: F) -> R
        where
            F: FnOnce(&mut dyn AnyNetworkDevice) -> R,
        {
            let mut device = self.0.lock();
            f(&mut *device)
        }
    }

    // FIXME: These flags are currently hardcoded.
    // In the future, we should set appropriate values.
    let flags = InterfaceFlags::UP
        | InterfaceFlags::LOOPBACK
        | InterfaceFlags::RUNNING
        | InterfaceFlags::LOWER_UP;

    IpIface::new(
        Wrapper(Mutex::new(Loopback::new())),
        Ipv4Cidr::new(LOOPBACK_ADDRESS, LOOPBACK_ADDRESS_PREFIX_LEN),
        Some(Ipv6Cidr::new(
            LOOPBACK_IPV6_ADDRESS,
            LOOPBACK_IPV6_PREFIX_LEN,
        )),
        InterfaceName::from_str_truncated("lo"),
        PollScheduler::new(),
        InterfaceType::LOOPBACK,
        flags,
    ) as Arc<Iface>
}

fn new_virtio() -> Option<Arc<Iface>> {
    new_ether::<aster_virtio::device::network::device::NetworkDevice>(VIRTIO_DEVICE_NAME)
}

#[cfg(feature = "kernelet")]
fn new_shared() -> Option<Arc<Iface>> {
    use crate::net::device::shared::{DEVICE_NAME, SharedNetworkDevice};

    if !SharedNetworkDevice::init()
        .expect("startup-selected shared Ethernet device must initialize")
    {
        return None;
    }
    new_ether::<SharedNetworkDevice>(DEVICE_NAME)
}

fn new_ether<D: AnyNetworkDevice>(device_name: &str) -> Option<Arc<Iface>> {
    use aster_bigtcp::{
        iface::EtherIface,
        wire::{Ipv4Address, Ipv4Cidr},
    };

    // Benchmark Hosts use .16 so images can address Host port mappings.
    // The explicit network flag also supports builds without timing probes.
    // Images and unconfigured Hosts keep the normal .15 address.
    #[cfg(all(
        any(kernelet_rq1, kernelet_bench_host_network),
        not(feature = "kernelet")
    ))]
    const VIRTIO_ADDRESS: Ipv4Address = Ipv4Address::new(10, 0, 2, 16);
    #[cfg(not(all(
        any(kernelet_rq1, kernelet_bench_host_network),
        not(feature = "kernelet")
    )))]
    const VIRTIO_ADDRESS: Ipv4Address = Ipv4Address::new(10, 0, 2, 15);
    const VIRTIO_ADDRESS_PREFIX_LEN: u8 = 24; // mask: 255.255.255.0
    const VIRTIO_GATEWAY: Ipv4Address = Ipv4Address::new(10, 0, 2, 2);

    let virtio_net = aster_network::get_device(device_name)?;

    let ether_addr = virtio_net.lock().mac_addr();

    struct Wrapper<D>(
        Arc<SpinLock<dyn AnyNetworkDevice, BottomHalfDisabled>>,
        core::marker::PhantomData<D>,
    );

    impl<D: AnyNetworkDevice> WithDevice for Wrapper<D> {
        type Device = D;

        fn with<F, R>(&self, f: F) -> R
        where
            F: FnOnce(&mut dyn AnyNetworkDevice) -> R,
        {
            let mut device = self.0.lock();
            f(&mut *device)
        }
    }

    // FIXME: These flags are currently hardcoded.
    // In the future, we should set appropriate values.
    let flags = InterfaceFlags::UP
        | InterfaceFlags::BROADCAST
        | InterfaceFlags::RUNNING
        | InterfaceFlags::MULTICAST
        | InterfaceFlags::LOWER_UP;

    Some(EtherIface::new(
        Wrapper::<D>(virtio_net, core::marker::PhantomData),
        ether_addr,
        Ipv4Cidr::new(VIRTIO_ADDRESS, VIRTIO_ADDRESS_PREFIX_LEN),
        VIRTIO_GATEWAY,
        InterfaceName::from_str_truncated("eth0"),
        PollScheduler::new(),
        flags,
    ))
}
