# 2026-11-16 Allocate the kernelet heap from the grant

- Status: Draft
- Author(s): Plucky923
- Discussion: No public review opened yet.
- Affected chapters: [The first kernel we will run](../accepted-design/the-first-kernel-we-will-run.md), [The kernelet ABI](../accepted-design/the-kernelet-abi.md), [Carriers](../accepted-design/carriers.md), [Stopping a kernelet](../accepted-design/stopping-a-kernelet.md), [What vOSTD adds on top](../accepted-design/what-vostd-adds-on-top.md), and [What it costs](../accepted-design/what-it-costs.md).
- Implementation or experiments: Not yet implemented. The argument below comes from source inspection; no local-heap performance or fault-injection results are available.

## Summary

This proposal removes `mem_alloc`, `mem_free`, and the endovisor's per-block heap table. Instead, vOSTD implements Rust's `#[global_allocator]` (`Box`, `Vec`, `Arc`) directly over grant pages using OSTD's `Frame` and `MetaSlot` model. Moving the heap into the grant eliminates 449-cycle host crossings and sleeping `kmalloc` calls under kernelet spin locks. Linux still delivers, accounts for, and reclaims the grant as a whole after execution and host accesses stop, without walking Rust objects.

## Problem and motivation

### Host page ownership vs. kernelet objects

A kernelet needs physical pages for two uses: user address spaces (`UFrame`) and its Rust heap (`Box`, `Vec`, `Arc`). Linux meters every backing page and reclaims the grant at sandbox stop, even if kernelet objects leak ([Stopping a kernelet](../accepted-design/stopping-a-kernelet.md#the-shape-of-a-death)). Subdividing a fixed grant into aligned objects inside vOSTD meets both host requirements without host calls per object.

### How the accepted host heap works and what it costs

Today, `FrameAllocOptions` takes user pages from the 4 MiB [grant](../accepted-design/the-kernelet-abi.md#the-grant-and-the-direct-map), while `HostHeap` (`prototype/vostd/src/mm/heap.rs`) forwards Rust allocations to `mem_alloc` and `mem_free`. As `new_frames` in `prototype/kernels/mem/src/lib.rs` shows, user frames come from the grant while the `Vec<UFrame>` buffer comes from Linux. `heap.rs` chose that split because the prototype grant is only 4 MiB.

Forwarding every Rust object to Linux adds three concrete costs:

1. **Per-object crossings and lock contention.** Each `alloc` or `free` switches to the Linux stack and takes `inst->heap.lock` to update `inst->heap.block`. [What it costs](../accepted-design/what-it-costs.md#the-crossing) measures 449 cycles for one 64-byte `mem_alloc`/`mem_free` pair, including ~120 cycles for the block table.
2. **Sleeping allocations under spin locks.** `mem_alloc` calls `kmalloc(GFP_KERNEL_ACCOUNT)`, which may sleep. Calling `Box` or `Vec` under a kernelet spin lock violates Rule 2 and can stall sibling vCPUs ([What vOSTD adds on top](../accepted-design/what-vostd-adds-on-top.md#the-rule-about-sleeping)).
3. **Per-block padding and teardown scans.** The endovisor pads every block by alignment (`size + align`) and maintains a dynamically grown `inst->heap.block` table. At teardown, `klet_heap_destroy` scans that table to `kfree` every leaked block.

## Proposed change

Linux continues to deliver, account for, and finally reclaim the grant. vOSTD manages pages and object storage within it.

### Use OSTD's frame model within the grant

When heap objects and user memory share one grant, vOSTD must track each page's role and stop heap pages from escaping as user frames. Adopting OSTD's `Frame`, `UniqueFrame`, and `MetaSlot` model adds per-page metadata for type safety, refcounts, and out-of-band slab state:

<div class="background">

**OSTD: direct-map frames and slabs.** At boot, OSTD maps all physical RAM once at a fixed kernel offset (`paddr_to_vaddr`) and never remaps pages for kernel allocations. [`GlobalFrameAllocator`](https://github.com/asterinas/asterinas/blob/ab9a4cfdc726263b3f41ccea0337633e24b443fc/ostd/src/mm/frame/allocator.rs#L130-L175) manages free physical pages, while each page has a 64-byte [`MetaSlot`](https://github.com/asterinas/asterinas/blob/ab9a4cfdc726263b3f41ccea0337633e24b443fc/ostd/src/mm/frame/meta.rs#L75-L118) storing its metadata `M`, refcount, and type. [`Frame<M>`](https://github.com/asterinas/asterinas/blob/ab9a4cfdc726263b3f41ccea0337633e24b443fc/ostd/src/mm/frame/mod.rs#L81-L121) shares read access to `M`, and [`UniqueFrame<M>`](https://github.com/asterinas/asterinas/blob/ab9a4cfdc726263b3f41ccea0337633e24b443fc/ostd/src/mm/frame/unique.rs#L18-L54) holds exclusive write ownership. OSTD's [`Slab`](https://github.com/asterinas/asterinas/blob/ab9a4cfdc726263b3f41ccea0337633e24b443fc/ostd/src/mm/heap/slab.rs#L23-L52) slices a `UniqueFrame` directly through `paddr_to_vaddr`; user page tables change only when mapping a `UFrame` for user space.

</div>

1. **Supply the grant range.** Initialize `GlobalFrameAllocator` with usable grant ranges, excluding bootstrap pages. Both heap allocations and `FrameAllocOptions` draw from and return pages to this pool.
2. **Index instance-local `MetaSlot`s.** Replace OSTD's `FRAME_METADATA_RANGE` lookup with an instance array indexed by `(paddr - grant_paddr) / PAGE_SIZE` after alignment and grant-bounds checks. Payload accesses still use `paddr_to_vaddr` over Linux's direct map.
3. **Reserve bootstrap metadata storage.** Allocate the slot array from static image data or early grant pages before the heap or `FrameAllocOptions` runs. With 64-byte slots, a 4 MiB grant (1,024 pages) requires a 64 KiB array (16 reserved grant pages if placed in the grant).

During normal execution, releasing a frame runs `M`'s `on_drop` before returning the page to `GlobalFrameAllocator`. On sandbox failure, Linux reclaims the whole grant without invoking `on_drop`.

Under this layer, `Slab` stores `Link<SlabMeta<SLOT_SIZE>>` in `MetaSlot`, and its drop checks that no slots remain live before freeing the backing page. The heap runs strictly within the fixed grant and never falls back to `kmalloc`.

### Connect Rust allocation to the local heap

Replace `HostHeap` (`prototype/vostd/src/mm/heap.rs`) with a grant-backed `#[global_allocator]` built from OSTD's `Slab` and `HeapSlot` (or OSTD's `AllocDispatch` and `GlobalHeapAllocator`). Because the host linear map already maps every grant page, `alloc` returns `paddr_to_vaddr(paddr) + offset` directly without touching any page table. Exhaustion returns null under the Rust `GlobalAlloc` contract instead of falling back to `kmalloc`.

### Keep heap pages private to the kernel

Live heap pages hold Rust objects and must never be exposed to user space:

- **Typed-frame boundary.** Heap page metadata (`SlabMeta`) must not implement `AnyUFrameMeta`, so safe code cannot turn heap pages into `UFrame` handles or `VmReader`/`VmWriter` targets.
- **Zeroing before reuse.** The heap retains each backing page until all its objects drop. Once a freed slab page returns to `GlobalFrameAllocator`, user allocations must zero it before mapping (`FrameAllocOptions` zeroing) so stale kernel data never leaks.
- **Trusted allocator code.** Moving the heap into the grant keeps the [language-based isolation model](../accepted-design/why-a-kernel-of-your-own.md#the-same-kernel-a-different-framework): allocator code remains trusted vOSTD with no hardware boundary inside the grant.

### Initialize the heap without depending on itself

Bootstrap must break the circular dependency between metadata, page allocation, and the heap:

1. **Strict startup order.** Initialize the `MetaSlot` array, `GlobalFrameAllocator`, and local heap before booting secondary vCPUs or constructing any `Box` or `Vec` (including command-line parsing and panic logging).
2. **Interrupt-safe locking.** Protect heap and frame allocators with vOSTD locks that handle kernelet preemption, masked virtual interrupts, concurrent vCPUs, and spinning (`vcpu::on_spin()`), with no recursive heap calls.

### Reclaim the grant after a failure

When a sandbox exits or fails, Linux reclaims backing grant pages without walking kernelet object lists or running Rust destructors:

1. **Stop execution.** Halt all carriers and block further sandbox entry so no kernelet or user-context access remains active.
2. **Drain host references.** Finish any in-flight host accesses and complete address-space and TLB teardown ([Stopping a kernelet](../accepted-design/stopping-a-kernelet.md#the-shape-of-a-death)).
3. **Free the grant whole.** Release the grant's backing pages from host allocation records after exit and the last sandbox descriptor close.

### Account for the shared capacity

The host already charges the grant via `GFP_KERNEL_ACCOUNT` (`prototype/linux/endovisor/sandbox.c`), so subdividing it into Rust objects adds no host charge. Heap pages, user-space memory, grant-resident `MetaSlot` storage, and free slab caches share this fixed budget. A 2 or 4 MiB grant may exhaust sooner than a split host heap. Empty slab caches stay charged until freed back to the pool. The sandbox `memory_max` ceiling still covers only the grant; Linux accounts separately for image pages, kernelet stacks, and address spaces.

## Alternatives and tradeoffs

| Alternative | Benefits | Costs and limits |
|---|---|---|
| Keep the host heap | Reuses `kmalloc`/`kfree` and keeps heap capacity separate from the grant | Retains per-object crossings, `inst->heap` records, and sleeping allocation under spin locks |
| Reserve a fixed heap region in the grant | Keeps bootstrap layout and heap quota explicit | Leaves spare capacity stranded on one side when the other fills |
| Share one local page pool between heap and user pages | Shifts capacity dynamically as workload demand changes | Requires `AnyUFrameMeta` isolation, zeroing before user reuse, and cache-release accounting |

## Implementation and integration

Replacing the host heap touches vOSTD's memory layer, startup sequence, image ABI, and test drivers:

| Location | Proposed work |
|---|---|
| `prototype/vostd/src/mm/frame.rs` | Replace the prototype bitmap with OSTD's `MetaSlot`, `Frame`, `UniqueFrame`, `UFrame`, and a global buddy allocator over grant pages |
| `prototype/vostd/src/mm/heap.rs` | Replace `HostHeap` with a `GlobalHeapAllocator` using OSTD `Slab` classes and `HeapSlot` over grant frames |
| `prototype/vostd/src/lib.rs` | Initialize `MetaSlot` storage, the buddy pool, and the local heap before `cmdline` parsing and `__ostd_main` |
| `prototype/vostd/src/abi.rs`, `prototype/linux/endovisor/kernelet.h`, and `prototype/linux/endovisor/carrier.c` | Remove `mem_alloc`, `mem_free`, `inst->heap.block`, and `klet_heap_destroy`, and bump `KLET_ABI_VERSION` |
| `prototype/kernels/mem/` and host tests | Test local allocation, exhaustion, isolation, and host teardown without `inst->heap.block` |
| Affected Accepted Design chapters | Document grant sharing, local allocation, whole-grant cleanup, and measured costs after acceptance |

`prototype/vostd/src/mm/frame.rs` serves as the shared foundation for both this design and the [direct page-table update proposal](2026-11-13-direct-page-table-updates-in-vostd.md). In both proposals, lower kernelet allocations consume grant pages while Linux-allocated `mm->pgd` stays outside `MetaSlot`. The local heap also works independently with the accepted Linux-managed page tables.

## Validation and evidence

Source inspection establishes the current host heap path, block table, and OSTD allocator contracts. The prototype has no implemented local heap or measured speedup yet. Acceptance requires the existing prototype suite plus targeted checks across six behaviors:

| Area | Required evidence |
|---|---|
| Allocation contracts | Test small classes, large `HeapSlot` pages, alignments, zeroing on user reuse, reallocation, and split deallocation. Verify every returned address lies inside owned grant pages without overlap. |
| Ownership | Audit safe APIs so `SlabMeta` pages cannot form `UFrame` handles or map into user space. Verify `MetaSlot` initialization, reference counts, and `on_drop` behavior. |
| Bootstrap and concurrency | Boot without host heap calls. Test concurrent vCPU allocations under `LocalIrqDisabled` spin locks without recursion, deadlock, or sleeping host calls. |
| Fixed capacity | Exhaust the shared pool and confirm null returns or `Error::NoMemory` without host fallback. Record peak `MetaSlot`, slab, buddy, and `UFrame` usage. |
| Failure cleanup | Destroy sandboxes with leaked `Box` and `Vec` allocations. Confirm Linux recovers the full grant with zero block-table walks, no kernelet destructors, and zero residual charges. |
| Cost and zero host crossings | Verify normal heap traffic emits zero `mem_alloc` or `mem_free` calls. Compare cycle counts against the 449-cycle host-heap baseline under matched workloads. |

## Open questions

- Does the existing `4 MiB` prototype grant fit `MetaSlot`, buddy overhead, the local heap, and current `mem` tests, or should default test grants increase?
- Should an empty `Slab` return to the buddy pool immediately, or should each size class retain one cached page to avoid thrashing?
- When adding future dynamic grant growth and shrinkage, should kernel slabs stay in unmovable segments while `UFrame`s use smaller returnable segments?

## Decision and follow-up

Status remains Draft pending prototype implementation and benchmark evidence. This proposal defines the shared `MetaSlot`, buddy frame, and local slab allocator over a single fixed grant. Accepted Design and the prototype keep the host heap until implementation and measurements land.
