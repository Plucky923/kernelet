# 2026-11-13 Direct page-table updates in vOSTD

- Status: Draft
- Author(s): Plucky923
- Discussion: Revised from the initial `2026-11-13` batched-services draft; batched services appear under [Alternatives and tradeoffs](#alternatives-and-tradeoffs).
- Affected chapters: [The kernelet ABI](../accepted-design/the-kernelet-abi.md), [Carrier hooks and patch overview](../accepted-design/carrier-hooks.md), [Into user mode and back](../accepted-design/into-user-mode-and-back.md), [Stopping a kernelet](../accepted-design/stopping-a-kernelet.md), [Tenant memory on Linux's page tables](../accepted-design/tenant-memory-on-linux-page-tables.md), [What vOSTD adds on top](../accepted-design/what-vostd-adds-on-top.md), and [What it costs](../accepted-design/what-it-costs.md).
- Implementation or experiments: Not yet implemented. Baseline `fork` measurements appear below; the [validation plan](#validation-and-evidence) precedes implementation.

## Summary

The accepted design maps tenant memory under a full-range `VM_PFNMAP` VMA and crosses into Linux for every PTE write. Over 90% of each `map` call goes to `mmap_lock`, VMA lookup, Linux page-table walks, and a second verification walk. This proposal deletes the VMA and removes `vm_map`, `vm_protect`, `vm_unmap`, `vm_wait`, and `vm_wake`. vOSTD allocates lower page-table pages from the sandbox grant and writes user PTEs in memory under per-node locks. Linux retains one VMA-free `mm_struct` per `VmSpace` for `CR3` scheduling, kernel-half updates, and `vm_flush` TLB shootdowns. A synchronous `on_exception` hook delivers user faults and the 11 supported traps to the kernelet without VMA callbacks or signals.

## Problem and motivation

### Who manages tenant page tables

Each carrier runs as a Linux task. Its page table must work with Linux scheduling, restrict mappings to the sandbox grant, and update quickly.

[Tenant memory on Linux's page tables](../accepted-design/tenant-memory-on-linux-page-tables.md#the-problem) delegates user PTE writes to Linux. Because Linux PTE helpers require a VMA, the endovisor creates one `mm_struct` and one full-range `VM_PFNMAP` VMA per `VmSpace`. On each `map`, `protect`, or `unmap`, vOSTD calls the endovisor to check the frame and invoke Linux.

This delegation adds four costs:

1. **Per-page crossings (`map`, `protect`).** Each single-page update enters `klet_do_vm_map()` or `klet_do_vm_protect()`.
2. **VMA locking (`map`, `protect`).** Each call takes `mmap_read_lock()` and runs `vma_lookup()`.
3. **Host tracking and double walks (`map`, `protect`).** `vmf_insert_pfn_prot()` checks PAT, walks the table, locks the PTE, and writes it. `klet_do_vm_map()` then walks and locks the slot again (`klet_space_ptes()`) to verify the PFN.
4. **Indirect trap delivery (`#PF`, traps).** `#PF` traverses RCU VMA lookup, `handle_mm_fault()`, and `klet_space_report()`. Other traps traverse `force_sig()` and `klet_drain_signals()` before `on_resume`.

<figure class="diagram">
<img src="../images/accepted-design-overhead.png" alt="Four sources of overhead across the PTE update path and user exception path in the accepted design.">
<figcaption>Four sources of overhead across the per-page PTE update path (steps 1–3) and user exception path (step 4).</figcaption>
</figure>

### What that choice costs

We measured five-boot medians on one KVM VM (2 vCPUs, 512 MiB RAM, Linux 6.12, 3.19 GHz Ryzen 7 5800H). Native Linux forks 64 MiB of 4 KiB anonymous pages (`MADV_NOHUGEPAGE`, 16,384 pages) in 0.34 ms (~21 ns or ~66 cycles/page), including VMA duplication. Linux walks each 2 MiB leaf table once, locks 512 PTEs together, write-protects and copies them, and flushes the TLB once.

In the same VM, the kernelet forks 64 MiB (256 frames mapped 64 times) by calling `protect` and `map` 16,384 times. That `fork` takes 7.85 ms (25.07 M cycles, ~479 ns or ~1,530 cycles/page) against 0.34 ms on native Linux.

| Kernelet operation (3.19 GHz VM) | Median | Median per page |
|---|---:|---:|
| null service crossing (stack switches) | 30 cycles (~9 ns) | n/a |
| `map`, one page per call | 447 cycles (140 ns) | 447 cycles (140 ns) |
| `map`, 512 pages under one cursor | reported per page | 472 cycles (148 ns) |
| `protect` 2 MiB read-only + flush (512 pages) | 243,808 cycles (76.3 µs) | ~476 cycles |
| `munmap` 64 MiB in one range call (16,384 pages) | 872,480 cycles (0.27 ms) | ~53 cycles |

One `CursorMut` across 512 pages still costs 472 cycles/page. `munmap` crosses once for 16,384 pages and drops to ~53 cycles/page. A null crossing costs 30 cycles (<7% of `map`), so `mmap_lock`, VMA lookup, and double walks consume >90%.

## Proposed change

### Why Linux need not maintain user page tables

A kernelet needs neither a Linux VMA nor per-PTE host calls:

- **No Linux VMA policy.** The kernel proper runs demand paging and copy-on-write. The accepted design set `VM_PFNMAP` to disable Linux page accounting and kept a VMA only for `vmf_insert_pfn_prot()` and `zap_vma_ptes()`.
- **Hardware ignores VMAs.** The x86-64 MMU reads `CR3` alone. With a VMA-free `mm_struct`, the MMU uses vOSTD-written PTEs while Linux VMA scanners skip user memory.
- **vOSTD enforces grant bounds.** Hypervisors intercept PTE writes because untrusted guest code builds the tables. Here, operator-compiled vOSTD maps only grant `UFrame`s ([Why a kernel of your own](../accepted-design/why-a-kernel-of-your-own.md), [What vOSTD adds on top](../accepted-design/what-vostd-adds-on-top.md)). Grant-backed tables let host kill reclaim the sandbox whole.

### Overview

Four layers divide page-table management:

- **Kernel proper (unchanged).** Uses OSTD `VmSpace`, `CursorMut`, and `TlbFlusher` APIs and handles user faults as on bare metal.
- **vOSTD.** Allocates grant tables and writes `mm->pgd[0..255]` and lower PTEs under node locks ([What vOSTD adds on top](../accepted-design/what-vostd-adds-on-top.md#reading-the-table)). It calls only `vm_create`, `vm_activate`, `vm_flush`, and `vm_destroy`.
- **Endovisor.** Allocates a VMA-free `mm_struct` in `vm_create`, switches spaces in `vm_activate`, runs `vm_flush`, forwards traps, and tears down spaces.
- **Linux and carrier hooks.** Loads `CR3` from `mm->pgd`, updates the kernel half, runs `flush_tlb_mm_range()`, and intercepts user traps via `on_exception`.

<figure class="diagram">
<img src="../images/direct-page-table-overview.png" alt="Responsibilities of vOSTD, the endovisor, and Linux in the proposed page-table design.">
<figcaption>Division of responsibilities around the tenant's single hardware page table (<code>mm-&gt;pgd</code>).</figcaption>
</figure>

Each kernel-proper operation moves from host VMA calls to direct vOSTD paths:

| Kernel proper call or event | Accepted design | Proposed design |
|---|---|---|
| `VmSpace::new()` | `vm_create` allocates `mm`, file, `VM_PFNMAP` VMA (two `kernelet_switch_mm` calls) | `vm_create` allocates VMA-free `mm_struct` (no file, VMA, or switch), publishes `root_paddr` |
| `vm_space.activate()` | `vm_activate` records space; `klet_space_adopt` switches before user mode | `vm_activate` switches via `kernelet_switch_mm()` and `mmput_async()` |
| `cursor.map(frame, prop)` | `vm_map` crossing (+ `withheld` `BTreeMap` if `!R`) | vOSTD allocates grant PT pages if needed and writes PTE in memory (including `!R`) |
| `cursor.protect_next(len, op)` | `vm_protect` crossing (or `vm_unmap`/`vm_map` across `withheld`) | vOSTD updates PTE atomically in place |
| `cursor.unmap(len)` | Walk + `vm_unmap` (`zap_vma_ptes` + flush) + `rcu::synchronize` | vOSTD clears PTEs, calls `vm_flush`, runs `rcu::synchronize()`, drops frames |
| `flusher.dispatch_tlb_flush()` | `vm_flush` (VMA leaf flush) | `vm_flush` (`flush_tlb_mm_range()`) |
| `VmSpace` drop (`retire::destroy`) | Walk + `vm_unmap` + `vm_destroy` (`zap_vma_ptes` + `mmput`) | Walks subtree, calls `vm_destroy` teardown, runs `rcu::synchronize()`, frees grant pages |
| Tenant `#PF` / user trap | VMA `fault`/`pfn_mkwrite` or `force_sig` + `klet_drain_signals` | `on_exception` intercepts user trap and delivers it via `on_resume` |

### VMA-free mm_struct and root page

On x86-64, one 4-level root (`mm->pgd`) maps both halves: shared Linux kernel slots `256..511` and tenant slots `0..255`. Deleting the VMA drops Linux's user-range tracking, but each `VmSpace` retains one VMA-free `mm_struct` because Linux still needs it to:

1. **Own and sync the root page.** Allocate `mm->pgd` and propagate host kernel updates in `256..511`.
2. **Restore `CR3` on schedule.** Reload `mm->pgd` across host preemptions and CPU migrations.
3. **Track CPUs and PCIDs.** Maintain `mm_cpumask` and PCID generations for `flush_tlb_mm_range()`.
4. **Switch tenant spaces.** Swap `current->mm` in `kernelet_switch_mm()` when a carrier changes tenant threads.

Previously, `klet_do_vm_create()` called `vm_mmap()` to build the VMA, which required an `anon_inode` file and switching `current->mm` in and back. Without VMAs, `klet_do_vm_create()` allocates only `sp->mm` and publishes `__pa(sp->mm->pgd)`:

*Proposed: simplifying `klet_do_vm_create` in `prototype/linux/endovisor/space.c`.*

```c
s64 klet_do_vm_create(struct klet_carrier *c)
{
	sp = alloc_free_space(c->inst);
	sp->mm = kernelet_mm_alloc(c->inst->owner);
	// Block core dumps and non-root `ptrace` on tenant spaces.
	set_mask_bits(&sp->mm->flags, MMF_DUMPABLE_MASK, SUID_DUMP_DISABLE);
	WRITE_ONCE(sp->rec->root_paddr, __pa(sp->mm->pgd));
	smp_store_release(&sp->live, true);
	return sp->id;
}
```

Every `mm->pgd` maps Linux's direct map (`linear_map_base`) in slots `256..511`. vOSTD therefore reads and updates any `VmSpace` at `linear_map_base + paddr` without changing `CR3`.

User execution still requires loading the target `mm->pgd` into `CR3`. Because `VmSpace::activate()` masks virtual interrupts and `mmput(old)` can sleep, the accepted design deferred switching until user-mode entry. Now `vm_activate` calls non-sleeping `kernelet_switch_mm(sp->mm)` and drops `old` via `mmput_async(old)`. Because `old` has no VMAs, `mmput_async(old)` never walks or frees lower page tables.

### Direct page-table writes in vOSTD

vOSTD runs upstream OSTD's page-table logic (`CursorMut::map`, `protect_next`, and `unmap`) directly in memory. Lower tables (levels 1–3) use grant frames, `MetaSlot` node locks (`PageTablePageMeta`), and hand-over-hand locking as on bare metal. Node locks add only `vcpu::on_spin()` while waiting. Extra handling applies only where Linux still allocates `mm->pgd`, sets `IA32_PAT`, or walks `mm->pgd` without locks.

<div class="background">

**Linux: page-table isolation (PTI).** To mitigate Meltdown, PTI removes full kernel mappings from user mode's `CR3`. Under `X86_FEATURE_PTI`, Linux allocates two adjacent 4 KiB pages per `mm->pgd` on an 8 KiB boundary. The first page is the kernel root (`root_paddr`), and the second is the user root (`root_paddr | PAGE_SIZE`). Its upper half maps only the kernel-entry trampoline in `256..511`. Across user slots `0..255`, both roots share one lower subtree. Linux loads `root_paddr` on kernel entry and `root_paddr | PAGE_SIZE` on user return. In the kernel root, [`__pti_set_user_pgtbl()`](https://elixir.bootlin.com/linux/v6.12/source/arch/x86/mm/pti.c#L124) sets `_PAGE_NX` on user entries when `__supported_pte_mask & _PAGE_NX` holds. Because vOSTD writes user PGD slots, it maintains both roots.

</div>

Because Linux allocates `mm->pgd` outside the grant `MetaSlot` array, `VmSpace` keeps a dedicated root lock for level 4. `BootArgs` exports `pti_enabled` (`X86_FEATURE_PTI`), `nx_supported` (`__supported_pte_mask & _PAGE_NX`), and `pgtable_levels`. vOSTD supports 4-level paging and rejects 5-level hosts (`pgtable_levels != 4`). Under the root lock, vOSTD mirrors [`__pti_set_user_pgtbl()`](https://elixir.bootlin.com/linux/v6.12/source/arch/x86/mm/pti.c#L124). When `pti_enabled` holds, it writes `root_paddr | PAGE_SIZE` without `_PAGE_NX` first, then `Release`-stores `root_paddr` with `_PAGE_NX` (if `nx_supported`). Non-leaf entries at levels 2–4 set `PRESENT | WRITE | USER | ACCESSED` and clear `HUGE`. They also clear `NO_EXECUTE` outside the kernel PTI root, so leaf PTEs control permissions.

An empty VMA tree stops VMA-based Linux scanners (`pagemap`, MGLRU, `exit_mmap()`). Two lockless Linux paths still walk `mm->pgd` on `current->mm`.

<div class="background">

**Linux: lockless page-table walkers and non-present PTE bits.** `perf_virt_to_phys()` walks `mm->pgd` in NMI context, where taking `mmap_lock` would deadlock. `gup_pgd_range()` (`gup_fast`) walks page tables under RCU or with interrupts disabled before checking VMAs. In `gup_pte_range()`, Linux skips an entry only when `pte_special()` (`_PAGE_SPECIAL`) holds or `pte_present()` is false; otherwise it updates the frame's `struct page` refcount. On x86-64, hardware ignores bits 1–63 when `Present = 0`. Linux reuses bit 8 (`_PAGE_GLOBAL`) as `_PAGE_PROTNONE` and defines `pte_present()` as `_PAGE_PRESENT | _PAGE_PROTNONE` (`arch/x86/include/asm/pgtable_types.h`).

</div>

`on_syscall` blocks carrier calls such as `O_DIRECT` from `gup_fast`, while host `perf` samples carriers in NMI context. To protect lockless walkers without patching Linux, `CursorMut::unmap` clears leaf PTEs and leaves lower tables (levels 1–3) attached until `VmSpace` destruction.

Before writing a leaf PTE, vOSTD checks alignment, user-range bounds, and `in_grant(paddr)`, and encodes three bit groups:

- **Host PAT slots.** Upstream OSTD sets bit 7 (`PAT` on 4 KiB pages) as a valid marker and reprograms `IA32_PAT`. Because Linux owns `IA32_PAT`, vOSTD leaves `IA32_PAT` untouched and encodes `CachePolicy` with Linux's slots.
- **Special and global bits.** Mapped leaf PTEs set `_PAGE_SPECIAL` (bit 9) and clear `_PAGE_GLOBAL` (bit 8). `gup_fast` then drops to its slow path, finds no VMA, and exits.
- **Readable and `!R` leaves.** Readable entries (`PageFlags::R`) set `PRESENT | USER | ACCESSED | SPECIAL` plus `WRITE`, `NO_EXECUTE`, and `DIRTY`. Non-readable entries (`!PageFlags::R`) clear `PRESENT` and `_PAGE_GLOBAL` and set `SOFTW2` (bit 10, keeping OSTD bits 52–53 free) to hold `paddr` and permissions in place.

### TLB flushing and space teardown

vOSTD sees only virtual CPUs and edits memory without changing `CR3`. Only Linux tracks which physical CPUs hold a space (`mm_cpumask`), sends cross-CPU IPIs, and runs host RCU:

- **Runtime TLB flushes (`vm_flush`).** Local `invlpg` misses remote physical CPUs in `mm_cpumask`, inactive spaces edited via the direct map, and PTI user PCIDs. `vm_flush` calls `flush_tlb_mm_range()` instead.
- **Space teardown (`vm_destroy`).** Without VMAs, `exit_mmap()` skips user tables and table-freeing TLB flushes. Reclaiming grant page tables requires evicting host CPUs holding stale `CR3` roots and waiting for host RCU readers. On `KLET_KILL`, kernelet cleanup never runs, so the endovisor must sever host references itself.

<div class="background">

**Linux: lazy TLB mode and freeing page tables.** When a CPU runs a kernel thread, x86 Linux keeps the last user `mm` in `CR3` (*lazy TLB mode*, `arch/x86/mm/tlb.c`). Page shootdowns skip lazy CPUs until they exit lazy mode. Freeing page-table pages requires `flush_tlb_mm_range()` with `freed_tables = true`: CPUs cache upper-level paging structures, walk `CR3` speculatively, and must switch lazy CPUs back to `init_mm`.

</div>

Runtime `VmSpace` retirement (`retire::destroy`) and sandbox exit or kill (`klet_spaces_destroy()`) run four teardown steps in order:

1. Wait for active `vm_activate` and `vm_flush` calls on the space to finish, and detach referencing vCPUs.
2. Zero user entries `0..255` in `mm->pgd` (and `root_paddr | PAGE_SIZE` under PTI) without reading lower tables.
3. Run `flush_tlb_mm_range(mm, 0, TLB_FLUSH_ALL, 0, true)` to clear paging-structure caches and evict lazy-TLB CPUs.
4. Clear `mm->owner`, run host `synchronize_rcu()` to drain NMI `perf`, `gup_fast`, and `mm->owner` readers, and call `mmput(mm)`.

On runtime `VmSpace` retirement, the last `Arc<VmSpace>` has dropped, so no cursor can edit the tree. vOSTD walks the user subtree first to collect mapped `UFrame`s (including `SOFTW2` entries) and lower table pages. It then calls `vm_destroy` (steps 1–4), runs `rcu::synchronize()` for descheduled `copy_regions` readers, and frees the collected grant pages. On sandbox exit or `KLET_KILL`, the endovisor runs steps 1–4 on every space without reading lower tables, then frees the grant whole.

### User-mode exception hook

On x86-64, user faults and traps enter Linux's IDT handlers first. Without a VMA, Linux treats every tenant page fault as an invalid access and turns user exceptions into POSIX signals (`SIGSEGV`, `SIGILL`, `SIGFPE`). Just as `on_syscall` intercepts system calls, `on_exception` intercepts user exceptions before Linux runs VMA lookup or queues a signal:

*Proposed: extending `struct carrier_event_hooks` in `prototype/linux/patches/0001-carrier-hooks.patch` (`include/linux/kernelet.h`).*

```c
struct carrier_event_hooks {
	// Intercepts a carrier's user-mode system calls before Linux's table.
	bool (*on_syscall)(struct pt_regs *regs);

	// Intercepts a carrier's user-mode CPU exceptions before Linux handles them.
	//
	// Returns `true` if the kernelet claims the exception and schedules delivery via `on_resume`,
	// or `false` to let Linux run its normal handler.
	bool (*on_exception)(struct pt_regs *regs, unsigned int trapnr,
			     unsigned long error_code, unsigned long addr);

	// Delivers pending kernelet events before returning to user mode.
	void (*on_resume)(struct pt_regs *regs);
};
```

Unlike `on_syscall`, `on_exception` runs on trap-entry contexts (such as `#DB`'s IST stack) where the kernelet cannot sleep or switch tasks. Therefore, `on_exception` only captures the trap and hands execution off to Linux's exit-to-user hook `on_resume` in `exit_to_user_mode_loop()`:

1. **Linux trap entry.** On `#PF`, `do_user_addr_fault()` (before `emulate_vsyscall()` and VMA lookup) and user-mode `do_kern_addr_fault()` invoke `on_exception` when `user_mode(regs)` holds. `arch/x86/kernel/traps.c` calls the same check for the other forwarded user traps so they also skip `force_sig()`.

*Proposed: forwarding `#PF` in `prototype/linux/patches/0001-carrier-hooks.patch` (`arch/x86/mm/fault.c`).*

```c
// In `do_user_addr_fault()`, after host checks and before `emulate_vsyscall()`.
if (unlikely(user_mode(regs) && tsk->carrier_hooks &&
	     tsk->carrier_hooks->on_exception &&
	     tsk->carrier_hooks->on_exception(regs, X86_TRAP_PF,
					      error_code, address)))
	return;
```

2. **Endovisor capture.** `klet_on_exception()` verifies `KLET_USER`, records `(trapnr, error_code, addr)` on the carrier, sets `TIF_NOTIFY_RESUME`, and returns `true` without touching `pt_regs`:

*Proposed: `klet_on_exception` in `prototype/linux/endovisor/carrier.c`.*

```c
static bool klet_on_exception(struct pt_regs *regs, unsigned int trapnr,
			      unsigned long error_code, unsigned long addr)
{
	struct klet_carrier *c = klet_current_carrier();

	if (c->state != KLET_USER)
		return false;
	// Record the trap now; `on_resume()` enters the kernelet on the normal stack.
	c->exc_trap = trapnr;
	c->exc_error = error_code;
	c->exc_addr = addr;
	c->exc_pending = true;
	set_thread_flag(TIF_NOTIFY_RESUME);
	return true;
}
```

3. **Kernelet dispatch via `on_resume`.** Returning from the trap enters `exit_to_user_mode_loop()` on the task's sleepable kernel stack with interrupts enabled. Seeing `exc_pending`, `on_resume` hands the exception to the kernelet just like `on_syscall`. In the accepted design it calls `klet_enter(KLET_RUN_EXCEPTION)`. Under the syscall-handoff `UserEventHandler` model, it enters `user_event_entry(UserEvent::Exception)` without returning:

*Proposed: dispatching `exc_pending` from `on_resume` into `UserEventHandler`.*

```rust
// 3a. In `on_resume(regs)` (`exit_to_user_mode_loop()`):
// Clear `c->exc_pending`, write `(exc_trap, exc_error, exc_addr)` to `vrec`,
// mask virqs, set `regs->orig_ax = -1`, and jump to `user_event_entry(UserEvent::Exception)`.

// 3b. In vOSTD `user_event_entry(raw_event)` (with virqs still masked):
let mut user = UserMode::for_current_carrier(); // reads exception from `vrec`
unmask_virtual_interrupts();
__ostd_user_handle(data, UserEvent::Exception, &task, &mut user);

// 3c. In kernel proper `UserEventHandler::handle`:
UserEvent::Exception => {
    let exception = user.take_exception();
    handle_exception(&ctx, user.context_mut(), exception.unwrap()); // resolves `#PF` via `CursorMut::map`
}
// Returning runs `pre_user_run` -> `user_run()` -> `kernelet_return_to_user()`.
```

Four constraints bound the hook:

- **User traps only.** `on_exception` runs only when `user_mode(regs)` and `KLET_USER` hold; kernel-mode faults return `-EFAULT` via Linux's exception table.
- **Host checks first.** Linux runs its hardware checks (reserved PTE bits, SMAP, error-code sanitization, and bus/split-lock fixups) before calling `on_exception`.
- **Forwarded traps.** Linux forwards Asterinas's 11 user traps (`#DE`, `#DB`, `#BP`, `#OF`, `#UD`, `#SS`, `#GP`, `#PF`, `#MF`, `#XM`, `#AC`). Fatal traps (`#BR`, `#DF`, `#MC`, non-XFD `#NM`) stay in Linux and kill the carrier.
- **No host VMAs or notifiers.** Because `on_syscall` blocks host memory system calls, no carrier can attach a VMA or `mmu_notifier` to a tenant `mm`.

## Alternatives and tradeoffs

- **Keep the accepted design (per-page Linux calls).** Leaving PTE writes in Linux keeps PTI and leaf-PTE formatting out of vOSTD, at the cost of a >20× slower `fork` (7.85 ms vs. 0.34 ms).
- **Batch Linux PTE calls (primary alternative).** Linux could keep the VMA and PTE writes while vOSTD buffers multiple `map` or `protect_next` updates and submits them under one `mmap_lock`. That cuts crossings on large contiguous ranges, but single-page faults (`#PF`) and small ranges still cross into Linux, take `mmap_lock`, and run Linux's double walk. Direct vOSTD writes remove Linux from every update path, speeding up both single-page and bulk operations.

## Implementation and integration

- **Linux patch** (`prototype/linux/patches/0001-carrier-hooks.patch`). Add `on_exception` to `struct carrier_event_hooks`. Call it after host-first checks on `#PF` (`do_user_addr_fault()` before `emulate_vsyscall()` and user-mode `do_kern_addr_fault()`). Call it on forwarded trap paths in `arch/x86/kernel/traps.c` as well.
- **Endovisor** (`prototype/linux/endovisor/kernelet.h`, `space.c`, `carrier.c`). Export `pti_enabled`, `nx_supported`, and `pgtable_levels` in `klet_boot_args` and bump `KLET_ABI_VERSION`. Delete `vm_map`, `vm_protect`, `vm_unmap`, `vm_wait`, `vm_wake`, `klet_space_adopt`, `anon_inode` creation, and `VM_PFNMAP` setup. Switch spaces in `vm_activate` via `kernelet_switch_mm()` and `mmput_async()`. Update `klet_space_teardown` to zero user PGDs, run `flush_tlb_mm_range(..., freed_tables = true)`, clear `mm->owner`, and call `synchronize_rcu()`. Delete fault-signal decoding from `klet_drain_signals()` and route traps through `klet_on_exception`.
- **vOSTD** (`prototype/vostd/src/mm/page_table.rs`, `vm_space.rs`, `backend.rs`, `arch/cpu/context.rs`). Reject 5-level hosts (`pgtable_levels != 4`). Delete `SpaceRec::lock`, `vm_wait`/`vm_wake`, `withheld`, and Rule 2 checks on `map`, `protect_next`, and `unmap`. Add grant page-table allocation, `PageTablePageMeta` locks with `vcpu::on_spin()`, and `VmSpace`'s root lock. Add PTI dual-root writes, `_PAGE_SPECIAL`/Linux `IA32_PAT`/`SOFTW2` leaf bits, non-pruning `unmap`, `retire::destroy` subtree collection, and 11-vector trap mapping (add `#SS`; drop `#BR`, `#NM`).
- **Book and proposals.** On acceptance, update the seven Accepted Design chapters listed above. Future grant-reclaim designs must keep installed page-table pages pinned until `klet_space_teardown` finishes.

## Validation and evidence

**Benchmarks.** Run five-boot benchmarks (no in-loop `rdtsc`) on the 2-vCPU, 512 MiB KVM VM with a 256 MiB chunked grant and `MADV_NOHUGEPAGE`. Compare native Linux, the accepted design, and this proposal across single-page faults, 16-page fault-around, 64 MiB populate, and 64 MiB `fork`. Also compare 2 MiB and 64 MiB read-only `protect` + flush, 1-ref and 2-ref COW faults, 64 MiB `munmap`, and `exit`. Verify zero first-touch faults after `map`, and measure the single-lock 512-PFN host bound to evaluate batched Linux calls.

**Correctness and safety tests.** Pass adapted `make mem-func`, `mem-conc`, `mem-pressure`, and `mem-kill`. Update `mem-r2` so `map`, `protect_next`, and `unmap` succeed under a `SpinLock` or masked virtual IRQs while `vm_create`, `vm_destroy`, and `mem_alloc` still trigger Rule 2 panics. Add tests for:

- `pti=on` (`CONFIG_MITIGATION_PAGE_TABLE_ISOLATION=y`), checking user execution and kernel `_PAGE_NX`;
- two-vCPU races installing shared PMD, PUD, and PGD entries with zero leaked pages;
- `perf` NMI address and callchain sampling during lazy-TLB `VmSpace` churn;
- all 11 forwarded vectors, kernel `-EFAULT`, QEMU TCG `-cpu SapphireRapids` `#NM` XFD, `#AC`/`#DB`/`#GP` host checks, and fatal unforwarded traps (`#BR`, non-XFD `#NM`, `#DF`, `#MC`);
- `KLET_KILL` after corrupting grant page-table entries, confirming clean module unload.

**Acceptance criteria.** All correctness and safety tests pass. Per-page `map`, `protect`, and `fork` drop to memory speed (near native Linux's ~21 ns/page in `fork`) without regressing `munmap`, `exit`, or first-touch latency.

## Open questions

- Adding a `CONFIG_MITIGATION_PAGE_TABLE_ISOLATION=y` build to CI, since `tinyconfig` disables PTI.
- Whether sparse `mmap`/`munmap` workloads need low-watermark batch pruning of empty lower tables under `freed_tables = true` and `synchronize_rcu()`.
- Sizing `KLET_GRANT_MAX` now that user page-table pages come from the grant instead of `GFP_PGTABLE_USER`.
- Measuring `synchronize_rcu()` latency in `vm_destroy` under rapid `fork` + `exit` churn.
- Whether full Asterinas needs high-watermark `retire` draining at syscall return or after `after_switching_to()` IRQ re-enable when `vcpu_idle` and `vm_create` do not run.

## Decision and follow-up

Pending prototype implementation, benchmark results, and review.
